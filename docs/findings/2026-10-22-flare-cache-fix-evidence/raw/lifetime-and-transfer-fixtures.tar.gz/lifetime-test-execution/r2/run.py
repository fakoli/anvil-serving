from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('OPERATOR_PATH_d81b073e3d22/flare-local-inference')
evidence=Path('OPERATOR_PATH_314c65bb5921/r2')
proposal=evidence.parent.parent/'lifetime-test-proposal'
source=root/'helios/src/server/runtime/phase_tests.rs'; patch=proposal/'lifetime-test.patch'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def binaries():
    return {str(p):sha(p) for p in (root/'helios/target/debug/deps').glob('flare_helios-*') if p.is_file() and os.access(p,os.X_OK)}
record={'source_before':sha(source),'patch_before':sha(patch),'binaries_before':binaries()}
assert record['source_before']=='b21df8e9ad32b725b7f5934820441138483b245eeb35479c176f1f701081aa78'
assert record['patch_before']=='43f14e55bd3724c87d9a04c847ee50d2412ed2df056b5826f52118faa4fde149'
record['source_applied']=sha(source)
command=['cargo','test','--locked','--jobs','2','--manifest-path','helios/Cargo.toml','--features','server,runtime-package','--lib','server::runtime::phase_tests::cancelled_shared_fetch_keeps_ticket_resources_until_completion','--','--exact','--nocapture']
updates={'PROTOC':'OPERATOR_PATH_b14c926a7f3b/protoc','LD_LIBRARY_PATH':'OPERATOR_PATH_904a718e9796/x86_64-linux-gnu'}
record.update(command=command,cwd=str(root),environment_overrides=updates,timeout_seconds=900,status='running',started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
(evidence/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
started=time.monotonic()
with (evidence/'stdout.log').open('wb') as stdout,(evidence/'stderr.log').open('wb') as stderr:
    try:
        result=subprocess.run(command,cwd=root,env={**os.environ,**updates},stdout=stdout,stderr=stderr,timeout=900)
        record.update(exit_code=result.returncode,status='passed' if result.returncode==0 else 'failed')
    except subprocess.TimeoutExpired:
        record.update(exit_code=None,status='timed_out')
record.update(elapsed_seconds=time.monotonic()-started,source_after=sha(source),patch_after=sha(patch),binaries_after=binaries(),finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
(evidence/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['status','exit_code','elapsed_seconds','source_after','patch_after']}))
