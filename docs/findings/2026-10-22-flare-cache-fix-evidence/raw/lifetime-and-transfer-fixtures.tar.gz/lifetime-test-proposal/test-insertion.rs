#[test]
fn cancelled_shared_fetch_keeps_ticket_resources_until_completion() {
    for success in [false, true] {
        let mut fixture = Fixture::new();
        fixture.config.limits.pages = 6;
        fixture.config.limits.snapshots = 3;
        let (sender, receiver) = mpsc::channel();
        let (first, first_generation) = fixture.incoming(vec![0; 70], 1);
        let (second, mut second_generation) = fixture.incoming(vec![0; 70], 1);
        let mut history = crate::cache::PrefixHistory::new(fixture.config.identity);
        history.append(&first.prompt.tokens, &[]).unwrap();
        sender.send(vec![first, second]).unwrap();
        let mut worker = fixture.worker(receiver);
        worker.attach_store(Some(Box::new(FakeStore::new(Some(host_hit(&history, 70))))));
        assert_eq!(worker.admit().unwrap(), ControlFlow::Continue(true));
        let first = worker.active[0].as_ref().unwrap().request;
        let second = worker.active[1].as_ref().unwrap().request;
        assert_eq!(fake_store(&mut worker).fetched.len(), 1);
        let ticket = fake_store(&mut worker).fetched[0].1.clone();
        assert_eq!(worker.scheduler.stats().inbound_waiting, 2);
        for handle in [first, second] {
            assert_eq!(worker.scheduler.request(handle).unwrap().phase, RequestPhase::Inbound);
        }
        drop(first_generation);
        assert_eq!(worker.admit().unwrap(), ControlFlow::Continue(true));
        assert!(worker.active[first.slot as usize].is_none());
        assert!(worker.scheduler.request(first).is_err());
        assert_eq!(fixture.metrics.cancelled.load(Ordering::Relaxed), 1);
        assert_eq!(worker.scheduler.request(second).unwrap().phase, RequestPhase::Inbound);
        assert_eq!(worker.scheduler.stats().inbound_waiting, 1);
        assert!(worker.plan(0).unwrap().0.is_none());
        assert_eq!(worker.scheduler.free_page_count(), 4);
        assert_eq!(worker.scheduler.free_snapshot_count(), 2);

        // Held, unrelated tickets fill every other snapshot row. Cancelling
        // their waiters frees only private request resources, not ticket storage.
        let spec = |token, length| RequestSpec {
            prompt: vec![token; length],
            message_boundaries: vec![],
            conditioning: vec![],
            max_new_tokens: 1,
            grammar_constrained: false,
            host_stops: false,
            growable_output: false,
        };
        let mut pressure = Vec::new();
        for token in [1, 2] {
            let request = spec(token, 70);
            let plan = worker.scheduler.plan_admission(&request).unwrap();
            let hit = host_hit(plan.history(), 70);
            let admitted = worker.scheduler.admit_planned(request, plan, Some(
                crate::scheduler::InboundRequest {
                    key: hit.key,
                    consumed_tokens: hit.consumed_tokens,
                    pages: hit.pages,
                },
            )).unwrap();
            let other = admitted.ticket.unwrap();
            assert_ne!(other.slot, ticket.slot);
            assert!(other.pages.iter().all(|page| !ticket.pages.contains(page)));
            worker.scheduler.cancel(admitted.handle).unwrap();
            pressure.push(other);
        }
        assert_eq!(worker.scheduler.free_snapshot_count(), 0);
        // Two available pages are insufficient to make the protected row free.
        let request = spec(3, 70);
        let plan = worker.scheduler.plan_admission(&request).unwrap();
        let hit = host_hit(plan.history(), 70);
        assert!(matches!(worker.scheduler.admit_planned(request, plan, Some(
            crate::scheduler::InboundRequest {
                key: hit.key,
                consumed_tokens: hit.consumed_tokens,
                pages: hit.pages,
            },
        )), Err(Error::Admission(AdmissionError::Capacity(_)))));
        let page_pressure = worker.scheduler.admit(spec(3, 127)).unwrap();
        assert_eq!(worker.scheduler.free_page_count(), 0);
        assert!(matches!(worker.scheduler.admit(spec(4, 1)),
            Err(Error::Admission(AdmissionError::Capacity(_)))));
        assert_eq!(worker.scheduler.request(second).unwrap().phase, RequestPhase::Inbound);
        assert_eq!(fake_store(&mut worker).fetched.len(), 1);
        assert_eq!(fake_store(&mut worker).fetched[0].1, ticket);
        worker.scheduler.cancel(page_pressure).unwrap();
        for other in pressure {
            assert!(worker.scheduler.finish_inbound(other.key, false).unwrap().is_empty());
        }
        assert_eq!(worker.scheduler.free_page_count(), 4);
        assert_eq!(worker.scheduler.free_snapshot_count(), 2);
        fake_store(&mut worker).events.push_back(crate::offload::StoreEvent::Fetched {
            key: ticket.key,
            result: if success { Ok(1 << 20) } else { Err("transfer failed".into()) },
        });
        assert!(worker.service_store().unwrap());
        assert_eq!(worker.scheduler.stats().inbound_waiting, 0);
        if success {
            let live = worker.scheduler.request(second).unwrap();
            assert_eq!(live.phase, RequestPhase::Restore);
            assert_eq!(live.pages().collect::<Vec<_>>(), ticket.pages);
            assert_eq!(worker.scheduler.snapshot_slot(live.prefix_snapshot().unwrap()), ticket.slot);
            let restored = live.prefix().unwrap();
            assert_eq!(worker.scheduler.cache().checkpoint(restored).unwrap().pin_count(), 1);
            advance(&mut worker, GraphKind::Restore, 1, None);
            advance(&mut worker, GraphKind::Resume, 2, Some(1));
            assert_eq!(worker.scheduler.request(second).unwrap().phase, RequestPhase::Finishing);
        } else {
            assert!(worker.scheduler.request(second).is_err());
            assert_eq!(worker.parked.len(), 1);
            assert!(!worker.parked[0].0.host_lookup);
            assert_eq!(worker.scheduler.free_page_count(), 6);
            assert_eq!(worker.scheduler.free_snapshot_count(), 3);
            assert_eq!(worker.admit().unwrap(), ControlFlow::Continue(true));
            let readmitted = worker.active.iter().flatten().next().unwrap().request;
            assert_eq!(worker.scheduler.request(readmitted).unwrap().phase, RequestPhase::Initialize);
            advance(&mut worker, GraphKind::Init, 1, None);
            advance(&mut worker, GraphKind::Prefill, 2, None);
            advance(&mut worker, GraphKind::Prefill, 3, Some(1));
            advance(&mut worker, GraphKind::Snapshot, 4, None);
        }
        assert!(worker.publish().unwrap());
        assert_eq!(worker.active.iter().flatten().count(), 0);
        let mut finished = 0;
        while let Ok(event) = second_generation.events.try_recv() {
            if let GenerationEvent::Finished { generated_tokens, reused_prompt_tokens, .. } = event {
                assert_eq!(generated_tokens, 1);
                assert_eq!(reused_prompt_tokens, if success { 70 } else { 0 });
                finished += 1;
            }
        }
        assert_eq!(finished, 1);
        assert_eq!(fake_store(&mut worker).fetched.len(), 1);
        // Cache eviction must succeed after the survivor's final fence and pins
        // release; ordinary admissions consume the entire six-page pool.
        let reclaim: Vec<_> = (1..=3)
            .map(|token| worker.scheduler.admit(spec(token, 127)).unwrap())
            .collect();
        assert_eq!(worker.scheduler.free_page_count(), 0);
        for handle in reclaim {
            worker.scheduler.cancel(handle).unwrap();
        }
        assert_eq!(worker.scheduler.free_page_count(), 6);
        assert_eq!(worker.scheduler.free_snapshot_count(), 3);
    }
}

