run decode-c4 180 measured measured 0
