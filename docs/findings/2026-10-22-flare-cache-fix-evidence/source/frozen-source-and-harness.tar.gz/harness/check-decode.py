"""Offline decode body identity, normalization and whole-batch matching checks."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import decode
from analyze import compare

contract=json.loads((Path(__file__).parent/'decode-contract.json').read_text())
spec=importlib.util.spec_from_file_location('old',contract['source_fixture']['path'])
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
for ref in contract['bodies']:
    raw=Path(ref['path']).read_bytes()
    assert raw==json.dumps(old.body(ref['index']),sort_keys=True).encode()
    assert hashlib.sha256(raw).hexdigest()==ref['sha256']
row={'output_token_ids':list(range(1024)),'core_token_timestamps_ns':[2000+i*1000 for i in range(1024)],
    'usage':{'prompt_tokens':7037,'completion_tokens':1024},'performance':{'ingress_ns':100,'enqueue_ns':200},
    'finish_reasons':['length'],'done':True,'e2e':1,
    'events':[{'event':{'choices':[{'delta':{'reasoning_content':'exact reasoning span'}}]}}]}
normalized=decode.normalize(0,'a'*64,row)
assert normalized['reasoning_span_sha256']==hashlib.sha256(b'exact reasoning span').hexdigest()
assert normalized['speculative_work'] is None and normalized['decode_tokens_per_second']==1000000
bad=copy.deepcopy(row);bad['output_token_ids'].pop()
try:decode.normalize(0,'a'*64,bad);raise AssertionError('1023 IDs accepted')
except ValueError:pass
work={'proposed':4,'accepted':2,**{'flare_speculative_'+name+'_total{batch="4",width="2"}':value for name,value in [('rounds',2),('emitted_tokens',4),('offered_drafts',4),('accepted_drafts',2)]}}
plan={'repetitions':3,'arm_orders':[['A','B'],['B','A'],['A','B']],
 'required_acceptance_receipts':['functional'],'thresholds':{'primary_min_improvement_percent_each_rep':5,'protected_max_regression_percent_each_rep':3},
 'lanes':{'decode-c4':{'role':'protected','metric':'decode_tokens_per_second','prime_requests':0,'measured_requests':4,'requests_per_arm_rep':4}}}
runs=[]
for rep in range(1,4):
    for arm in 'AB':
        attempts=[]
        for index in range(4):
            item=copy.deepcopy(normalized);item['case_id']=str(index);attempts.append(item)
        runs.append({'lane':'decode-c4','repetition':rep,'arm':arm,'order':plan['arm_orders'][rep-1].index(arm),
            'receipts':{'functional':True},'attempts':attempts,'batch_speculative_work':copy.deepcopy(work)})
assert compare({'runs':runs},plan)['comparison_gates_passed']
for change in ['batch','reasoning','ids','fake_request_spec']:
    bad=copy.deepcopy(runs)
    if change=='batch':bad[1]['batch_speculative_work']['proposed']+=1
    elif change=='reasoning':bad[1]['attempts'][0]['reasoning_span_sha256']=None
    elif change=='ids':bad[1]['attempts'][0]['output_token_ids'][0]=9999
    else:bad[1]['attempts'][0]['speculative_work']=work
    assert not compare({'runs':bad},plan)['comparison_gates_passed'],change
print('PASS: exact prior request bytes,1024-ID native decode normalization, exact reasoning spans, batch-owned C4 spec matching; corrupt/missing/fake attribution rejected')
