"""Small runnable synthetic positive, negative and corrupted evidence checks."""
import copy
from analyze import compare
import hashlib
import json
from oracles import check

plan = {'repetitions': 3, 'arm_orders': [['A','B'],['B','A'],['A','B']],
        'thresholds': {'primary_min_improvement_percent_each_rep': 5, 'protected_max_regression_percent_each_rep': 3},
        'required_acceptance_receipts': ['functional'],
        'lanes': {name: {'role': role, 'metric': 'client_generated_ttft', 'prime_requests': 1,
                        'measured_requests': 1, 'requests_per_arm_rep': 2}
                  for name, role in [('fixed-work','primary'),('small12','protected')]}}
runs = []
for lane in plan['lanes']:
    for rep in range(1,4):
        for arm in 'AB':
            rows = [{'case_id': '0', 'phase': phase, 'ok': True, 'body_sha256': 'a'*64,
                     'prompt_tokens': 100, 'output_token_ids': [42], 'reasoning_tokens': 0,
                     'speculative_work': {'proposed': 3, 'accepted': 1},
                     'client_generated_ttft': 100 if arm == 'A' else 94}
                    for phase in ['prime','measured']]
            runs.append({'lane': lane, 'repetition': rep, 'arm': arm,
                         'order': plan['arm_orders'][rep-1].index(arm),
                         'receipts': {'functional': True}, 'attempts': rows})
data = {'runs': runs}
assert compare(data, plan)['comparison_gates_passed']
for field, value in [('client_generated_ttft',96), ('speculative_work',None),
                     ('output_token_ids',[43]), ('client_generated_ttft',float('nan')),
                     ('prompt_tokens',None)]:
    bad=copy.deepcopy(data); bad['runs'][1]['attempts'][1][field]=value
    assert not compare(bad, plan)['comparison_gates_passed'], field
bad=copy.deepcopy(data); bad['runs'][1]['attempts'][0]['ok']=False
report=compare(bad, plan)
assert not report['comparison_gates_passed'] and report['failures']
assert report['lanes']['fixed-work'][0]['denominators']['B']['failed'] == 1
bad=copy.deepcopy(data); bad['runs'][1]['attempts'].pop()
assert not compare(bad, plan)['comparison_gates_passed']
bad=copy.deepcopy(data); bad['runs'].append(bad['runs'][0])
assert not compare(bad, plan)['comparison_gates_passed']
bad=copy.deepcopy(data); bad['runs'][-1]['attempts'][1]['client_generated_ttft']=104
assert not compare(bad, plan)['comparison_gates_passed']
assert check('strict', {'content':'42'}, '42')
assert not check('strict', {'content':'The answer is 42'}, '42')
assert check('json', {'content':'{"language":"python","ok":true}'}, {'language':'python','ok':True})
assert not check('json', {'content':'prose {"language":"python"}'}, {'language':'python','ok':True})
tool={'tool_calls':[{'id':'call_1','type':'function','function':{'name':'get_weather','arguments':'{"city":"Oakland"}'}}]}
assert check('tool', tool, {'name':'get_weather','arguments':{'city':'Oakland'}})
assert not check('tool', tool, {'name':'get_weather','arguments':{'city':'wrong'}})
assert check('restore_tokens', {'token_ids':[1,2]}, [1,2])
assert not check('restore_tokens', {'token_ids':[1,3]}, [1,2])
print('PASS: three-pair thresholds, protected regression, all-failure denominators, missing/corrupted work, exact independent oracles')
# Fake in-memory SSE transport; never starts a service or contacts a live endpoint.
import importlib.util
from pathlib import Path
import tempfile
import time
import io
spec=importlib.util.spec_from_file_location('replay',Path(__file__).with_name('replay.py'))
replay=importlib.util.module_from_spec(spec); spec.loader.exec_module(replay)
class Response(io.BytesIO):
    status=200
payload=(b'data: {"id":"r1","choices":[{"token_ids":[42],"delta":{}}]}\n\n'
         b'data: {"id":"r1","choices":[{"finish_reason":"length","delta":{}}],"usage":{"prompt_tokens":100,"completion_tokens":1}}\n\n'
         b'data: [DONE]\n\n')
replay.urllib.request.urlopen=lambda *a,**k:Response(payload)
with tempfile.TemporaryDirectory() as temp:
    capture=Path(temp)/'response.json'
    result=replay.request({'max_tokens':1},'offline-key',time.monotonic()+5,capture)
    assert result['client_generated_ttft'] is not None and result['visible_ttft'] is None
    assert result['request_ids']==['r1'] and capture.exists()
    replay.urllib.request.urlopen=lambda *a,**k:Response(payload.replace(b'[42]',b'[42,43]'))
    try:
        replay.request({'max_tokens':1},'offline-key',time.monotonic()+5,capture)
        raise AssertionError('over-generation accepted')
    except ValueError:
        assert 'one-generated-token' in json.loads(capture.read_text())['error']
assert [i for i,_ in replay.bodies('small12','prime')]==list(range(40,52))
assert [i for i,_ in replay.bodies('fixed-work','measured')]==list(reversed(range(52)))
print('PASS: raw-ID client TTFT, reasoning-only fixed1 allowed, over-generation fails with retained evidence, exact retained order/hashes')
metrics_before = '\n'.join(f'flare_speculative_{name}_total{{batch="1",width="2"}} {value}' for name,value in [('offered_drafts',4),('accepted_drafts',2),('rounds',2),('emitted_tokens',3)])
metrics_after = '\n'.join(f'flare_speculative_{name}_total{{batch="1",width="2"}} {value}' for name,value in [('offered_drafts',7),('accepted_drafts',3),('rounds',3),('emitted_tokens',4)])
assert replay.speculative_delta(metrics_before,metrics_after)['proposed'] == 3
assert replay.speculative_delta('flare_speculative_rounds_total 2', 'flare_speculative_rounds_total 3') is None
assert replay.speculative_delta('', '') is None
assert replay.speculative_delta('flare_speculative_offered_drafts_total 2', 'flare_speculative_offered_drafts_total 1') is None
assert not check('json', {'content':'{"language":"python","ok":1}'}, {'language':'python','ok':True})
for lane in ('pageheavy','cold'):
    original_status=replay.PLAN[lane]['status']
    try:
        replay.PLAN[lane]['status']='unverified-offline-fixture'
        try:
            replay.bodies(lane,'prime')
            raise AssertionError('unverified protected corpus admitted')
        except ValueError as error:
            assert 'gate unresolved' in str(error)
        replay.PLAN[lane]['status']='tokenization_and_capacity_verified'
        assert len(replay.bodies(lane,'prime'))==12
    finally:
        replay.PLAN[lane]['status']=original_status
print('PASS: native speculative-work deltas, reset rejection, exact JSON types, protected lane gate')
bounded=copy.deepcopy(data)
bounded_plan=copy.deepcopy(plan)
for lane in bounded_plan['lanes'].values(): lane['contract']='fixed1'
for run in bounded['runs']:
    for row in run['attempts']:
        row['reasoning_tokens']=None
        row['usage']={'completion_tokens':1}
assert compare(bounded,bounded_plan)['comparison_gates_passed']
bounded['runs'][1]['attempts'][1]['usage']['completion_tokens']=2
assert not compare(bounded,bounded_plan)['comparison_gates_passed']
print('PASS: predeclared fixed1 bounded-work exception requires raw1-ID AND usage1, never fabricated reasoning counts')
tool_payload=(b'data: {"id":"tool_request","choices":[{"delta":{"tool_calls":[{"index":0,"id":"call_x","type":"function","function":{"name":"get_weather","arguments":"{\\\"city\\\":"}}]}}]}\n\n'
              b'data: {"id":"tool_request","choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\\"Oakland\\\"}"}}]},"finish_reason":"tool_calls"}],"usage":{"prompt_tokens":100,"completion_tokens":12}}\n\n'
              b'data: [DONE]\n\n')
replay.urllib.request.urlopen=lambda *a,**k:Response(tool_payload)
with tempfile.TemporaryDirectory() as temp:
    result=replay.request({'tools':[{}]},'offline-key',time.monotonic()+5,Path(temp)/'response.json')
    assert check('tool', result['message'], {'name':'get_weather','arguments':{'city':'Oakland'}})
    assert result['message']['tool_calls'][0]['id']=='call_x' and result['request_ids']==['tool_request']
print('PASS: fragmented tool arguments and tool_calls terminal, preserved request and tool IDs')

assert replay.speculative_delta(metrics_before.replace('rounds_total{batch="1",width="2"}','rounds_total{batch="2",width="2"}'), metrics_after.replace('rounds_total{batch="1",width="2"}','rounds_total{batch="2",width="2"}')) is None
assert replay.native_first_token({'performance':{'ingress_ns':100,'enqueue_ns':150},'core_token_timestamps_ns':[200],'output_token_ids':[42]}) == 1e-7
assert replay.native_first_token({'performance':{'ingress_ns':300,'enqueue_ns':350},'core_token_timestamps_ns':[200],'output_token_ids':[42]}) is None
assert replay.native_first_token({'performance':{'ingress_ns':100,'enqueue_ns':150},'core_token_timestamps_ns':[200],'output_token_ids':[42,43]}) is None
assert len(replay.bodies('pageheavy-pilot','measured')) == 12
assert len(replay.bodies('cold-pilot','measured')) == 12
assert replay.bodies('pageheavy-pilot','measured')[0][1] == json.loads(Path(replay.PLAN['pageheavy']['bodies']['path']).read_text())[0]
# Retained real SSE uses package revision although /v1/models advertises served alias.
fixture=json.loads((Path(__file__).parent.parent/'pilot-a-correctness-r2/http/000-response.json').read_text())
first=fixture['events'][0]['event'];revision=first['model'];alias=replay.MODEL if hasattr(replay,'MODEL') else replay.prior.MODEL
extra=[{'id':first['id'],'model':revision,'choices':[{'token_ids':[42],'delta':{}}]},
       {'id':first['id'],'model':revision,'choices':[{'finish_reason':'length','delta':{}}],
        'usage':{'prompt_tokens':len(first['prompt_token_ids']),'completion_tokens':1}}]
real_sse=b''.join(('data: '+json.dumps(event)+'\n\n').encode() for event in [first,*extra])+b'data: [DONE]\n\n'
replay.urllib.request.urlopen=lambda *a,**k:Response(real_sse)
with tempfile.TemporaryDirectory() as temp:
    capture=Path(temp)/'real-model-response.json'
    try:
        replay.request({'model':alias,'max_tokens':1},'offline-key',time.monotonic()+5,capture)
        raise AssertionError('unproven revision accepted')
    except ValueError as error:assert 'model identity' in str(error)
    assert replay.request({'model':alias,'max_tokens':1},'offline-key',time.monotonic()+5,capture,{alias,revision})['done']
    envelope=json.loads((Path(__file__).parent/'retained-running-receipt.json').read_text())
    inv=json.loads(envelope['data']) if isinstance(envelope['data'],str) else envelope['data']
    verified=inv['containers'][0]
    proof={'verified':verified,'registry':str(Path(__file__).parent.parent/'registry-a.toml'),
           'registry_sha256':verified['registry_digest'],'recipe_sha256':verified['recipe_digest']}
    proof_path=Path(temp)/'proof.json';proof_path.write_text(json.dumps(proof))
    assert replay.proven_source_revision(proof_path,alias)==revision
    proof['registry_sha256']='0'*64;proof_path.write_text(json.dumps(proof))
    try:
        replay.proven_source_revision(proof_path,alias)
        raise AssertionError('invalid managed digest proof accepted')
    except ValueError:pass
print('PASS: retained real SSE revision mismatch rejected by default; exact managed revision compatibility only; corrupt proof rejected')
from types import SimpleNamespace
socket_budgets=[];connect_budgets=[]
class TimedResponse(Response):
    def __init__(self,data):
        super().__init__(data)
        self.fp=SimpleNamespace(raw=SimpleNamespace(_sock=SimpleNamespace(settimeout=socket_budgets.append)))
def timed_response(*args,**kwargs):
    connect_budgets.append(kwargs['timeout']);return TimedResponse(real_sse)
replay.urllib.request.urlopen=timed_response
with tempfile.TemporaryDirectory() as temp:
    replay.request({'model':alias,'max_tokens':1},'offline-key',time.monotonic()+50,Path(temp)/'bounded.json',{alias,revision})
assert 10 < connect_budgets[0] <= 50
assert socket_budgets and all(0 < value <= 50 for value in socket_budgets)
print('PASS: connect/read budgets use remaining declared request deadline, without hidden10second cutoff')
restore=replay.bodies('restore-pilot','prime')
assert [i for i,_ in restore]==[0,40,51]
assert restore==replay.bodies('restore-pilot','measured')
for i,body in restore:
    fixed=json.loads((Path(__file__).parent/'fixed1-bodies.json').read_text())[i]
    expected=dict(fixed);expected['max_tokens']=128
    assert body==expected and body['temperature']==0 and body['return_token_ids'] is True
print('PASS: frozen restore-pilot indices0/40/51,128token cap, original fixed1 messages/observation flags, same prime/replay order')
pressure=replay.bodies('restore-pressure','measured')
assert [i for i,_ in pressure]==list(range(12,32))
assert len({json.dumps(body['messages']) for _,body in pressure})==20
cold=json.loads((Path(__file__).parent/'cold-bodies.json').read_text())[0]
for _,body in pressure:
    assert body['max_tokens']==1 and body['temperature']==0
    assert {k:v for k,v in body.items() if k!='messages'}=={k:v for k,v in cold.items() if k!='messages'}
assert pressure==replay.bodies('restore-pressure','prime')
print('PASS: frozen20 novel restore-pressure bodies, indices12..31, fixed1 cold controls, same request order')
warmup=replay.bodies('warmup','prime')
assert [i for i,_ in warmup]==[0,1,2] and warmup==replay.bodies('warmup','measured')
existing=[]
for filename in Path(__file__).parent.glob('*-bodies.json'):
    if filename.name=='warmup-bodies.json':continue
    for row in json.loads(filename.read_text()):existing.append(row.get('body',row))
for filename in (Path(__file__).parent/'decode-bodies').glob('*-body.json'):existing.append(json.loads(filename.read_text()))
for reference in replay.PLAN['original_bodies']:existing.append(json.loads(Path(reference['path']).read_text()))
existing_messages={json.dumps(body['messages'],sort_keys=True) for body in existing}
pages=json.loads((Path(__file__).parent/'pageheavy-bodies.json').read_text())
for (i,body),source in zip(warmup,[0,4,8]):
    assert json.dumps(body['messages'],sort_keys=True) not in existing_messages
    assert {k:v for k,v in body.items() if k!='messages'}=={k:v for k,v in pages[source].items() if k!='messages'}
    assert body['messages'][0]['content'].count(' apple')==[8000,16000,29000][i]
assert len({json.dumps(body['messages']) for _,body in warmup})==3
print('PASS: frozen3 disjoint warmup bodies, fixed0/1/2 order, same pageheavy controls/profiles; tokenization pending pilot')
diagnostic=compare(data,plan)
assert diagnostic['comparison_gates_passed'] is True
assert diagnostic['diagnostic_only'] is True and diagnostic['recommend_candidate'] is False and diagnostic['performance_eligible'] is False
assert diagnostic['diagnostic_amendment']['sha256']==hashlib.sha256(Path(diagnostic['diagnostic_amendment']['path']).read_bytes()).hexdigest()
print('PASS: canonical diagnostic amendment forces recommendation/performance false despite passing hand-entered receipts and thresholds')
