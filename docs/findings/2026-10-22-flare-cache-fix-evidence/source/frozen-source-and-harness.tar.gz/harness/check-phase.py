"""Offline checks against retained real status/inventory schemas; no model HTTP."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import tomllib

ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('phase',ROOT/'run-phase.py')
phase=importlib.util.module_from_spec(spec);spec.loader.exec_module(phase)
status=json.loads((ROOT.parent/'pilot-a-correctness/status.jsonl').read_text().splitlines()[0])['status']
envelope=json.loads((ROOT/'retained-running-receipt.json').read_text())
inventory=json.loads(envelope['data']) if isinstance(envelope['data'],str) else envelope['data']
raw=(ROOT.parent/'registry-a.toml').read_bytes();recipe=tomllib.loads(raw.decode())['recipe'][0]
sys.path.insert(0,str(phase.WORKTREE))
from anvil_serving.serve_recipes import recipe_digest
registry_hash=phase.hashlib.sha256(raw).hexdigest();recipe_hash=recipe_digest(recipe)
assert 'registry_digest' not in status and 'recipe_digest' not in status
assert phase.validate(status,recipe)==status
assert phase.select_running(inventory,status,registry_hash,recipe_hash)['container_id']==status['container_id']
for field in ('registry_digest','recipe_digest','container_id'):
    bad=copy.deepcopy(inventory);bad['containers'][0][field]='wrong'
    try:
        phase.select_running(bad,status,registry_hash,recipe_hash)
        raise AssertionError('wrong running proof accepted')
    except RuntimeError:
        pass
for mutate in [lambda s:s.update(container_id='changed'),lambda s:s.update(restart_count=1),lambda s:s['host_memory']['events'].update(oom=1),lambda s:s['host_memory'].pop('peak_bytes')]:
    bad=copy.deepcopy(status);mutate(bad)
    try:
        phase.validate(bad,recipe,status)
        raise AssertionError('invalid status accepted')
    except RuntimeError:
        pass
print('PASS: real retained status omits digests; exact running proof supplies registry+recipe digests; mismatches/OOM rejected')

for interruption in (signal.SIGTERM,signal.SIGINT):
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp);(root/'registry-a.toml').write_bytes(raw)
        driver=f'''
import importlib.util,json,subprocess,sys,time
from pathlib import Path
from types import SimpleNamespace
spec=importlib.util.spec_from_file_location('phase',{str(ROOT/'run-phase.py')!r})
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
p.E=Path({str(root)!r})
status={status!r}
inventory={inventory!r}
def observed(argv,**kwargs):
    return SimpleNamespace(returncode=0,stdout=json.dumps({{'ok':True,'data':inventory if 'running' in argv else status}}))
p.subprocess.run=observed
original=p.subprocess.Popen
def child(*a,**k):
    process=original([sys.executable,'-c','import time;time.sleep(30)'])
    (p.E/'child.pid').write_text(str(process.pid))
    return process
p.subprocess.Popen=child
raise SystemExit(p.main(SimpleNamespace(arm='a',seconds=100,request_deadline_epoch=time.time()+1000,output=p.E/'result',lane='fixed-work',phase='prime',iteration=1)))
'''
        wrapper=subprocess.Popen([sys.executable,'-c',driver],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            until=time.monotonic()+5
            while not (root/'child.pid').exists() and wrapper.poll() is None and time.monotonic()<until:time.sleep(.02)
            assert (root/'child.pid').exists(),wrapper.communicate(timeout=2)
            child_pid=int((root/'child.pid').read_text());wrapper.send_signal(interruption)
            stdout,stderr=wrapper.communicate(timeout=5)
            assert wrapper.returncode==1,(stdout,stderr)
            summary=json.loads((root/'result/summary.json').read_text())
            assert summary['ok'] is False and 'KeyboardInterrupt' in summary['error']
            assert summary['child_returncode'] is not None and (root/'result/running-proof.json').exists()
            try:
                os.kill(child_pid,0);raise AssertionError('owned child survived wrapper cancellation')
            except ProcessLookupError:pass
        finally:
            if wrapper.poll() is None:wrapper.kill();wrapper.wait()
print('PASS: real SIGTERM/SIGINT wrapper cancellation reaps only fixture child and records aborted status after real-schema arm proof')
# Runtime pins are temporary offline fixtures, never an operational v2 placeholder.
with tempfile.TemporaryDirectory() as temp:
    root=Path(temp)
    legacy=phase.runtime_config(root,'a')
    assert legacy['image']==phase.IMAGE and legacy['bytes'] is None
    try:phase.runtime_config(root,'a',True);raise AssertionError('unfrozen legacy audit accepted')
    except ValueError:pass
    fixture_image='sha256:'+'c'*64
    pins={'image':fixture_image,'source_patch_sha256':'b132065b27532028bf2a02e754e86553ea846281f616f22ce74e89442ff0ec76',
        'registries':{arm:str(root/f'registry-v2-{arm}.toml') for arm in 'ab'},
        'audit_registries':{arm:str(root/f'registry-v2-{arm}-audit.toml') for arm in 'ab'}}
    (root/'runtime-pins.json').write_text(json.dumps(pins))
    normal=phase.runtime_config(root,'b');audit=phase.runtime_config(root,'b',True)
    assert normal['registry']==Path(pins['registries']['b']) and audit['registry']==Path(pins['audit_registries']['b'])
    assert normal['image']==fixture_image and normal['bytes']==(root/'runtime-pins.json').read_bytes()
    try:phase.validate(status,recipe,expected_image=fixture_image);raise AssertionError('wrong runtime image accepted')
    except RuntimeError:pass
    simulated=copy.deepcopy(status);simulated['image_id']=fixture_image
    assert phase.validate(simulated,recipe,expected_image=fixture_image)
    pins['image']='unfrozen:latest';(root/'runtime-pins.json').write_text(json.dumps(pins))
    try:phase.runtime_config(root,'a');raise AssertionError('unpinned runtime image accepted')
    except ValueError:pass
phase.verify_audit_mode(recipe,False)
audited=copy.deepcopy(recipe);audited['serve']['flags'].append('--verify-host-cache-transfers')
phase.verify_audit_mode(audited,True)
for config,mode in [(audited,False),(recipe,True)]:
    try:phase.verify_audit_mode(config,mode);raise AssertionError('audit/timing flag mix accepted')
    except ValueError:pass
print('PASS: optional legacy/frozen runtime selection, configured image guard, explicit frozen audit paths and transfer-verify flag separation')
