"""Retained phase schema plus synthetic missing/failure/proof normalization checks."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import normalize as n
from analyze import compare

source=n.E/'pilot-a-correctness-r3'
refs={};issues=[]
rows,summary,ok,identity,started,uncertain=n.phase_artifacts(source,'correctness','measured',3,'A',refs,issues)
assert ok and identity and len(rows)==3,issues
with tempfile.TemporaryDirectory() as temp:
    root=Path(temp);directory=root/'r1-a/decode-c4'
    for name,count in [('warmup',3),('measured',4)]:
        phase=directory/name;shutil.copytree(source,phase)
        plan=json.loads((phase/'http/plan.json').read_text());plan.update(lane='warmup' if name=='warmup' else 'decode-c4',phase='prime' if name=='warmup' else 'measured')
        (phase/'http/plan.json').write_text(json.dumps(plan))
        attempts=[{'case_id':str(i),'phase':'prime' if name=='warmup' else 'measured',
                   'ok':not(name=='measured' and i==2),'speculative_work':None} for i in range(count)]
        (phase/'http/attempts.json').write_text(json.dumps(attempts))
        work={'proposed':4,'accepted':2}
        (phase/'http/summary.json').write_text(json.dumps({'expected':count,'attempted':count,
            'completed':count if name=='warmup' else count-1,'error':None if name=='warmup' else 'retained synthetic request failure',
            'batch_speculative_work':work if name=='measured' else None}))
    config={'repetitions':1,'arm_orders':[['A','B']],'required_acceptance_receipts':['functional','identities','monitoring','restore_fidelity','independent_oracles','causal_chain','restoration'],
            'lanes':{'decode-c4':{'prime_requests':0,'measured_requests':4,'requests_per_arm_rep':4,'role':'protected','metric':'decode_tokens_per_second'}},
            'thresholds':{'primary_min_improvement_percent_each_rep':5,'protected_max_regression_percent_each_rep':3}}
    result=n.normalize(root,config);a,b=result['runs']
    assert result['denominators']=={'expected_requests':8,'attempted_requests':4,'failed_attempts':1,'attempted_count_is_lower_bound':False,'uncertain_target_slots':0}
    assert len(a['attempts'])==4 and a['attempts'][2]['ok'] is False
    assert a['batch_speculative_work']==work and all(row['speculative_work'] is None for row in a['attempts'])
    assert a['receipts']['functional'] is False and a['receipts']['restoration'] is False
    assert a['receipts']['identities'] is True and b['receipts']['identities'] is False
    assert a['order'] is None and result['source_artifacts']
    report=compare(result,config)
    assert report['recommend_candidate'] is False and report['lanes']['decode-c4'][0]['denominators']['A']['failed']==1
    assert report['lanes']['decode-c4'][0]['denominators']['B']['missing']==4
    lost=directory/'measured/http'
    saved=json.loads((lost/'attempts.json').read_text());saved.pop()
    (lost/'attempts.json').write_text(json.dumps(saved))
    (lost/'003-response.json').write_text(json.dumps({'start_ns':123,'error':'synthetic cancellation'}))
    (lost/'004-before.prom').write_text('synthetic-before-only')
    recovered=n.normalize(root,config)
    assert recovered['denominators']['attempted_requests']==4 and recovered['denominators']['failed_attempts']==2
    assert recovered['denominators']['uncertain_target_slots']==1 and recovered['denominators']['attempted_count_is_lower_bound'] is True
    evidence=root/'evidence.json';evidence.write_text('{"observed":true}')
    proof=root/'proof.json';proof.write_text(json.dumps({'schema':'flare-cache-fix-proof/v1','gate':'monitoring','ok':True,
        'checks':{'native_generation_current':True},'evidence':[{'path':str(evidence),'sha256':hashlib.sha256(evidence.read_bytes()).hexdigest()}]}))
    pointer={'path':str(proof),'sha256':hashlib.sha256(proof.read_bytes()).hexdigest()}
    assert n.proof_gate('monitoring',pointer,root,{},[])
    evidence.write_text('{"observed":false}')
    assert not n.proof_gate('monitoring',pointer,root,{},[])
    assert not n.proof_gate('monitoring',None,root,{},[])
missing=n.normalize(Path('/nonexistent-flare-formal-fixture'))
assert len(missing['runs'])==54 and missing['denominators']['expected_requests']==2550
assert missing['denominators']['attempted_requests']==0
print('PASS: retained real phase schema,54 missing runs retain2550 denominator, phase failures/failed requests retained, warmup excluded, C4 batch ownership, hash-bound proofs and missing-proof false')
