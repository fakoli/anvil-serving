"""Exact retained decode bodies; concurrent HTTP only, with batch-owned telemetry."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import time
import urllib.request
import replay as shared

ROOT=Path(__file__).parent

def normalize(index,body_sha256,row):
    ids=row.get('output_token_ids') or [];stamps=row.get('core_token_timestamps_ns') or []
    usage=row.get('usage') or {}
    if (len(ids)!=1024 or not all(type(i) is int and i>=0 for i in ids) or len(stamps)!=1024 or usage.get('completion_tokens')!=1024
            or usage.get('prompt_tokens')!=7037 or row.get('finish_reasons')!=['length']
            or row.get('done') is not True or shared.native_first_token(row) is None
            or stamps[-1]<=stamps[0] or stamps[-1]-(row.get('performance') or {})['ingress_ns']>row['e2e']*1e9):
        raise ValueError('decode1024 native work/timing contract failed')
    reasoning=''.join((choice.get('delta') or {}).get('reasoning_content') or ''
        for packet in row.get('events',[]) for choice in packet['event'].get('choices',[]))
    return {'case_id':str(index),'phase':'measured','ok':True,'body_sha256':body_sha256,
        'prompt_tokens':usage['prompt_tokens'],'usage':usage,'output_token_ids':ids,
        'reasoning_tokens':usage.get('completion_tokens_details',{}).get('reasoning_tokens'),
        'reasoning_span_sha256':hashlib.sha256(reasoning.encode()).hexdigest() if reasoning else None,
        'reasoning_observed_characters':len(reasoning),'speculative_work':None,
        'speculative_work_scope':'batch_only_no_request_attribution',
        'decode_tokens_per_second':1023*1e9/(stamps[-1]-stamps[0]),
        'e2e':row['e2e'],'client_generated_ttft':row.get('client_generated_ttft')}

def run_decode(output,lane,phase,seconds,identity_proof):
    if phase!='measured':raise ValueError('decode contract has measured batch only, no implicit prime')
    contract_raw=(ROOT/'decode-contract.json').read_bytes();contract=json.loads(contract_raw)
    selected=contract['lanes'][lane]['indices'];bodies=[]
    for i in selected:
        ref=contract['bodies'][i];raw=Path(ref['path']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=ref['sha256']:raise ValueError('decode frozen body changed')
        bodies.append((i,raw,json.loads(raw),ref['sha256']))
    output.mkdir(mode=0o700)
    key,identity=shared.prior.read_key(shared.prior.KEY);model=bodies[0][2]['model']
    req=urllib.request.Request(shared.prior.BASE+'/v1/models',headers={'Authorization':'Bearer '+key})
    with urllib.request.urlopen(req,timeout=5) as response:endpoint=json.loads(response.read(1048576))
    shared.prior.protect(endpoint,key);shared.prior.write(output/'identity.json',endpoint)
    if [r['id'] for r in endpoint['data']]!=[model]:raise ValueError('decode endpoint model mismatch')
    allowed={model}
    if identity_proof is not None:allowed.add(shared.proven_source_revision(identity_proof,model))
    shared.prior.write(output/'plan.json',{'lane':lane,'phase':phase,'expected':len(selected),
        'concurrency':len(selected),'contract_sha256':hashlib.sha256(contract_raw).hexdigest(),
        'bodies':[r for r in contract['bodies'] if r['index'] in selected],
        'allowed_sse_model_ids':sorted(allowed),'request_deadline_seconds':60})
    before_raw,before=shared.prior.idle(key);(output/'batch-before.prom').write_text(before_raw)
    deadline=time.monotonic()+min(60,seconds);attempts=[];failure=None;batch_work=None
    def worker(entry):
        i,raw,body,sha=entry
        try:
            row=shared.request(body,key,deadline,output/f'{i:03}-response.json',allowed,raw)
            return normalize(i,sha,row)
        except Exception as error:
            detail=str(error) if key not in str(error) else 'protected error omitted'
            return {'case_id':str(i),'phase':'measured','ok':False,'body_sha256':sha,'error':detail}
    try:
        with ThreadPoolExecutor(len(selected)) as pool:attempts=list(pool.map(worker,bodies))
        if shared.prior.read_key(shared.prior.KEY)[1]!=identity:raise RuntimeError('credential identity changed')
        after_raw,after=shared.prior.idle(key);(output/'batch-after.prom').write_text(after_raw)
        delta={k:after[k]-before[k] for k in shared.prior.COUNTERS}
        if (after['flare_uptime_seconds']<before['flare_uptime_seconds'] or any(v<0 for v in delta.values())
                or delta['flare_requests_completed_total']!=len(selected)
                or any(delta[k] for k in ('flare_requests_cancelled_total','flare_host_cache_store_failed_total','flare_host_cache_fetch_failed_total'))):
            raise RuntimeError('decode batch counter/reset/interference failure')
        batch_work=shared.speculative_delta(before_raw,after_raw)
        if not all(r['ok'] for r in attempts):raise ValueError('decode request contract failure')
        if sum(delta[k] for k in ('flare_prefill_tokens_total','flare_cache_reused_tokens_total','flare_host_cache_reused_tokens_total'))!=sum(r['prompt_tokens'] for r in attempts):
            raise RuntimeError('decode batch prompt accounting mismatch')
    except Exception as error:failure=type(error).__name__+': '+str(error)
    finally:
        shared.prior.write(output/'attempts.json',attempts)
        shared.prior.write(output/'summary.json',{'expected':len(selected),'attempted':len(attempts),
            'completed':sum(r['ok'] for r in attempts),'error':failure,
            'batch_speculative_work':batch_work,'speculative_work_scope':'whole_drained_batch',
            'performance_eligible':False,'matched_work_requires_other_arm':True})
    return failure is None
