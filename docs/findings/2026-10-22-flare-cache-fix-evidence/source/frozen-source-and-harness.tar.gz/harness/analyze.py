"""Offline paired evidence gate. Never contacts a model or controls lifecycle."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

CONFIG = Path(__file__).with_name('prospective.json')
AMENDMENT = Path(__file__).parent.parent/'diagnostic-amendment.json'
MATCH = ('case_id', 'body_sha256', 'prompt_tokens', 'output_token_ids',
         'reasoning_tokens', 'reasoning_span_sha256', 'speculative_work')

def number(value):
    return type(value) in (int, float) and math.isfinite(value) and value > 0

def valid_speculative(work, complete=False):
    if (not isinstance(work,dict) or not {'proposed','accepted'} <= set(work)
            or not all(type(v) is int and v>=0 for v in work.values())
            or work['accepted']>work['proposed']):return False
    if complete:
        families=('rounds','emitted_tokens','offered_drafts','accepted_drafts')
        prefixes=['flare_speculative_'+name+'_total' for name in families]
        support=[{k[len(prefix):] for k in work if k.split('{',1)[0]==prefix} for prefix in prefixes]
        if not support[0] or any(labels!=support[0] for labels in support[1:]):return False
        if work['proposed']!=sum(v for k,v in work.items() if k.split('{',1)[0]==prefixes[2]):return False
        if work['accepted']!=sum(v for k,v in work.items() if k.split('{',1)[0]==prefixes[3]):return False
    return True

def valid_work(row, contract=None):
    ids=row.get('output_token_ids');reason=row.get('reasoning_tokens')
    reason_valid=type(reason) is int and reason>=0
    if contract=='decode1024-batch':
        return (type(row.get('prompt_tokens')) is int and row['prompt_tokens']==7037
            and isinstance(ids,list) and len(ids)==1024
            and all(type(i) is int and i>=0 for i in ids)
            and row.get('usage',{}).get('completion_tokens')==1024
            and (reason_valid or (isinstance(row.get('reasoning_span_sha256'),str)
                                  and len(row['reasoning_span_sha256'])==64))
            and row.get('speculative_work') is None
            and isinstance(row.get('body_sha256'),str) and len(row['body_sha256'])==64)
    return (type(row.get('prompt_tokens')) is int and row['prompt_tokens']>0
        and (reason_valid or (contract in ('fixed1','fixed1_last12_fresh_cache')
            and len(ids or [])==1 and row.get('usage',{}).get('completion_tokens')==1))
        and isinstance(ids,list) and bool(ids) and all(type(i) is int and i>=0 for i in ids)
        and valid_speculative(row.get('speculative_work'))
        and isinstance(row.get('body_sha256'),str) and len(row['body_sha256'])==64)

def compare(data, config=None):
    config = config or json.loads(CONFIG.read_text())
    runs = data.get('runs', [])
    output = {'schema': 'flare-cache-fix-analysis/v1', 'promoted': False,
              'recommend_candidate': False, 'lanes': {}, 'failures': []}
    for lane, plan in config['lanes'].items():
        pairs = []
        for repetition in range(1, config['repetitions'] + 1):
            pair = {'repetition': repetition, 'status': 'incomplete', 'issues': [], 'denominators': {}}
            arms = {};arm_runs = {}
            for arm in ('A', 'B'):
                selected = [r for r in runs if (r.get('lane'), r.get('repetition'), r.get('arm')) == (lane, repetition, arm)]
                if len(selected) != 1:
                    pair['issues'].append(f'{arm}: expected exactly one run, found {len(selected)}')
                    continue
                run = selected[0]
                if run.get('normalization_issues'):
                    pair['issues'].extend(f'{arm}: '+str(issue) for issue in run['normalization_issues'])
                arm_runs[arm]=run
                rows = run.get('attempts', [])
                failed = [r for r in rows if r.get('ok') is not True]
                pair['denominators'][arm] = {'expected': plan['requests_per_arm_rep'],
                    'attempted': len(rows), 'failed': len(failed),
                    'missing': max(0, plan['requests_per_arm_rep'] - len(rows))}
                if failed:
                    output['failures'].append({'lane': lane, 'repetition': repetition, 'arm': arm,
                                              'cases': [r.get('case_id') for r in failed]})
                    pair['status'] = 'failed'
                for phase, count in [('prime', plan['prime_requests']), ('measured', plan['measured_requests'])]:
                    subset = [r for r in rows if r.get('phase') == phase]
                    if len(subset) != count or len({r.get('case_id') for r in subset}) != count:
                        pair['issues'].append(f'{arm}: {phase} count/unique case mismatch')
                if len(rows) != plan['requests_per_arm_rep']:
                    pair['issues'].append(f'{arm}: request denominator mismatch')
                receipts = run.get('receipts', {})
                if any(receipts.get(key) is not True for key in config['required_acceptance_receipts']):
                    pair['issues'].append(f'{arm}: acceptance receipt missing or false')
                if run.get('order') != config['arm_orders'][repetition - 1].index(arm):
                    pair['issues'].append(f'{arm}: prospective arm order mismatch')
                arms[arm] = {r.get('case_id'): r for r in rows if r.get('phase') == 'measured'}
            if plan['role'] == 'descriptive' and len(arms) == 2:
                if set(arms['A']) != set(arms['B']):
                    pair['issues'].append('unmatched diagnostic case populations')
                elif any(arms['A'][k].get('body_sha256') != arms['B'][k].get('body_sha256') for k in arms['A']):
                    pair['issues'].append('diagnostic body mismatch')
                if not pair['issues'] and pair['status'] != 'failed':
                    pair['status'] = 'descriptive'
                    pair['performance_eligible'] = False
                pairs.append(pair)
                continue
            if len(arms) == 2:
                a, b = arms['A'], arms['B']
                contract='decode1024-batch' if lane in ('decode-c1','decode-c4') else plan.get('contract')
                if contract=='decode1024-batch':
                    wa=arm_runs['A'].get('batch_speculative_work');wb=arm_runs['B'].get('batch_speculative_work')
                    if not valid_speculative(wa,True) or not valid_speculative(wb,True) or wa!=wb:
                        pair['issues'].append('missing/unmatched whole-batch speculative work')
                if set(a) != set(b):
                    pair['issues'].append('unmatched case populations')
                elif any(not valid_work(a[k], contract) or not valid_work(b[k], contract)
                         or any(a[k].get(field) != b[k].get(field) for field in MATCH) for k in a):
                    pair['issues'].append('missing/unmatched prompt, output or speculative work')
                elif any(not number(r.get(plan['metric'])) for r in [*a.values(), *b.values()]):
                    pair['issues'].append('missing/invalid metric')
                elif a and not pair['issues'] and pair['status'] != 'failed':
                    av = statistics.median(r[plan['metric']] for r in a.values())
                    bv = statistics.median(r[plan['metric']] for r in b.values())
                    improvement = 100 * ((bv - av) if plan['metric'] == 'decode_tokens_per_second' else (av - bv)) / av
                    pair.update(a_median=av, b_median=bv, improvement_percent=improvement)
                    threshold = (config['thresholds']['primary_min_improvement_percent_each_rep']
                        if plan['role'] == 'primary' else -config['thresholds']['protected_max_regression_percent_each_rep'])
                    pair['status'] = ('descriptive' if plan['role'] == 'descriptive' else
                                      'passed' if improvement >= threshold else 'failed')
            pairs.append(pair)
        output['lanes'][lane] = pairs
    accepted = [p for lane, pairs in output['lanes'].items()
                if config['lanes'][lane]['role'] != 'descriptive' for p in pairs]
    output['recommend_candidate'] = bool(accepted) and all(p['status'] == 'passed' for p in accepted) and not output['failures'] and all(p['status'] in ('passed', 'descriptive') for pairs in output['lanes'].values() for p in pairs)
    # Prospective blockers must be resolved explicitly before accepting real results.
    if config.get('blocked'):
        output['unresolved_prospective_blockers'] = config['blocked']
        output['recommend_candidate'] = False
    output['comparison_gates_passed']=output['recommend_candidate']
    output['diagnostic_only']=bool(data.get('diagnostic_only')) or AMENDMENT.exists()
    if AMENDMENT.exists():
        raw=AMENDMENT.read_bytes()
        amendment=json.loads(raw)
        if amendment.get('schema')!='flare-cache-fix-diagnostic-amendment/v1':
            raise ValueError('unexpected diagnostic amendment schema; acceptance blocked')
        output['diagnostic_amendment']={'path':str(AMENDMENT),'sha256':hashlib.sha256(raw).hexdigest()}
        if data.get('diagnostic_amendment') and data['diagnostic_amendment']!=output['diagnostic_amendment']:
            output['diagnostic_amendment_reference_mismatch']=True
    if output['diagnostic_only']:
        output['recommend_candidate']=False
    output['performance_eligible']=output['recommend_candidate']
    return output

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence', type=Path)
    args = parser.parse_args()
    raw = args.evidence.read_bytes()
    result = compare(json.loads(raw))
    result['input_sha256'] = hashlib.sha256(raw).hexdigest()
    print(json.dumps(result, indent=2, allow_nan=False))
