"""Normalize retained formal phase artifacts; no model calls, lifecycle or fabricated receipts."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tomllib

ROOT=Path(__file__).parent
E=ROOT.parent
spec=importlib.util.spec_from_file_location('phase',ROOT/'run-phase.py')
phase=importlib.util.module_from_spec(spec);spec.loader.exec_module(phase)
sys.path.insert(0,str(phase.WORKTREE))
from anvil_serving.serve_recipes import recipe_digest


def phases(lane,plan):
    target=[]
    if plan['prime_requests']:target.append(('prime',plan['prime_requests']))
    if lane in ('small12','small12-original'):
        target.extend([('measured-1',12),('measured-2',12)])
    else:target.append(('measured',plan['measured_requests']))
    return [('warmup',3),*target]


def read(path,refs,issues):
    try:
        raw=path.read_bytes()
        refs[str(path)]={'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()}
        return json.loads(raw)
    except (OSError,ValueError) as error:
        issues.append(f'{path}: {type(error).__name__}')
        return None


def reference(pointer,base,refs,issues):
    if not isinstance(pointer,dict) or not isinstance(pointer.get('path'),str) or not isinstance(pointer.get('sha256'),str):
        issues.append('missing/malformed evidence reference');return None
    path=Path(pointer['path']);path=path if path.is_absolute() else base/path
    try:
        raw=path.read_bytes();actual=hashlib.sha256(raw).hexdigest()
        refs[str(path)]={'path':str(path),'sha256':actual}
        if actual!=pointer['sha256']:raise ValueError('digest mismatch')
        return path,raw
    except (OSError,ValueError) as error:
        issues.append(f'{path}: {error}');return None


def proof_gate(gate,pointer,base,refs,issues):
    value=reference(pointer,base,refs,issues)
    if value is None:return False
    path,raw=value
    try:
        proof=json.loads(raw);checks=proof.get('checks');evidence=proof.get('evidence')
        valid=(proof.get('synthetic_template') is not True and proof.get('schema')=='flare-cache-fix-proof/v1' and proof.get('gate')==gate
            and proof.get('ok') is True and isinstance(checks,dict) and bool(checks)
            and all(value is True for value in checks.values()) and isinstance(evidence,list) and bool(evidence))
        verified=[reference(item,path.parent,refs,issues) for item in evidence or []]
        return valid and bool(verified) and all(item is not None for item in verified)
    except (ValueError,TypeError,AttributeError) as error:
        issues.append(f'{path}: invalid proof {type(error).__name__}');return False


def phase_artifacts(directory,lane,name,count,arm,refs,issues):
    start_issues=len(issues)
    wrapper=read(directory/'summary.json',refs,issues)
    plan=read(directory/'plan.json',refs,issues)
    http=directory/'http'
    summary=read(http/'summary.json',refs,issues)
    http_plan=read(http/'plan.json',refs,issues)
    attempts=read(http/'attempts.json',refs,issues)
    if not isinstance(attempts,list):attempts=[];issues.append(f'{directory}: attempts unavailable')
    attempts=[row if isinstance(row,dict) else {'case_id':f'malformed-{i}','ok':False,'raw_value':row,
              'normalization_error':'attempt is not an object'} for i,row in enumerate(attempts)]
    expected_phase='prime' if name in ('prime','warmup') else 'measured'
    expected_lane='warmup' if name=='warmup' else lane
    def case_id(path):
        value=str(int(path.name.split('-')[0]))
        return value+':'+name[-1] if lane in ('small12','small12-original') and name.startswith('measured-') else value
    tracked={row.get('case_id') for row in attempts}
    uncertain=[]
    for path in sorted(http.glob('*-response.json')):
        try:
            raw=path.read_bytes()
        except OSError as error:
            issues.append(f'{path}: {error}');continue
        refs[str(path)]={'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()}
        try:
            case=case_id(path)
            if case not in tracked:
                captured=json.loads(raw)
                if type(captured.get('start_ns')) is not int:raise ValueError('request start missing')
                attempts.append({'case_id':case,'phase':expected_phase,'ok':False,
                    'normalization_error':'raw response has no persisted attempt validation','raw_response':refs[str(path)]})
                tracked.add(case)
                issues.append(f'{path}: recovered unvalidated attempted request')
        except (ValueError,AttributeError) as error:issues.append(f'{path}: {error}')
    for path in sorted(http.glob('*-before.prom')):
        try:
            if case_id(path) not in tracked:
                uncertain.append(case_id(path));issues.append(f'{path}: request initiation unknown, not counted as proven attempt')
        except ValueError:issues.append(f'{path}: invalid request index')
    ok=(isinstance(wrapper,dict) and wrapper.get('ok') is True and wrapper.get('audit') is not True
        and isinstance(summary,dict) and summary.get('expected')==count
        and summary.get('attempted')==count and summary.get('completed')==count and not summary.get('error')
        and len(attempts)==count and all(row.get('ok') is True and row.get('phase')==expected_phase for row in attempts)
        and isinstance(http_plan,dict) and http_plan.get('lane')==expected_lane and http_plan.get('phase')==expected_phase)
    identity=None
    try:
        if not isinstance(plan,dict):raise ValueError('phase plan missing')
        if plan.get('arm')!=arm.lower():raise ValueError('phase arm mismatch')
        raw=Path(plan['registry']).read_bytes()
        refs[plan['registry']]={'path':plan['registry'],'sha256':hashlib.sha256(raw).hexdigest()}
        if hashlib.sha256(raw).hexdigest()!=plan['registry_sha256']:raise ValueError('registry changed')
        recipe=tomllib.loads(raw.decode())['recipe'][0]
        status_path=directory/'status.jsonl';status_raw=status_path.read_bytes()
        refs[str(status_path)]={'path':str(status_path),'sha256':hashlib.sha256(status_raw).hexdigest()}
        statuses=[json.loads(line)['status'] for line in status_raw.splitlines() if line]
        if not statuses:raise ValueError('status samples missing')
        previous=None
        for status in statuses:previous=phase.validate(status,recipe,previous,plan.get('expected_image',phase.IMAGE))
        running=read(directory/'running-proof.json',refs,issues)
        if not isinstance(running,dict) or running.get('error'):raise ValueError('running proof missing/failed')
        phase.select_running(running['inventory'],statuses[0],plan['registry_sha256'],recipe_digest(recipe))
        endpoint=read(http/'identity.json',refs,issues)
        if [row['id'] for row in endpoint['data']]!=[recipe['serve']['served_model_name']]:raise ValueError('HTTP alias mismatch')
        identity=tuple(statuses[0].get(key) for key in phase.IDENTITY)
    except Exception as error:
        issues.append(f'{directory}: identity evidence {error}')
    if not ok:issues.append(f'{directory}: wrapper/HTTP phase failed, incomplete or audit-enabled')
    return attempts,summary,ok and len(issues)==start_issues,identity,(plan.get('epoch_ns') if isinstance(plan,dict) else None),uncertain


def normalize(formal,config=None):
    config=config or json.loads((ROOT/'prospective.json').read_text())
    refs={};runs=[];seen={}
    for repetition in range(1,config['repetitions']+1):
        for arm in ('A','B'):
            for lane,plan in config['lanes'].items():
                directory=formal/f'r{repetition}-{arm.lower()}'/lane
                issues=[];attempts=[];identities=[];summaries={};phase_ok=True;start=None;uncertain_slots={}
                for name,count in phases(lane,plan):
                    rows,summary,ok,identity,started,uncertain=phase_artifacts(directory/name,lane,name,count,arm,refs,issues)
                    if name=='warmup':start=started
                    summaries[name]=summary;uncertain_slots[name]=uncertain;phase_ok=phase_ok and ok
                    if identity is not None:identities.append(identity)
                    if name!='warmup':attempts.extend(rows)
                native_identity=bool(identities) and len(identities)==len(phases(lane,plan)) and len(set(identities))==1
                if native_identity:
                    key=identities[0][0]
                    if key in seen:issues.append(f'fresh incarnation reused from {seen[key]}');native_identity=False
                    else:seen[key]=str(directory)
                manifest=read(directory/'proofs.json',refs,issues)
                pointers=manifest.get('proofs',{}) if isinstance(manifest,dict) and manifest.get('schema')=='flare-cache-fix-lane-proofs/v1' else {}
                receipts={gate:False for gate in config['required_acceptance_receipts']}
                for gate in receipts:
                    if gate=='identities':receipts[gate]=native_identity;continue
                    receipts[gate]=proof_gate(gate,pointers.get(gate),directory,refs,issues)
                receipts['functional']=receipts.get('functional',False) and phase_ok
                receipts['monitoring']=receipts.get('monitoring',False) and native_identity and phase_ok
                if (E/'diagnostic-amendment.json').exists():receipts['restore_fidelity']=False
                run={'lane':lane,'repetition':repetition,'arm':arm,
                    'order':None,'start_epoch_ns':start,'attempts':attempts,
                    'receipts':receipts,'phase_summaries':summaries,'normalization_issues':issues,
                    'source_directory':str(directory),'uncertain_attempt_slots':uncertain_slots}
                if lane.startswith('decode-'):
                    measured=summaries.get('measured')
                    run['batch_speculative_work']=measured.get('batch_speculative_work') if isinstance(measured,dict) else None
                runs.append(run)
    for run in runs:
        peer=next(r for r in runs if r['lane']==run['lane'] and r['repetition']==run['repetition'] and r['arm']!=run['arm'])
        first,second=run['start_epoch_ns'],peer['start_epoch_ns']
        if type(first) is int and type(second) is int and first!=second:run['order']=int(first>second)
        else:run['normalization_issues'].append('actual arm order unavailable')
    amendment=E/'diagnostic-amendment.json'
    return {'schema':'flare-cache-fix-normalized/v1','diagnostic_only':True,
        'diagnostic_amendment':{'path':str(amendment),'sha256':hashlib.sha256(amendment.read_bytes()).hexdigest()} if amendment.exists() else None,
        'runs':runs,'source_artifacts':list(refs.values()),
        'denominators':{'expected_requests':sum(p['requests_per_arm_rep'] for p in config['lanes'].values())*2*config['repetitions'],
            'attempted_requests':sum(len(run['attempts']) for run in runs),
            'attempted_count_is_lower_bound':any(slots for run in runs for name,slots in run['uncertain_attempt_slots'].items() if name!='warmup'),
            'uncertain_target_slots':sum(len(slots) for run in runs for name,slots in run['uncertain_attempt_slots'].items() if name!='warmup'),
            'failed_attempts':sum(row.get('ok') is not True for run in runs for row in run['attempts'])}}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('formal',type=Path,nargs='?',default=E/'formal')
    args=parser.parse_args()
    print(json.dumps(normalize(args.formal),indent=2,allow_nan=False))
