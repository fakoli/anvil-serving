"""Small offline synthetic check for deterministic sanitized packaging."""
import gzip
import importlib.util
import json
import tarfile
import tempfile
from pathlib import Path

HERE = Path(__file__).parent
spec = importlib.util.spec_from_file_location("publisher", HERE / "publish-evidence.py")
publisher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(publisher)

def expect_reject(inventory, output):
    try:
        publisher.build(inventory, output)
    except ValueError:
        assert not output.exists()
    else:
        raise AssertionError("expected inventory rejection")

with tempfile.TemporaryDirectory() as root:
    root = Path(root)
    source = root / "source"
    (source / "phase-a").mkdir(parents=True)
    (source / "phase-b").mkdir()
    (source / "phase-a" / "summary.json").write_text('{"container_id":"archive-only-id","host":"primary-node"}\n')
    (source / "phase-b" / "summary.json").write_text('{"container_id":"jsonl-only-id","path":"OPERATOR_PATH_1da67c6461f4/row"}\n')
    (source / "events.jsonl").write_text('{"container_id":"jsonl-only-id"}\n')
    (source / "failure.log").write_text("archive-only-id jsonl-only-id primary-node\n")
    publisher.E = source
    inventory = {"schema": "flare-cache-fix-publication-inventory/v1",
        "campaign": {"id": "primary-node", "promotion_authorized": False},
        "native_evidence_schemas": ["synthetic/v1"], "size_policy": "primary-node",
        "artifacts": [],
        "archives": [{"sources": ["phase-a/summary.json", "phase-b/summary.json", "events.jsonl", "failure.log"],
                      "path": "raw/primary-node-phases.tar.gz", "roles": ["raw-run-evidence", "failures-and-friction"]}],
        "role_overrides": {role: {"status": "not-applicable", "reason": "synthetic primary-node check"}
                           for role in publisher.ROLES if role not in ("raw-run-evidence", "failures-and-friction", "evidence-index")}}
    inventory_path = root / "inventory.json"; inventory_path.write_text(json.dumps(inventory))
    first, second = source / "first", source / "second"
    publisher.build(inventory_path, first); publisher.build(inventory_path, second)
    archive_a = next((first / "raw").glob("*.tar.gz")); archive_b = next((second / "raw").glob("*.tar.gz"))
    assert archive_a.read_bytes() == archive_b.read_bytes()
    with tarfile.open(fileobj=__import__("io").BytesIO(gzip.decompress(archive_a.read_bytes()))) as bundle:
        members = bundle.getnames(); payload = b"".join(bundle.extractfile(name).read() for name in members)
    assert sorted(members) == ["events.jsonl", "failure.log", "phase-a/summary.json", "phase-b/summary.json"]
    assert b"archive-only-id" not in payload and b"jsonl-only-id" not in payload and b"primary-node" not in payload
    manifest = json.loads((first / "artifact-manifest-source.json").read_text())
    assert "primary-node" not in json.dumps(manifest)
    provenance = json.loads((first / "provenance.json").read_text())
    assert len(provenance["files"]) == 4
    assert {item["archive_member"] for item in provenance["files"]} == set(members)
    assert "primary-node" not in json.dumps(provenance)
    bad = root / "bad.json"
    bad.write_text('{"schema":"flare-cache-fix-publication-inventory/v1","campaign":{},"native_evidence_schemas":[],"artifacts":[],"archives":[{"sources":["events.jsonl"],"path":"raw/a.tar.gz","roles":["raw-run-evidence"]}],"role_overrides":{}}')
    (source / "events.jsonl").write_text('{bad json}\n')
    expect_reject(bad, source / "bad-output")
    (source / "events.jsonl").write_text('{"container_id":""}\n')
    expect_reject(bad, source / "empty-id-output")
    (source / "events.jsonl").write_text('{"container_id":"jsonl-only-id"}\n')
    outside = root / "outside"; outside.mkdir(); (outside / "escape.json").write_text("{}")
    (source / "link").symlink_to(outside, target_is_directory=True)
    escaped = dict(inventory); escaped["archives"] = [{"sources": ["link/escape.json"], "path": "raw/a.tar.gz", "roles": ["raw-run-evidence"]}]
    escaped_path = root / "escaped.json"; escaped_path.write_text(json.dumps(escaped))
    expect_reject(escaped_path, source / "escaped-output")
    (source / "output-link").symlink_to(outside, target_is_directory=True)
    expect_reject(inventory_path, source / "output-link" / "bundle")
    for path in (("raw/a.json", "raw/a.json"), ("raw/a.json", "raw/./a.json"),
                 ("raw/a.json", "raw//a.json"), ("raw", "raw/a.json"),
                 ("provenance.json", "provenance.json/child")):
        collision = dict(inventory); collision["archives"] = []; collision["artifacts"] = [
            {"source": "phase-a/summary.json", "path": path[0], "roles": ["raw-run-evidence"]},
            {"source": "phase-b/summary.json", "path": path[1], "roles": ["raw-run-evidence"]}]
        collision_path = root / ("collision-" + path[0].replace("/", "_") + path[1].replace("/", "_") + ".json")
        collision_path.write_text(json.dumps(collision)); expect_reject(collision_path, source / ("reject-" + str(len(path[0])) + str(len(path[1]))))
