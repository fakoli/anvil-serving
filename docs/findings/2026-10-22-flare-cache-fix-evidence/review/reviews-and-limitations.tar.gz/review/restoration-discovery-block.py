for discovery_attempt in range(1,7):
 assert time.time()<read(a/'window.json')['wall_deadline_epoch']
 receipt={'observed_epoch':time.time(),'expected_generation':g,'source':q['engine_discovery']}
 path=a/f'final-discovery-attempt-{discovery_attempt}.json';assert not path.exists()
 try:
  with m.urlopen(q['engine_discovery'],timeout=15) as h:receipt['raw_response']=h.read().decode('utf-8')
  with path.open('x') as f:json.dump(receipt,f,indent=2)
  targets=json.loads(receipt['raw_response'])
  match=(isinstance(targets,list) and len(targets)==1 and targets[0].get('labels',{}).get('registration_generation')==g and targets[0]['labels'].get('model')==sync['model'])
 except Exception as error:
  receipt['error']={'type':type(error).__name__,'message':str(error)};path.write_text(json.dumps(receipt,indent=2)+'\n');match=False
 if match:
  assert time.time()<read(a/'window.json')['wall_deadline_epoch']
  with (a/'final-engine-targets.json').open('x') as f:json.dump(targets,f,indent=2)
  break
 if discovery_attempt==6:raise ValueError('Restored generation not registered after six observations')
 assert time.time()+15<read(a/'window.json')['wall_deadline_epoch']
 time.sleep(15)
