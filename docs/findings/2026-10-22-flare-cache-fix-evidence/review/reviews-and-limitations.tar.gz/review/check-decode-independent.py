"""Independent offline C4 orchestration check; no HTTP or serving operations."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import threading
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'harness'), 'OPERATOR_PATH_cc25b9dd30c4/anvil-serving']
import decode

model = json.loads((ROOT/'harness/decode-bodies/0-body.json').read_text())['model']
row = {'output_token_ids':list(range(1024)), 'core_token_timestamps_ns':[2000+i*1000 for i in range(1024)],
       'usage':{'prompt_tokens':7037,'completion_tokens':1024}, 'performance':{'ingress_ns':100,'enqueue_ns':200},
       'finish_reasons':['length'],'done':True,'e2e':1,
       'events':[{'event':{'choices':[{'delta':{'reasoning_content':'fixture'}}]}}]}

class Endpoint:
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def read(self,*args): return json.dumps({'data':[{'id':model}]}).encode()

def snapshot(after):
    values={k:0 for k in decode.shared.prior.COUNTERS}
    values['flare_uptime_seconds']=10+int(after)
    values['flare_requests_completed_total']=4 if after else 0
    values['flare_prefill_tokens_total']=4*7037 if after else 0
    raw='\n'.join('flare_speculative_'+name+'_total{batch="4",width="2"} '+str(value if after else 0)
                  for name,value in [('rounds',2),('emitted_tokens',4),('offered_drafts',4),('accepted_drafts',2)])
    return raw,values

for fail in (False,True):
    barrier=threading.Barrier(4)
    def request(body,key,deadline,capture,allowed,raw):
        assert json.loads(raw)==body and model in allowed
        barrier.wait(timeout=3)
        if fail and capture.name.startswith('002'): raise ValueError('deliberate fixture failure')
        return copy.deepcopy(row)
    with tempfile.TemporaryDirectory(dir=ROOT/'review',prefix='decode-offline-') as temporary:
        output=Path(temporary)/'result'
        with patch.object(decode.shared.prior,'read_key',return_value=('fixture-credential','fixture-identity')), \
             patch.object(decode.urllib.request,'urlopen',return_value=Endpoint()), \
             patch.object(decode.shared.prior,'idle',side_effect=[snapshot(False),snapshot(True)]), \
             patch.object(decode.shared,'request',side_effect=request):
            assert decode.run_decode(output,'decode-c4','measured',60,None) is not fail
        summary=json.loads((output/'summary.json').read_text())
        attempts=json.loads((output/'attempts.json').read_text())
        assert summary['expected']==summary['attempted']==len(attempts)==4
        assert summary['completed']==(3 if fail else 4)
        assert summary['performance_eligible'] is False
        assert summary['batch_speculative_work']['proposed']==4
        assert all(r.get('speculative_work') is None for r in attempts)
print('PASS independent mocked C4 overlap, exact body forwarding, whole-batch work, all-attempt retention and one-failure denominator')
