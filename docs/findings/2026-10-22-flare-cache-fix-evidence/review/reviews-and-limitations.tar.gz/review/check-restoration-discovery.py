"""Execute the exact retained discovery block with stdlib-only offline fakes."""
import hashlib
import json
from pathlib import Path
import tempfile
import time as real_time
from types import SimpleNamespace

ROOT = Path(__file__).parent.parent
block_path = ROOT / 'review/restoration-discovery-block.py'
block = block_path.read_text()
capture_path = ROOT / 'formal/root-operation-capture.json'
assert block.strip() in json.loads(capture_path.read_text())['sources']['verify_restoration']


class Clock:
    def __init__(self):
        self.now = 100
        self.sleeps = []

    def time(self):
        return self.now

    def sleep(self, seconds):
        self.sleeps.append(seconds)
        self.now += seconds


class Response:
    def __init__(self, raw):
        self.raw = raw

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self):
        return self.raw.encode()


def scenario(actions, deadline=1000):
    clock = Clock()
    calls = []
    def urlopen(url, timeout):
        assert url == 'synthetic-discovery' and timeout == 15
        calls.append((url, timeout))
        item = actions[len(calls)-1]
        if isinstance(item, Exception):
            raise item
        return Response(item)
    with tempfile.TemporaryDirectory() as temporary:
        directory = Path(temporary)
        (directory / 'window.json').write_text(json.dumps({'wall_deadline_epoch': deadline}))
        scope = {'a': directory, 'g': 'expected-generation', 'q': {'engine_discovery': 'synthetic-discovery'},
            'sync': {'model': 'expected-model'}, 'json': json, 'time': clock,
            'm': SimpleNamespace(urlopen=urlopen), 'read': lambda p: json.loads(p.read_text())}
        error = None
        try:
            exec(compile(block, str(block_path), 'exec'), scope)
        except Exception as caught:
            error = caught
        attempts = [json.loads(p.read_text()) for p in sorted(directory.glob('final-discovery-attempt-*.json'))]
        canonical = directory / 'final-engine-targets.json'
        final = json.loads(canonical.read_text()) if canonical.exists() else None
        return error, attempts, final, calls, clock.sleeps


started = real_time.monotonic()
matching = [{'labels': {'registration_generation': 'expected-generation', 'model': 'expected-model'}}]
wrong = [{'labels': {'registration_generation': 'different-generation', 'model': 'expected-model'}}]
match_raw = json.dumps(matching)
results = {}
error, attempts, final, calls, sleeps = scenario(['[]', match_raw])
assert error is None and final == matching and len(attempts) == len(calls) == 2
assert [r['raw_response'] for r in attempts] == ['[]', match_raw] and sleeps == [15]
results['empty_then_matching_retains_both'] = True
error, attempts, final, calls, sleeps = scenario([json.dumps(wrong)] * 6)
assert isinstance(error, ValueError) and 'six observations' in str(error)
assert final is None and len(attempts) == len(calls) == 6 and sleeps == [15] * 5
results['six_mismatched_generations_no_canonical'] = True
error, attempts, final, calls, sleeps = scenario(['{malformed', match_raw])
assert error is None and final == matching and len(attempts) == 2
assert attempts[0]['raw_response'] == '{malformed' and attempts[0]['error']['type'] == 'JSONDecodeError'
results['malformed_raw_retained_then_matching'] = True
error, attempts, final, calls, sleeps = scenario([OSError('synthetic retrieval failure'), match_raw])
assert error is None and final == matching and len(attempts) == 2
assert attempts[0]['error'] == {'type': 'OSError', 'message': 'synthetic retrieval failure'}
assert 'raw_response' not in attempts[0]
results['retrieval_error_retained_then_matching'] = True
error, attempts, final, calls, sleeps = scenario(['[]'], deadline=110)
assert isinstance(error, AssertionError) and final is None and len(attempts) == len(calls) == 1 and not sleeps
results['deadline_blocks_retry_without_canonical'] = True
error, attempts, final, calls, sleeps = scenario([], deadline=100)
assert isinstance(error, AssertionError) and final is None and not attempts and not calls
results['expired_deadline_blocks_retrieval'] = True
print(json.dumps({'ok': True, 'checks': results, 'offline_only': True,
    'source_block_sha256': hashlib.sha256(block_path.read_bytes()).hexdigest(),
    'capture_sha256': hashlib.sha256(capture_path.read_bytes()).hexdigest(),
    'check_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'elapsed_seconds': real_time.monotonic()-started}, indent=2))
