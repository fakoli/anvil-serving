import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location("describe", Path(__file__).with_name("describe.py"))
describe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(describe)

def batch(value):
    labels = '{rank="0"}'
    return {"proposed": value, "accepted": value,
            f"flare_speculative_rounds_total{labels}": 1,
            f"flare_speculative_emitted_tokens_total{labels}": 1,
            f"flare_speculative_offered_drafts_total{labels}": value,
            f"flare_speculative_accepted_drafts_total{labels}": value}

config = {"repetitions": 1, "lanes": {"decode-c1": {"requests_per_arm_rep": 2, "measured_requests": 2, "metric": "e2e", "role": "primary"}}}
data = {"normalization_issues": ["root containment failure"], "runs": [
    {"lane": "decode-c1", "repetition": 1, "arm": "A", "batch_speculative_work": batch(1), "normalization_issues": ["wrapper failure"], "receipts": {"containment": False}, "phase_summaries": {"measured": {"error": "wrapper failure"}}, "attempts": [
        {"case_id": "0", "phase": "measured", "ok": True, "e2e": 2, "body_sha256": "a" * 64, "prompt_tokens": 7037, "output_token_ids": list(range(1024)), "usage": {"completion_tokens": 1024}, "reasoning_tokens": 0, "reasoning_span_sha256": None, "speculative_work": None, "deltas": {"flare_prefill_tokens_total": 3, "flare_cache_reused_tokens_total": 2, "flare_host_cache_reused_tokens_total": 1}},
        {"case_id": "1", "phase": "measured", "ok": False, "e2e": 1}]},
    {"lane": "decode-c1", "repetition": 1, "arm": "B", "batch_speculative_work": batch(2), "attempts": [
        {"case_id": "0", "phase": "measured", "ok": True, "e2e": 1, "body_sha256": "b" * 64, "prompt_tokens": 7037, "output_token_ids": list(range(1024)), "usage": {"completion_tokens": 1024}, "reasoning_tokens": 0, "reasoning_span_sha256": None, "speculative_work": None}]},
]}
result = describe.describe(data, config)
pair = result["lanes"]["decode-c1"]["repetitions"][0]
assert pair["arms"]["A"]["denominators"]["failed"] == 1
assert pair["arms"]["B"]["denominators"]["missing"] == 1
assert pair["pair"]["complete_work_mismatches"] == 2
assert pair["pair"]["observed_percent_delta"] is None
assert pair["arms"]["A"]["phase_sums"]["measured"]["flare_prefill_tokens_total"]["sum"] == 3
assert pair["arms"]["A"]["phase_sums"]["measured"]["flare_host_cache_fetched_total"]["contributing_count"] == 0
assert pair["pair"]["batch_speculative_work"]["equal"] is False
missing_work = {"case_id": "x", "body_sha256": "c" * 64, "prompt_tokens": 1,
                "output_token_ids": [1], "reasoning_tokens": 0, "speculative_work": None}
assert describe.match_case(missing_work, missing_work, None)["complete_work_match"] is False
assert pair["pair"]["cases"][1]["complete_work_match"] is False
assert result["normalized_source_metadata"]["normalization_issues"] == ["root containment failure"]
assert pair["arms"]["A"]["normalized_run_metadata"]["receipts"]["containment"] is False
without_batches = {"runs": [dict(run, batch_speculative_work=None) for run in data["runs"]]}
assert describe.describe(without_batches, config)["lanes"]["decode-c1"]["repetitions"][0]["pair"]["complete_work_matches"] == 0
assert result["recommend_candidate"] is False
