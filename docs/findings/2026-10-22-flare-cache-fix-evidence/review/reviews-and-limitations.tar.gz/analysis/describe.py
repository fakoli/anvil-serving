"""Offline descriptive summary for a completed normalized matrix; never accepts a candidate."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).parent.parent
HARNESS = ROOT / "harness"
spec = importlib.util.spec_from_file_location("flare_analyze", HARNESS / "analyze.py")
analyze = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analyze)


def p95(values):
    values = sorted(values)
    return values[math.ceil(len(values) * .95) - 1]


def metric_summary(rows, metric):
    values = [row.get(metric) for row in rows if analyze.number(row.get(metric))]
    return {"population": "all measured rows, including failed requests", "valid_count": len(values), "median": statistics.median(values) if values else None,
            "p95_nearest_rank": p95(values) if values else None}


DELTA_FIELDS = ("flare_prefill_tokens_total", "flare_generated_tokens_total",
                "flare_cache_reused_tokens_total", "flare_host_cache_reused_tokens_total",
                "flare_host_cache_fetched_total", "flare_host_cache_store_failed_total",
                "flare_host_cache_fetch_failed_total")


def phase_sums(rows):
    result = {}
    for phase in sorted({str(row.get("phase", "unknown")) for row in rows}):
        selected = [row for row in rows if str(row.get("phase", "unknown")) == phase]
        sums = {}
        for field in DELTA_FIELDS:
            values = [row.get("deltas", {}).get(field) for row in selected
                      if isinstance(row.get("deltas"), dict)]
            values = [value for value in values if type(value) in (int, float) and math.isfinite(value)]
            sums[field] = {"sum": sum(values) if values else None,
                           "contributing_count": len(values), "expected_count": len(selected)}
        result[phase] = sums
    return result


def attempts(rows, plan):
    measured = [row for row in rows if str(row.get("phase", "")).startswith("measured")]
    failed = [row for row in rows if row.get("ok") is not True]
    return {
        "expected": plan["requests_per_arm_rep"], "attempted": len(rows),
        "failed": len(failed), "missing": max(0, plan["requests_per_arm_rep"] - len(rows)),
        "measured": {"expected": plan["measured_requests"], "attempted": len(measured),
                     "failed": sum(row.get("ok") is not True for row in measured),
                     "missing": max(0, plan["measured_requests"] - len(measured))},
    }, measured


def match_case(left, right, contract):
    if left is None or right is None:
        return {"output_equal": False, "complete_work_match": False,
                "mismatch_fields": ["missing_arm_case"],
                "invalid_reasons": []}
    invalid = []
    for arm, row in (("A", left), ("B", right)):
        if row.get("ok") is not True:
            invalid.append(f"request_not_successful_{arm}")
        if not analyze.valid_work(row, contract):
            invalid.append(f"invalid_work_{arm}")
    mismatches = [field for field in analyze.MATCH if left.get(field) != right.get(field)]
    output = left.get("output_token_ids")
    output_equal = (isinstance(output, list) and bool(output)
                    and all(type(token) is int and token >= 0 for token in output)
                    and output == right.get("output_token_ids"))
    return {"output_equal": output_equal,
            "complete_work_match": not invalid and not mismatches,
            "mismatch_fields": mismatches, "invalid_reasons": invalid}


def descriptive_coverage(rows):
    fields = ("e2e", "visible_ttft", "reasoning_ttft", "client_generated_ttft")
    return {field: {"available_count": sum(analyze.number(row.get(field)) for row in rows),
                    "expected_count": len(rows),
                    "by_case": [{"case_id": row.get("case_id"), "value": row.get(field)} for row in rows]}
            for field in fields}


def pair_summary(a, b, metric, expected, contract, batch_a, batch_b):
    a_rows = {row.get("case_id"): row for row in a}
    b_rows = {row.get("case_id"): row for row in b}
    cases = []
    for case_id in sorted(set(a_rows) | set(b_rows), key=str):
        left, right = a_rows.get(case_id), b_rows.get(case_id)
        matched = match_case(left, right, contract)
        cases.append({"case_id": case_id, **matched})
    same_cases = set(a_rows) == set(b_rows)
    complete = (same_cases and len(a) == expected and len(b) == expected and len(a_rows) == expected and len(b_rows) == expected)
    metrics = [row.get(metric) for row in [*a, *b]]
    valid = complete and not any(row.get("ok") is not True for row in [*a, *b]) and all(analyze.number(value) for value in metrics)
    delta = None
    if valid:
        av = metric_summary(a, metric)["median"]
        bv = metric_summary(b, metric)["median"]
        delta = 100 * ((bv - av) if metric == "decode_tokens_per_second" else (av - bv)) / av
    batch = None
    batch_equal = True
    if contract == "decode1024-batch":
        batch = {"A": batch_a, "B": batch_b,
                 "A_valid": analyze.valid_speculative(batch_a, True),
                 "B_valid": analyze.valid_speculative(batch_b, True)}
        batch["equal"] = batch["A_valid"] and batch["B_valid"] and batch_a == batch_b
        batch_equal = batch["equal"]
    complete_matches = sum(case["complete_work_match"] for case in cases) if batch_equal else 0
    return {"output_equal_cases": sum(case["output_equal"] for case in cases),
            "output_unequal_cases": len(cases) - sum(case["output_equal"] for case in cases),
            "complete_work_matches": complete_matches,
            "complete_work_mismatches": len(cases) - complete_matches,
            "cases": cases, "observed_percent_delta": delta,
            "observed_percent_delta_reason": None if delta is not None else "requires identical complete measured case populations, finite metrics, and no failed measured requests",
            "batch_speculative_work": batch}


def describe(data, config):
    result = {"schema": "flare-cache-fix-descriptive/v1", "diagnostic_only": True,
              "performance_eligible": False, "recommend_candidate": False,
              "numerical_gate": "failed", "p95_method": "nearest-rank ceil(0.95*n)", "lanes": {},
              "normalized_source_metadata": {"normalization_issues": data.get("normalization_issues", []),
                                               "denominators": data.get("denominators"),
                                               "diagnostic_amendment": data.get("diagnostic_amendment")}}
    runs = data.get("runs", [])
    for lane, plan in config["lanes"].items():
        repetitions = []
        for repetition in range(1, config["repetitions"] + 1):
            arms, measured = {}, {}
            selected_runs = {}
            for arm in ("A", "B"):
                selected = [run for run in runs if (run.get("lane"), run.get("repetition"), run.get("arm")) == (lane, repetition, arm)]
                rows = selected[0].get("attempts", []) if len(selected) == 1 else []
                counts, arm_measured = attempts(rows, plan)
                arms[arm] = {"run_count": len(selected), "denominators": counts,
                             "metrics": metric_summary(arm_measured, plan["metric"]),
                             "phase_sums": phase_sums(rows)}
                if len(selected) != 1:
                    arms[arm]["selection_issues"] = [f"expected exactly one normalized run, found {len(selected)}"]
                else:
                    arms[arm]["normalized_run_metadata"] = {
                        "normalization_issues": selected[0].get("normalization_issues", []),
                        "receipts": selected[0].get("receipts", {}),
                        "phase_summaries": selected[0].get("phase_summaries", {})}
                if plan["role"] == "descriptive":
                    arms[arm]["descriptive_coverage"] = descriptive_coverage(arm_measured)
                measured[arm] = arm_measured
                selected_runs[arm] = selected[0] if len(selected) == 1 else {}
            contract = "decode1024-batch" if lane.startswith("decode-") else plan.get("contract")
            repetitions.append({"repetition": repetition, "arms": arms,
                                "pair": pair_summary(measured["A"], measured["B"], plan["metric"], plan["measured_requests"], contract,
                                                     selected_runs["A"].get("batch_speculative_work"), selected_runs["B"].get("batch_speculative_work"))})
        result["lanes"][lane] = {"metric": plan["metric"], "role": plan["role"], "repetitions": repetitions}
    result["decode_work_scope"] = "decode speculative work is a whole-batch vector and is never attributed per request"
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("normalized_matrix", type=Path)
    parser.add_argument("--config", type=Path, default=HARNESS / "prospective.json")
    args = parser.parse_args()
    raw, config_raw = args.normalized_matrix.read_bytes(), args.config.read_bytes()
    output = describe(json.loads(raw), json.loads(config_raw))
    output["input_sha256"] = hashlib.sha256(raw).hexdigest()
    output["config_sha256"] = hashlib.sha256(config_raw).hexdigest()
    print(json.dumps(output, indent=2, allow_nan=False))
