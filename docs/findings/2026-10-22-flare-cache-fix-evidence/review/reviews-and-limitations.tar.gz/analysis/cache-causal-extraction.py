"""Fixed-work cache observations only; no latency calculation or causal verdict."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path

E = Path(__file__).resolve().parent.parent
PREFIX = 'flare_host_cache_memory_'
METRICS = [PREFIX + suffix for suffix in ('rows', 'pages', 'free_rows', 'free_pages',
    'row_pressure_total', 'page_pressure_total', 'evicted_records_total')]
ADMISSION = 'flare_host_cache_admission_'
EXACT = {ADMISSION+'raw_lookup_match_total': 1, ADMISSION+'cost_rejected_total': 0,
    ADMISSION+'capacity_rejected_total': 0, ADMISSION+'fetch_admitted_total': 1,
    ADMISSION+'fetch_failed_total': 0, 'flare_host_cache_fetch_failed_total': 0,
    'flare_host_cache_store_failed_total': 0, 'flare_host_cache_fetched_total': 1,
    'flare_requests_completed_total': 1, 'flare_requests_cancelled_total': 0,
    'flare_requests_failed_total': 0}
IDLE = ('flare_active_requests', 'flare_pending_requests', 'flare_retiring_request_slots',
    'flare_host_cache_outbound_in_flight', 'flare_host_cache_inbound_in_flight',
    'flare_host_cache_inbound_waiting')
TOKENS = ('flare_cache_reused_tokens_total', 'flare_host_cache_reused_tokens_total',
          'flare_prefill_tokens_total')


def scalars(raw):
    # Same scalar-only parsing pattern as the frozen serial replay; reject ambiguity.
    result = {}
    for line in raw.splitlines():
        if line and not line.startswith('#') and '{' not in line.split()[0]:
            key, value = line.split()[:2]
            if key in result: raise ValueError('duplicate scalar metric: '+key)
            value = float(value)
            if not math.isfinite(value): raise ValueError('nonfinite scalar: '+key)
            result[key] = value
    return result


def eligibility(before, after, attempt, raw):
    names = set(EXACT) | set(TOKENS) | {'flare_host_cache_stored_total', 'flare_generated_tokens_total'}
    missing = sorted(names - (before.keys() & after.keys()))
    delta = {k: after[k]-before[k] for k in sorted(names) if k in before and k in after}
    checks = {'required_counters_present': not missing}
    checks.update({k+'='+str(v): delta.get(k) == v for k,v in EXACT.items()})
    checks['positive_host_extension'] = delta.get(TOKENS[1], 0) > 0
    checks['idle_before_after'] = all(before.get(k) == after.get(k) == 0 for k in IDLE)
    checks['no_counter_reset'] = (all(v >= 0 for v in delta.values())
        and 'flare_uptime_seconds' in before and after.get('flare_uptime_seconds', -1) >= before['flare_uptime_seconds'])
    usage = attempt.get('usage') or {}
    checks['native_output_ok'] = (attempt.get('ok') is True and not attempt.get('error')
        and raw.get('done') is True and not raw.get('error')
        and raw.get('usage') == usage and len(attempt.get('output_token_ids', [])) == 1
        and raw.get('output_token_ids') == attempt.get('output_token_ids')
        and usage.get('completion_tokens') == 1 and delta.get('flare_generated_tokens_total') == 1
        and bool(raw.get('finish_reasons')) and set(raw['finish_reasons']) <= {'stop','length'}
        and raw.get('finish_reasons') == attempt.get('finish_reasons'))
    checks['prompt_segment_accounting'] = (all(k in delta for k in TOKENS)
        and sum(delta[k] for k in TOKENS) == attempt.get('prompt_tokens') == usage.get('prompt_tokens'))
    recorded = attempt.get('deltas') or {}
    disagreement = sorted(k for k in delta if k in recorded and recorded[k] != delta[k])
    checks['retained_delta_consistency'] = not disagreement
    return {'eligible': all(checks.values()), 'checks': checks,
        'noneligible_categories': [k for k,v in checks.items() if not v], 'raw_deltas': delta,
        'missing_raw_counters': missing, 'admission_fields_absent_from_attempt_deltas':
            sorted(k for k in EXACT if k.startswith(ADMISSION) and k not in recorded),
        'recorded_delta_disagreements': disagreement}


class Inputs:
    def __init__(self): self.refs = {}; self.cache = {}
    def raw(self, path):
        path = Path(path)
        if path not in self.cache:
            raw = path.read_bytes(); self.cache[path] = raw
            self.refs[str(path.relative_to(E))] = {'path': str(path.relative_to(E)),
                'sha256': hashlib.sha256(raw).hexdigest()}
        return self.cache[path]
    def json(self, path): return json.loads(self.raw(path))
    def prom(self, path): return scalars(self.raw(path).decode())


def sampled_series(data, generation, start, end):
    output = {}; issues = []
    if data.get('status') != 'success' or data.get('data', {}).get('resultType') != 'matrix':
        issues.append('engine range query not successful matrix')
    rows = data.get('data', {}).get('result', [])
    for metric in METRICS:
        selected = [r for r in rows if r.get('metric', {}).get('__name__') == metric
                    and r['metric'].get('registration_generation') == generation]
        if len(selected) != 1:
            issues.append(metric+': exact-generation series count '+str(len(selected)))
            output[metric] = {'complete': False, 'series': selected}; continue
        row = selected[0]; samples = [[float(t),float(v)] for t,v in row['values']]
        valid = bool(samples) and all(math.isfinite(t) and math.isfinite(v) for t,v in samples)
        valid = valid and all(a[0] < b[0] for a,b in zip(samples,samples[1:]))
        valid = valid and all(start <= t <= end for t,_ in samples)
        if not valid:
            issues.append(metric+': invalid samples');output[metric]={'complete':False,'series':[row]};continue
        values = [v for _,v in samples]
        output[metric] = {'complete': True, 'labels': row['metric'], 'sample_count': len(samples),
            'first_epoch': samples[0][0], 'last_epoch': samples[-1][0], 'baseline': values[0],
            'final': values[-1], 'min': min(values), 'max': max(values), 'sampled_delta': values[-1]-values[0],
            'samples': samples, 'counter_reset_observed': metric.endswith('_total') and any(b<a for a,b in zip(values,values[1:]))}
    return output, issues


def extract():
    inputs = Inputs()
    for relative in ['analysis/cache-causal-extraction.py','analysis/final-causal-procedure.md',
        'review/cache-counter-semantics.md','harness/prospective.json','candidate-freeze.json',
        'geometry.json','runtime-pins.json','harness/normalize.py','harness/analyze.py']:
        inputs.raw(E/relative)
    config = inputs.json(E/'harness/prospective.json')
    fixed = config['fixed1_bodies']; body_path = Path(fixed['path'])
    body_raw = inputs.raw(body_path)
    assert hashlib.sha256(body_raw).hexdigest() == fixed['sha256'], 'frozen fixed1 corpus changed'
    bodies = json.loads(body_raw); arms = []
    for repetition in range(1,4):
        for arm in ('a','b'):
            directory = E/'formal'/f'r{repetition}-{arm}'; lane = directory/'fixed-work'
            inputs.json(directory/'closeout.json')
            for name in ['window.json','frozen-inputs.sha256']:
                inputs.raw(directory/name)
            for name in ['proofs.json','functional.json','monitoring.json','causal_chain.json',
                         'independent_oracles.json','restore_fidelity.json','registration-generation.txt']:
                inputs.raw(lane/name)
            indexes = inputs.json(lane/'proofs.json')
            for pointer in indexes['proofs'].values():
                path = Path(pointer['path']);path = path if path.is_absolute() else lane/path
                assert hashlib.sha256(inputs.raw(path)).hexdigest() == pointer['sha256'], 'proof input hash mismatch'
            for phase in ['warmup','prime','measured']:
                phase_dir = lane/phase
                for name in ['plan.json','summary.json','status.jsonl','running-proof.json',
                             'http/plan.json','http/summary.json','http/identity.json','http/attempts.json']:
                    inputs.raw(phase_dir/name)
                plan = inputs.json(phase_dir/'plan.json')
                registry = Path(plan['registry'])
                assert hashlib.sha256(inputs.raw(registry)).hexdigest() == plan['registry_sha256']
            generation = inputs.raw(lane/'registration-generation.txt').decode().strip()
            manifest = inputs.json(lane/'query-ranges/manifest.json')
            assert manifest['generation'] == generation
            inputs.json(lane/'query-ranges/queries-manifest.json')
            ranges, issues = sampled_series(inputs.json(lane/'query-ranges/engine.json'),generation,
                                           manifest['start_epoch'], manifest['end_epoch'])
            attempts = inputs.json(lane/'measured/http/attempts.json')
            expected = [str(i) for i in range(51,-1,-1)]
            actual = [r.get('case_id') for r in attempts]
            denominator_ok = len(attempts)==52 and actual==expected
            categories = Counter(); requests = []
            for case in expected:
                matches = [r for r in attempts if r.get('case_id') == case]
                if len(matches) != 1:
                    row = {'eligible':False,'noneligible_categories':['missing_or_duplicate_attempt'],
                           'matching_attempt_count':len(matches)}
                else:
                    attempt = matches[0]; index = int(case)
                    try:
                        raw = inputs.json(lane/'measured/http'/f'{index:03}-response.json')
                        before = inputs.prom(lane/'measured/http'/f'{index:03}-before.prom')
                        after = inputs.prom(lane/'measured/http'/f'{index:03}-after.prom')
                        row = eligibility(before, after, attempt, raw)
                        body_ok = attempt.get('body_sha256') == hashlib.sha256(json.dumps(bodies[index]).encode()).hexdigest()
                        row['checks']['frozen_body_and_phase'] = body_ok and attempt.get('phase')=='measured'
                        if not row['checks']['frozen_body_and_phase']:
                            row['eligible']=False;row['noneligible_categories'].append('frozen_body_and_phase')
                    except (OSError, ValueError, KeyError, TypeError) as error:
                        row = {'eligible':False,'noneligible_categories':['missing_or_invalid_raw_evidence'],
                               'error':type(error).__name__+': '+str(error)}
                if not denominator_ok:
                    row['eligible']=False;row['noneligible_categories'].append('measured_denominator_or_order')
                categories.update(row['noneligible_categories']);requests.append({'case_id':case,**row})
            prime = inputs.json(lane/'prime/http/attempts.json')
            assert [r['case_id'] for r in prime] == [str(i) for i in range(52)]
            first = lane/'prime/http/000-before.prom'; last = lane/'measured/http/000-after.prom'
            before,after = inputs.prom(first),inputs.prom(last)
            aggregate_metrics = METRICS+list(EXACT)+list(TOKENS)+['flare_host_cache_stored_total','flare_generated_tokens_total']
            aggregate = {k:{'baseline':before.get(k),'final':after.get(k),
                'delta':after[k]-before[k] if k in before and k in after else None,
                'scope':'counter delta' if k.endswith('_total') else 'gauge endpoint difference'} for k in dict.fromkeys(aggregate_metrics)}
            arms.append({'repetition':repetition,'arm':arm.upper(),'lane':'fixed-work','generation':generation,
                'sampled_range':{'manifest':manifest,'metrics':ranges,'issues':issues,
                    'scope':'retained scrape samples only; not continuous pressure observation'},
                'phase_aggregate':{'from':str(first.relative_to(E)),'through':str(last.relative_to(E)),
                    'scope':'prime52 plus measured52; preceding warmup excluded','metrics':aggregate},
                'measured_requests':{'expected':52,'retained_rows':len(attempts),'denominator_and_order_ok':denominator_ok,
                    'unexpected_case_ids':[c for c in actual if c not in expected],
                    'eligible_count':sum(r['eligible'] for r in requests),'noneligible_categories':dict(sorted(categories.items())),
                    'rows':requests}})
    return {'schema':'flare-cache-fix-cache-causal-observations/v1','scope':'offline fixed-work cache observations; causal judgment deferred',
        'diagnostic_only':True,'performance_eligible':False,'promoted':False,
        'semantics':['GPU-ready admission reuse plus host admission extension plus successful completed prefill partition a clean serial prompt.',
                     'Neither admission reuse nor completed fetch alone proves exclusive historical origin or numerical fidelity.',
                     'No concurrent decode attribution, latency calculation or causal/performance verdict is made.'],
        'expected_measured_requests':312,'arms':arms,'source_artifacts':[inputs.refs[k] for k in sorted(inputs.refs)]}


def self_check():
    before = {k:0 for k in set(EXACT)|set(TOKENS)|set(IDLE)|{'flare_uptime_seconds','flare_host_cache_stored_total','flare_generated_tokens_total'}}
    after = dict(before); after.update(EXACT); after.update({TOKENS[0]:128,TOKENS[1]:384,TOKENS[2]:288,'flare_generated_tokens_total':1})
    attempt = {'ok':True,'prompt_tokens':800,'usage':{'prompt_tokens':800,'completion_tokens':1},
               'output_token_ids':[1],'finish_reasons':['length'],'deltas':{}}
    raw = {'done':True,'usage':attempt['usage'],'output_token_ids':[1],'finish_reasons':['length']}
    assert eligibility(before,after,attempt,raw)['eligible']
    assert len(eligibility(before,after,attempt,raw)['admission_fields_absent_from_attempt_deltas'])==5
    for key,value in [(ADMISSION+'raw_lookup_match_total',2),(ADMISSION+'capacity_rejected_total',1),
                      ('flare_host_cache_fetched_total',0),('flare_host_cache_inbound_waiting',1),
                      (TOKENS[2],287)]:
        bad=dict(after);bad[key]=value;assert not eligibility(before,bad,attempt,raw)['eligible']
    assert not eligibility(before,after,{**attempt,'ok':False},raw)['eligible']
    data={'status':'success','data':{'resultType':'matrix','result':[{'metric':{'__name__':m,
          'registration_generation':'g'},'values':[[1,'2'],[2,'4']]} for m in METRICS]}}
    selected,issues=sampled_series(data,'g',1,2);assert not issues and all(r['sampled_delta']==2 for r in selected.values())
    assert sampled_series(data,'wrong',1,2)[1]
    print('PASS: clean serial eligibility, omitted admission deltas, rejection/fetch/idle/output/accounting failures, exact-generation sampled summaries')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--self-check',action='store_true');args=parser.parse_args()
    if args.self_check:self_check()
    else:
        output=E/'analysis/cache-causal-observations.json'
        if output.exists():raise FileExistsError('refusing to overwrite '+str(output))
        result=extract()
        with output.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
        print(json.dumps({'arms':len(result['arms']),'expected_measured_requests':312,
            'eligible':{f"r{r['repetition']}-{r['arm'].lower()}":r['measured_requests']['eligible_count'] for r in result['arms']}}))
