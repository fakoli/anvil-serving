"""Collect retained Prometheus evidence for a closed formal arm; never starts traffic."""
import argparse
import hashlib
import importlib.util
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen


E = Path(__file__).resolve().parents[1]
LANES = ("original-reverse", "original-forward", "small12", "fixed-work", "pageheavy",
         "cold", "decode-c1", "decode-c4", "small12-original")
RANGE_KEYS = ("engine", "gpu_and_host", "identity", "collection_freshness")
RANGE_FILES = {*(f"{key}.json" for key in RANGE_KEYS), "manifest.json", "queries-manifest.json"}


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def response(url, params):
    with urlopen(url + "?" + urlencode(params), timeout=30) as handle:
        return json.loads(handle.read())


def query(url, expression, epoch):
    return response(url + "/api/v1/query", {"query": expression, "time": repr(epoch)})


def query_range(url, expression, start, end):
    return response(url + "/api/v1/query_range", {"query": expression, "start": start, "end": end, "step": "15s"})


def readiness_expressions(queries, generation):
    up = queries["identity"].replace("GENERATION", generation)
    return {"up": up, "scrape_count": f"count_over_time({up}[45s])",
            "scrape_min": f"min_over_time({up}[45s])", "sample_age": f"time()-timestamp({up})",
            "collection_freshness": queries["collection_freshness"]}


def validate_readiness(proof, expressions, epoch, generation):
    spec = importlib.util.spec_from_file_location("approved_proof_assembler", E / "analysis" / "assemble-proofs.py")
    assembler = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(assembler)
    if not assembler.historical_values(proof, expressions, epoch, generation):
        raise ValueError("historical readiness values do not meet the approved contract")


def result_value(receipt):
    rows = receipt["data"]["result"]
    if receipt.get("status") != "success" or len(rows) != 1:
        raise ValueError("monitor receipt is not one successful vector")
    return rows[0]["value"]


def arm_identity(arm_dir):
    name = arm_dir.name
    if len(name) != 4 or name[0] != "r" or name[2] != "-" or name[3] not in "ab":
        raise ValueError("arm directory must be formal/rN-a or formal/rN-b")
    return int(name[1]), name[3]


def retained_up(directory, index):
    candidates = [directory / f"up-{index}.json", directory / f"monitor-up-{index}.json"]
    existing = [path for path in candidates if path.is_file()]
    if len(existing) != 1:
        raise ValueError("need exactly one retained up receipt for sample " + str(index) + ": " + str(directory))
    return existing[0]


def lane_inputs(arm_dir, lane):
    directory = arm_dir / lane
    if not (directory / "lane-complete.json").is_file():
        raise ValueError("closed arm lacks lane-complete: " + lane)
    generation_paths = [path for path in (directory / "generation.txt", directory / "registration-generation.txt") if path.is_file()]
    values = [path.read_text().strip() for path in generation_paths]
    if not values or len(set(values)) != 1:
        raise ValueError("missing or disagreeing lane generation: " + lane)
    generation = values[0]
    if not generation:
        raise ValueError("empty lane generation: " + lane)
    warmup = read(directory / "warmup" / "plan.json")
    epoch = warmup["epoch_ns"] / 1e9
    summaries = list(directory.glob("*/summary.json"))
    if not summaries:
        raise ValueError("missing wrapper summaries: " + lane)
    retained_up(directory, 1)
    retained_up(directory, 2)
    end = max(read(path)["epoch_ns"] / 1e9 for path in summaries)
    return directory, generation, epoch, math.floor(epoch) - 30, math.ceil(end) + 15


def validate_existing_range(ranges, generation, start, end):
    if not ranges.is_dir() or {path.name for path in ranges.iterdir()} != RANGE_FILES:
        raise ValueError("existing query-ranges is incomplete or ambiguous")
    manifest = read(ranges / "manifest.json")
    if manifest.get("generation") != generation or manifest.get("start_epoch") != start or manifest.get("end_epoch") != end or manifest.get("keys") != list(RANGE_KEYS):
        raise ValueError("existing query-ranges manifest mismatch")
    for key in RANGE_KEYS:
        raw = read(ranges / f"{key}.json")
        if raw.get("status") != "success" or not raw.get("data", {}).get("result"):
            raise ValueError("existing query-ranges response incomplete")


def validate_existing_history(path, lane, generation, epoch, repetition, arm, queries):
    proof = read(path)
    if (proof.get("schema") != "flare-cache-fix-historical-readiness/v1" or proof.get("lane") != lane
            or proof.get("generation") != generation or proof.get("traffic_plan_epoch") != epoch
            or proof.get("repetition") != repetition or proof.get("arm") != arm
            or "retrospective" not in proof.get("kind", "")):
        raise ValueError("existing readiness history mismatch")
    validate_readiness(proof, readiness_expressions(queries, generation), epoch, generation)


def planned_outputs(arm_dir, queries):
    repetition, arm = arm_identity(arm_dir)
    history = E / "analysis" / "readiness-history" / arm_dir.name
    planned, actions = [], {}
    for lane in LANES:
        directory, generation, epoch, start, end = lane_inputs(arm_dir, lane)
        ranges = directory / "query-ranges"
        if ranges.exists():
            validate_existing_range(ranges, generation, start, end)
            ranges_missing = False
        else:
            ranges_missing = True
            planned.extend([ranges / f"{key}.json" for key in RANGE_KEYS] + [ranges / "manifest.json", ranges / "queries-manifest.json"])
        samples = directory / "monitoring-samples.jsonl"
        if samples.exists():
            rows = [json.loads(line) for line in samples.read_text().splitlines() if line]
            if len(rows) != 2 or any(row.get("generation") != generation for row in rows):
                raise ValueError("existing monitoring samples are incomplete or ambiguous")
            samples_missing = False
        else:
            samples_missing = True
            planned.append(directory / "monitoring-samples.jsonl")
        history_path = history / f"{lane}.json"
        if history_path.exists():
            validate_existing_history(history_path, lane, generation, epoch, repetition, arm, queries)
            history_missing = False
        else:
            history_missing = True
            planned.append(history_path)
        actions[lane] = (ranges_missing, samples_missing, history_missing)
    final_gen = arm_dir / "final-incumbent-generation.txt"
    final_up2 = arm_dir / "final-monitor-up-2.json"
    if final_gen.is_file() and final_up2.is_file():
        generation = final_gen.read_text().strip()
        epoch, _ = result_value(read(final_up2))
        restoration = history / "restoration.json"
        if restoration.exists():
            proof = read(restoration)
            if (proof.get("purpose") != "incumbent-restoration" or proof.get("generation") != generation
                    or proof.get("verification_epoch") != epoch or proof.get("repetition") != repetition
                    or proof.get("arm") != arm):
                raise ValueError("existing restoration readiness mismatch")
            validate_readiness(proof, readiness_expressions(queries, generation), epoch, generation)
        else:
            planned.append(restoration)
    if any(path.exists() for path in planned):
        raise ValueError("refusing to overwrite retained monitoring output")
    return repetition, arm, history, actions


def collect_lane(arm_dir, lane, queries, endpoint, history, repetition, arm, action):
    directory, generation, warmup_epoch, start, end = lane_inputs(arm_dir, lane)
    ranges_missing, samples_missing, history_missing = action
    readiness = {}
    expressions = readiness_expressions(queries, generation)
    proof = {"schema": "flare-cache-fix-historical-readiness/v1", "lane": lane, "arm": arm,
             "repetition": repetition, "generation": generation, "traffic_plan_epoch": warmup_epoch,
             "retrieved_utc": datetime.now(timezone.utc).isoformat(),
             "kind": "read-only retrospective Prometheus query; no new model request", "queries": readiness}
    if history_missing:
        try:
            for key, expression in expressions.items():
                readiness[key] = {"query": expression, "evaluation_epoch": warmup_epoch,
                                  "response": query(endpoint, expression, warmup_epoch)}
        except Exception as error:
            proof["collection_error"] = {"type": type(error).__name__, "message": str(error)}
            history.mkdir(parents=True, exist_ok=True); (history / f"{lane}.json").write_text(json.dumps(proof, indent=2) + "\n")
            raise
        history.mkdir(parents=True, exist_ok=True); (history / f"{lane}.json").write_text(json.dumps(proof, indent=2) + "\n")
        try:
            validate_readiness(proof, expressions, warmup_epoch, generation)
        except Exception as error:
            proof["validation_error"] = {"type": type(error).__name__, "message": str(error)}
            (history / f"{lane}.json").write_text(json.dumps(proof, indent=2) + "\n")
            raise
    if ranges_missing:
        ranges = directory / "query-ranges"; ranges.mkdir()
        range_expressions = {key: queries[key].replace("GENERATION", generation) for key in RANGE_KEYS}
        try:
            for key, expression in range_expressions.items():
                (ranges / f"{key}.json").write_text(json.dumps(query_range(endpoint, expression, start, end), indent=2) + "\n")
        except Exception as error:
            (ranges / "collection-error.json").write_text(json.dumps({"type": type(error).__name__, "message": str(error)}) + "\n")
            raise
        manifest = {"generation": generation, "start_epoch": start, "end_epoch": end, "keys": list(RANGE_KEYS),
                    "expressions": range_expressions, "retrieved_utc": datetime.now(timezone.utc).isoformat()}
        (ranges / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
        (ranges / "queries-manifest.json").write_text(json.dumps(queries, indent=2) + "\n")
    sample_path = directory / "monitoring-samples.jsonl"
    if samples_missing:
        records = []
        for index in (1, 2):
            source = retained_up(directory, index)
            timestamp, value = result_value(read(source))
            records.append({"sample": index, "epoch": float(timestamp), "generation": generation,
                            "value": float(value), "kind": "retrospective retained monitor receipt",
                            "provenance": {"path": source.relative_to(E).as_posix(), "sha256": sha(source)}})
        sample_path.write_text("".join(json.dumps(row) + "\n" for row in records))


def collect_restoration(arm_dir, queries, endpoint, history, repetition, arm):
    generation = (arm_dir / "final-incumbent-generation.txt").read_text().strip()
    source = arm_dir / "final-monitor-up-2.json"
    epoch, _ = result_value(read(source))
    expressions = readiness_expressions(queries, generation)
    proof = {"schema": "flare-cache-fix-historical-readiness/v1", "purpose": "incumbent-restoration",
             "arm": arm, "repetition": repetition, "generation": generation, "verification_epoch": epoch,
             "retrieved_utc": datetime.now(timezone.utc).isoformat(),
             "kind": "read-only retrospective Prometheus query; no new model request",
             "queries": {key: {"query": expression, "evaluation_epoch": epoch,
                                "response": query(endpoint, expression, epoch)}
                         for key, expression in expressions.items()}}
    validate_readiness(proof, expressions, epoch, generation)
    (history / "restoration.json").write_text(json.dumps(proof, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("arm_dir", type=Path, help="closed formal arm directory, e.g. formal/r1-b")
    parser.add_argument("--collect", action="store_true", help="perform read-only Prometheus collection")
    args = parser.parse_args()
    if not args.collect:
        raise SystemExit("refusing collection without --collect")
    arm_dir = args.arm_dir.resolve()
    if arm_dir.parent != (E / "formal").resolve():
        raise SystemExit("arm_dir must be directly under this evidence/formal directory")
    queries = read(E / "monitoring" / "queries.json")
    repetition, arm, history, actions = planned_outputs(arm_dir, queries)
    for lane in LANES:
        collect_lane(arm_dir, lane, queries, queries["prometheus"], history, repetition, arm, actions[lane])
    if (arm_dir / "final-incumbent-generation.txt").is_file() and (arm_dir / "final-monitor-up-2.json").is_file():
        collect_restoration(arm_dir, queries, queries["prometheus"], history, repetition, arm)
    print(json.dumps({"arm": arm_dir.name, "lanes": len(LANES), "retrospective": True}))


if __name__ == "__main__":
    main()
