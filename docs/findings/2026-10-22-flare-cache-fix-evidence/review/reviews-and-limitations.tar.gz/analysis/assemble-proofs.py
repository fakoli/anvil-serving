"""Offline receipts for one explicitly selected closed arm; never rescore formal answers."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import shlex
import sys
import tomllib

E = Path(__file__).resolve().parent.parent
H = E / 'harness'
sys.path.insert(0, str(H))
import normalize as native
import replay
import decode
import oracles


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


class Evidence:
    def __init__(self):
        self.refs = {}
        self.issues = []

    def raw(self, path):
        path = Path(path).resolve()
        raw = path.read_bytes()
        self.refs[str(path)] = {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest()}
        return raw

    def read(self, path):
        return json.loads(self.raw(path))

    def check(self, checks, name, operation):
        try:
            checks[name] = operation() is True
        except (OSError, ValueError, TypeError, KeyError, IndexError, AttributeError, RuntimeError) as error:
            checks[name] = False
            self.issues.append(f'{name}: {type(error).__name__}: {error}')

    def proof(self, gate, checks, **scope):
        return {'schema': 'flare-cache-fix-proof/v1', 'gate': gate,
                'ok': bool(checks) and all(v is True for v in checks.values()),
                'checks': checks, 'evidence': [self.refs[k] for k in sorted(self.refs)],
                'issues': sorted(set(self.issues)), **scope}


def envelope(e, path):
    value = e.read(path)
    assert_success = value.get('ok') is True and not value.get('error')
    if not assert_success:
        raise ValueError('managed receipt failed')
    data = value.get('data')
    return json.loads(data) if isinstance(data, str) and data.lstrip().startswith(('{', '[')) else data


def rows_match(rows, expected):
    """Exact ordered denominator, including distinct small-set iteration IDs."""
    return (isinstance(rows, list) and len(rows) == len(expected)
            and [r.get('case_id') for r in rows] == [r[0] for r in expected]
            and len({r.get('case_id') for r in rows}) == len(rows)
            and all(r.get('ok') is True and not r.get('normalization_error')
                    and r.get('body_sha256') == sha for r, (_, sha) in zip(rows, expected)))


def counters(raw):
    values = {}
    for line in raw.splitlines():
        if line and not line.startswith('#') and '{' not in line.split()[0]:
            key, value = line.split()[:2]
            if key in values:
                raise ValueError('duplicate scalar metric')
            values[key] = float(value)
    return values


def accounting(e, directory, stem, count, prompt_tokens, recorded=None):
    before_raw = e.raw(directory / f'{stem}-before.prom').decode()
    after_raw = e.raw(directory / f'{stem}-after.prom').decode()
    before, after = counters(before_raw), counters(after_raw)
    delta = {k: after[k] - before[k] for k in replay.prior.COUNTERS}
    if (not all(math.isfinite(v) and v >= 0 for v in delta.values())
            or after['flare_uptime_seconds'] < before['flare_uptime_seconds']
            or delta['flare_requests_completed_total'] != count
            or any(delta[k] for k in ('flare_requests_cancelled_total',
                    'flare_host_cache_store_failed_total', 'flare_host_cache_fetch_failed_total'))
            or sum(delta[k] for k in ('flare_prefill_tokens_total', 'flare_cache_reused_tokens_total',
                                      'flare_host_cache_reused_tokens_total')) != prompt_tokens
            or (recorded is not None and delta != recorded)):
        raise ValueError('counter/reset/interference/prompt accounting failure')
    return replay.speculative_delta(before_raw, after_raw)


def captured(row, body, allowed):
    usage = row['usage']
    reasons = row['finish_reasons']
    permitted = {'stop', 'length', 'tool_calls'} if body.get('tools') else {'stop', 'length'}
    if (row.get('done') is not True or row.get('error') or not reasons
            or not set(reasons) <= permitted or not usage
            or len(row.get('request_ids', [])) != 1
            or not row.get('events') or not all(p['event'].get('model', body['model']) in allowed
                and not p['event'].get('error') for p in row['events'])
            or type(row.get('start_epoch_ns')) is not int or row['e2e'] <= 0):
        raise ValueError('raw SSE terminal/identity/capture contract failure')
    if body.get('max_tokens') == 1 and (len(row['output_token_ids']) != 1
            or type(row['output_token_ids'][0]) is not int or row['output_token_ids'][0] < 0
            or usage.get('completion_tokens') != 1 or row.get('client_generated_ttft') is None):
        raise ValueError('fixed1 token contract failure')
    return True


CLOSURE_VERSION = 'flare-cache-fix-closure-normalization/v2'
_original_phase_artifacts = native.phase_artifacts


def closure_phase_artifacts(directory, lane, name, count, arm, refs, issues):
    """Versioned offline correction: batch-before is not a numeric request start."""
    before = len(issues)
    result = _original_phase_artifacts(directory, lane, name, count, arm, refs, issues)
    if lane in ('decode-c1', 'decode-c4') and name == 'measured':
        exact = f'{directory / "http/batch-before.prom"}: invalid request index'
        added = issues[before:]
        issues[:] = [issue for issue in issues if issue != exact]
        if added == [exact]:
            rows, summary, ok, identity, epoch, uncertain = result
            return rows, summary, True, identity, epoch, uncertain
    return result


def frozen_inputs(e):
    execution = e.read(E / 'formal/execution-plan.json')
    freeze_raw = e.raw(E / 'preformal-freeze.json')
    if hashlib.sha256(freeze_raw).hexdigest() != execution['preformal_freeze_sha256']:
        raise ValueError('preformal freeze digest mismatch')
    freeze = json.loads(freeze_raw)
    for name, digest in freeze['files'].items():
        if hashlib.sha256(e.raw(H / name)).hexdigest() != digest:
            raise ValueError(f'frozen input changed: {name}')
    if hashlib.sha256(e.raw(E / 'runtime-pins.json')).hexdigest() != execution['runtime_pins_sha256']:
        raise ValueError('frozen runtime pins changed')
    sources = e.read(H / 'source-references.json')['files']
    prior = next(r for r in sources if Path(r['path']) == replay.PRIOR / 'cache-replay.py')
    if hashlib.sha256(e.raw(Path(prior['path']))).hexdigest() != prior['sha256']:
        raise ValueError('frozen prior producer changed')
    for ref in replay.PLAN['original_bodies']:
        if hashlib.sha256(e.raw(Path(ref['path']))).hexdigest() != ref['sha256']:
            raise ValueError('frozen original corpus changed')
    return freeze, prior['sha256']


def formal_plan_matches(plan, prospective_sha, prior_sha):
    return plan.get('prospective_sha256') == prospective_sha and plan.get('prior_harness_sha256') == prior_sha


def phase_tags(rows, plan, lane, phase):
    return (plan.get('lane') == lane and plan.get('phase') == phase
            and all(r.get('phase') == phase for r in rows))


def phase_checks(e, directory, lane, name, count, arm, audit=False, frozen=None):
    issues = []
    rows, summary, native_ok, identity, epoch, uncertain = closure_phase_artifacts(
        directory, lane, name, count, arm.upper(), e.refs, issues)
    # Native helper deliberately rejects auditing; validate the pilot mode below.
    if audit:
        issues = [x for x in issues if 'wrapper/HTTP phase failed, incomplete or audit-enabled' not in x]
    e.issues.extend(issues)
    wrapper = e.read(directory / 'summary.json')
    plan = e.read(directory / 'plan.json')
    http_plan = e.read(directory / 'http/plan.json')
    recipe = tomllib.loads(e.raw(Path(plan['registry'])).decode())['recipe'][0]
    pins = e.read(E / 'runtime-pins.json')
    expected_registry = pins['audit_registries' if audit else 'registries'][arm.lower()]
    native.phase.verify_audit_mode(recipe, audit)
    expected_phase = 'prime' if name in ('warmup', 'prime') else 'measured'
    body_lane = 'warmup' if name == 'warmup' else lane
    iteration = int(name[-1]) if name.startswith('measured-') else 1
    selected = replay.bodies(body_lane, expected_phase) if not lane.startswith('decode-') or name == 'warmup' else None
    if selected is None:
        contract = e.read(H / 'decode-contract.json')
        selected = []
        for index in contract['lanes'][lane]['indices']:
            ref = contract['bodies'][index]
            raw = e.raw(Path(ref['path']))
            if hashlib.sha256(raw).hexdigest() != ref['sha256']:
                raise ValueError('decode body digest mismatch')
            selected.append((index, json.loads(raw)))
        expected = [(str(i), contract['bodies'][i]['sha256']) for i, _ in selected]
    else:
        expected = [(f'{i}:{iteration}' if lane in ('small12', 'small12-original') and expected_phase == 'measured'
                     else str(i), hashlib.sha256(json.dumps(body).encode()).hexdigest()) for i, body in selected]
    if (issues or uncertain or identity is None
            or not phase_tags(rows, http_plan, body_lane, expected_phase)
            or wrapper.get('ok') is not True or wrapper.get('error') or wrapper.get('child_returncode') != 0
            or wrapper.get('audit') is not audit or plan.get('audit') is not audit
            or plan.get('expected_image') != pins['image'] or Path(plan['registry']) != Path(expected_registry)
            or recipe['serve']['image'] != pins['image']
            or summary.get('missing', 0) != 0 or summary.get('error')
            or any(summary.get(k) != count for k in ('expected', 'attempted', 'completed'))
            or len(expected) != count or not rows_match(rows, expected)):
        raise ValueError('native phase/count/order/body/identity contract failure')
    if frozen is not None:
        freeze, prior_sha = frozen
        if http_plan.get('prior_harness_sha256') != prior_sha and selected is not None and not lane.startswith('decode-'):
            raise ValueError('phase prior producer hash mismatch')
        if not audit and not (lane.startswith('decode-') and name != 'warmup') and not formal_plan_matches(http_plan, freeze['files']['prospective.json'], prior_sha):
            raise ValueError('formal prospective hash mismatch')
        if not audit and lane.startswith('decode-') and name != 'warmup' and http_plan.get('contract_sha256') != freeze['files']['decode-contract.json']:
            raise ValueError('frozen decode contract mismatch')
        if audit and not re.fullmatch(r'[0-9a-f]{64}', http_plan.get('prospective_sha256', '')):
            raise ValueError('pilot earlier prospective version absent')
    allowed = {recipe['serve']['served_model_name'], replay.proven_source_revision(
        directory / 'running-proof.json', recipe['serve']['served_model_name'])}
    if set(http_plan['allowed_sse_model_ids']) != allowed:
        raise ValueError('SSE allowed-model set mismatch')
    traffic = []
    for attempt, (index, body) in zip(rows, selected):
        raw = e.read(directory / 'http' / f'{index:03}-response.json')
        captured(raw, body, allowed)
        traffic.append((raw['start_epoch_ns'] / 1e9, raw['start_epoch_ns'] / 1e9 + raw['e2e']))
        if selected is not None and lane.startswith('decode-') and name != 'warmup':
            normalized = decode.normalize(index, attempt['body_sha256'], raw)
            if any(attempt.get(k) != v for k, v in normalized.items()):
                raise ValueError('decode retained validation mismatch')
        else:
            if any(attempt.get(k) != raw.get(k) for k in raw if k != 'events'):
                raise ValueError('attempt/raw capture mismatch')
            if body_lane in ('cold', 'pageheavy') and raw['usage']['prompt_tokens'] != replay.PLAN[body_lane]['prompt_tokens'][index]:
                raise ValueError('protected prompt length mismatch')
            accounting(e, directory / 'http', f'{index:03}', 1, raw['usage']['prompt_tokens'], attempt['deltas'])
        if audit:
            oracle = e.read(H / 'oracle-fixtures.json')['semantic'][index]
            if not oracles.check(oracle['kind'], raw['message'], oracle['expected']):
                raise ValueError('strict pilot oracle failure')
            if raw['finish_reasons'] != (['tool_calls'] if oracle['kind'] == 'tool' else ['stop']):
                raise ValueError('strict pilot finish mismatch')
    if lane.startswith('decode-') and name != 'warmup':
        work = accounting(e, directory / 'http', 'batch', count, 7037 * count)
        if work != summary['batch_speculative_work'] or any(r.get('speculative_work') is not None for r in rows):
            raise ValueError('decode batch speculative ownership mismatch')
    return identity, recipe, traffic


def query(e, path, generation=None):
    value = e.read(path)
    rows = value['data']['result']
    if value.get('status') != 'success' or not rows:
        raise ValueError('missing/failed/empty monitoring query')
    if generation is not None and any(r['metric'].get('registration_generation') != generation for r in rows):
        raise ValueError('monitor generation mismatch')
    return rows


def points(rows):
    return [p for row in rows for p in row.get('values', [row.get('value')]) if p]


def readiness(e, lane_dir, generation, traffic_start):
    proof = e.read(E / 'analysis/readiness-history' / lane_dir.parent.name / (lane_dir.name + '.json'))
    expected_epoch = e.read(lane_dir / 'warmup/plan.json')['epoch_ns'] / 1e9
    queries = e.read(E / 'monitoring/queries.json')
    up = queries['identity'].replace('GENERATION', generation)
    expected_queries = {'up': up, 'scrape_count': f'count_over_time({up}[45s])',
        'scrape_min': f'min_over_time({up}[45s])', 'sample_age': f'time()-timestamp({up})',
        'collection_freshness': queries['collection_freshness']}
    if (proof.get('schema') != 'flare-cache-fix-historical-readiness/v1'
            or proof['generation'] != generation or proof['lane'] != lane_dir.name
            or proof['arm'] != lane_dir.parent.name[-1]
            or proof['repetition'] != int(lane_dir.parent.name[1])
            or proof['traffic_plan_epoch'] != expected_epoch or expected_epoch > traffic_start
            or 'retrospective' not in proof.get('kind', '')):
        raise ValueError('retrospective readiness scope mismatch')
    return historical_values(proof, expected_queries, expected_epoch, generation)


def historical_values(proof, expected_queries, expected_epoch, generation):
    values = {}
    for key, expression in expected_queries.items():
        receipt = proof['queries'][key]; response = receipt['response']
        rows = response['data']['result']
        if (receipt['query'] != expression or receipt['evaluation_epoch'] != expected_epoch
                or response.get('status') != 'success' or len(rows) != 1
                or (key != 'collection_freshness' and rows[0]['metric'].get('registration_generation') != generation)):
            raise ValueError('readiness query/generation mismatch')
        timestamp, value = rows[0]['value']
        if abs(float(timestamp)-expected_epoch) > .001:
            raise ValueError('readiness evaluation timestamp mismatch')
        values[key] = float(value)
    return (values['up'] == values['scrape_min'] == values['collection_freshness'] == 1
            and values['scrape_count'] >= 2 and 0 <= values['sample_age'] <= 30)


def assigned_gpus(load, running, status, registry_digest, recipe_digest):
    if load.get('ok') is not True or load.get('error'):
        raise ValueError('managed GPU assignment absent')
    argv = shlex.split(load['command'])
    requested = argv[argv.index('--gpu-device')+1].split(',')
    selected = native.phase.select_running(running['inventory'], status, registry_digest, recipe_digest)
    observed = selected.get('gpu_selection', [])
    verified = running.get('verified', {})
    if (running.get('error') or verified != selected or len(requested) != 2
            or len(set(requested)) != 2 or len(observed) != 2
            or set(observed) != set(requested)):
        raise ValueError('requested/actual exact-container GPU assignment mismatch')
    return set(observed)


def required_series(key, rows, gpu_ids):
    membership = {(r['metric'].get('__name__'), r['metric'].get('gpu_uuid')) for r in rows}
    names = {name for name, _ in membership}
    if key == 'identity': return 'up' in names
    if key == 'engine':
        return {'flare_requests_completed_total', 'flare_prefill_tokens_total',
                'flare_generated_tokens_total', 'flare_host_cache_fetch_failed_total',
                'flare_host_cache_store_failed_total'} <= names
    if key == 'collection_freshness': return 'operator:gpu_collection_success' in names
    return (len(gpu_ids) == 2 and {'node_memory_MemAvailable_bytes',
            'operator:gpu_collection_success', 'operator:gpu_last_success_timestamp_seconds'} <= names
            and all((name, gpu) in membership for gpu in gpu_ids for name in
                ('operator:gpu_utilization_ratio', 'operator:gpu_power_watts')))


def monitoring(e, lane_dir, traffic):
    gen_path = lane_dir / 'generation.txt'
    if not gen_path.exists(): gen_path = lane_dir / 'registration-generation.txt'
    generation = e.raw(gen_path).decode().strip()
    complete = e.read(lane_dir / 'lane-complete.json')
    samples = [json.loads(line) for line in e.raw(lane_dir / 'monitoring-samples.jsonl').splitlines() if line]
    if not generation or complete.get('generation', generation) != generation or len(samples) != 2 or any(r['generation'] != generation for r in samples):
        raise ValueError('missing/changed monitor generation')
    if not readiness(e, lane_dir, generation, min(t[0] for t in traffic)):
        raise ValueError('two actual fresh pretraffic scrapes unproven')
    manifest = e.read(lane_dir / 'query-ranges/manifest.json')
    start, end = min(t[0] for t in traffic), max(t[1] for t in traffic)
    if manifest['generation'] != generation or manifest['start_epoch'] > int(start) or manifest['end_epoch'] < int(end):
        raise ValueError('query interval does not cover traffic')
    load = e.read(lane_dir / 'load.json')
    plan = e.read(lane_dir / 'warmup/plan.json')
    recipe = tomllib.loads(e.raw(Path(plan['registry'])).decode())['recipe'][0]
    statuses = [json.loads(line)['status'] for line in e.raw(lane_dir / 'warmup/status.jsonl').splitlines() if line]
    running = e.read(lane_dir / 'warmup/running-proof.json')
    gpu_ids = assigned_gpus(load, running, statuses[0], plan['registry_sha256'], native.recipe_digest(recipe))
    for key in ('identity', 'engine', 'collection_freshness', 'gpu_and_host'):
        rows = query(e, lane_dir / f'query-ranges/{key}.json', generation if key in ('identity', 'engine') else None)
        if not required_series(key, rows, gpu_ids):
            raise ValueError('required telemetry family/GPU identity absent')
        for row in rows:
            samples_for_row = points([row])
            times = [float(p[0]) for p in samples_for_row]
            if not times or not all(math.isfinite(float(p[0])) and math.isfinite(float(p[1])) for p in samples_for_row) or any(b <= a for a,b in zip(times,times[1:])):
                raise ValueError('nonfinite/unordered monitoring samples')
            if min(times) > start or max(times) < end-15 or any(b-a > 45 for a,b in zip(times,times[1:])):
                raise ValueError('retained series does not cover traffic')
            metric = row['metric'].get('__name__', '')
            if metric in ('up', 'operator:gpu_collection_success') and any(float(p[1]) != 1 for p in samples_for_row):
                raise ValueError('monitor up/collection failure')
            if metric == 'operator:gpu_last_success_timestamp_seconds' and any(not 0 <= float(t)-float(v) <= 90 for t,v in samples_for_row):
                raise ValueError('collection stale')
            if any(s in metric for s in ('oom_kill', 'containment_error', 'crash', 'queue_timeout')) and any(float(p[1]) != 0 for p in samples_for_row):
                raise ValueError('retained fault signal')
    return True


def preflight_valid(preflight, model):
    names = ['smoke (short coding)', 'structured JSON', 'needle @ ~8192 ctx',
        'shared-prefix tool batch x20', 'streaming tool call', 'tool-result continuation', 'Responses API subset']
    results = preflight.get('results', [])
    tools = [r for r in preflight.get('observations', []) if r.get('test') == 'tools']
    return (preflight.get('schema_version') == 'preflight/v2' and preflight.get('passed') is True
        and preflight.get('model') == model and len(results) == 7
        and {r.get('name') for r in results} == set(names)
        and all(r.get('passed') is True for r in results)
        and any(r.get('name') == names[3] and r.get('detail', '').startswith('20/20 clean') for r in results)
        and (not tools or len(tools) == 20 and all(r.get('passed') is True for r in tools)
             and {r.get('request_index') for r in tools} == set(range(20))))


def restoration(e, arm_dir):
    close = e.read(arm_dir / 'closeout.json'); window = e.read(arm_dir / 'window.json')
    restore = e.read(arm_dir / 'restore.json')
    command = shlex.split(restore['command'])
    if restore.get('ok') is not True or restore.get('error') or command[:3] != ['serves', 'mode', 'restore-retained']:
        raise ValueError('managed restoration failure')
    for option, key in [('--expected-container-id', 'restore_id'), ('--expected-image', 'restore_image')]:
        if command[command.index(option)+1] != close[key]:
            raise ValueError('restoration identity mismatch')
    readmit = envelope(e, arm_dir / 'final-readmit.json')
    if readmit.get('applied') is not True or readmit['result'].get('readmitted') is not True:
        raise ValueError('readmit failed')
    sync = envelope(e, arm_dir / 'final-monitor-sync.json')
    if isinstance(sync, dict) and isinstance(sync.get('registration'), dict): sync = sync['registration']
    generation = e.raw(arm_dir / 'final-incumbent-generation.txt').decode().strip()
    if sync['container_id'] != close['restore_id'] or sync['image_digest'] != close['restore_image'] or sync['generation'] != generation or generation != close['incumbent_generation']:
        raise ValueError('restored generation identity mismatch')
    targets = e.read(arm_dir / 'final-engine-targets.json')
    if len(targets) != 1 or targets[0]['labels']['registration_generation'] != generation:
        raise ValueError('restored target generation mismatch')
    times = []
    for index in (1, 2):
        up = query(e, arm_dir / f'final-monitor-up-{index}.json', generation)
        fresh = query(e, arm_dir / f'final-monitor-freshness-{index}.json')
        if any(float(p[1]) != 1 for p in points(up) + points(fresh)):
            raise ValueError('restored monitoring failed')
        times.append(max(float(p[0]) for p in points(up) + points(fresh)))
    if not 15 <= times[1]-times[0] or times[-1] > window['wall_deadline_epoch'] or generation in e.raw(arm_dir / 'generations.txt').decode().splitlines():
        raise ValueError('new-generation/two-scrape/deadline failure')
    historical = e.read(E / 'analysis/readiness-history' / arm_dir.name / 'restoration.json')
    up2 = e.read(arm_dir / 'final-monitor-up-2.json')['data']['result'][0]['value'][0]
    queries = e.read(E / 'monitoring/queries.json')
    up = queries['identity'].replace('GENERATION', generation)
    expressions = {'up': up, 'scrape_count': f'count_over_time({up}[45s])',
        'scrape_min': f'min_over_time({up}[45s])', 'sample_age': f'time()-timestamp({up})',
        'collection_freshness': queries['collection_freshness']}
    if (historical.get('purpose') != 'incumbent-restoration' or historical['arm'] != arm_dir.name[-1]
            or historical['repetition'] != int(arm_dir.name[1]) or historical['generation'] != generation
            or historical.get('schema') != 'flare-cache-fix-historical-readiness/v1'
            or historical['verification_epoch'] != up2
            or not historical_values(historical, expressions, up2, generation)):
        raise ValueError('restoration actual-scrape historical proof failure')
    e.raw(native.phase.WORKTREE / 'anvil_serving/preflight.py')
    tiers = readmit['result']['status']['tiers']
    selected = [r for r in tiers if r.get('expected_model') == sync['model']]
    if len(selected) != 1 or selected[0].get('observed_model') != sync['model'] or selected[0].get('ready') is not True:
        raise ValueError('readmission served identity failure')
    for mode, model in [('direct', sync['model']), ('routed', 'llm.primary')]:
        preflight = e.read(arm_dir / f'final-{mode}-preflight.json')
        # Older direct/routed harness used the served name on both endpoints.
        expected = model if preflight.get('model') == model else sync['model']
        if not preflight_valid(preflight, expected):
            raise ValueError('restored named seven-result/twenty-tool aggregate failure')
    return True


def assemble(arm_dir):
    arm_dir = arm_dir.resolve()
    match = re.fullmatch(r'r([123])-([ab])', arm_dir.name)
    if not match or not (arm_dir / 'closeout.json').is_file():
        raise ValueError('explicit CLOSED r{1,2,3}-{a,b} directory required')
    arm = match[2]; config = json.loads((H / 'prospective.json').read_text())
    frozen_e = Evidence(); frozen_checks = {}; frozen = []
    frozen_e.check(frozen_checks, 'frozen_inputs', lambda: bool(frozen.append(frozen_inputs(frozen_e)) or True))
    common = Evidence(); common.refs.update(frozen_e.refs); restore_checks = dict(frozen_checks)
    common.check(restore_checks, 'managed_exact_restoration_and_service', lambda: restoration(common, arm_dir))
    output = {arm_dir / 'restoration.json': common.proof('restoration', restore_checks, tool_scope='producer-validated 20/20 aggregate; optional observations checked when present', readiness_scope='retrospective actual-scrape query evidence')}
    pilot = Evidence(); pilot.refs.update(frozen_e.refs); pilot_checks = dict(frozen_checks); pilot_result = []
    def pilot_check():
        pilot_result.append(phase_checks(pilot, E / f'audit-{arm}-correctness', 'correctness', 'measured', 3, arm, True, frozen[0] if frozen else None))
        pilot.raw(E / ('review/audit-a-gate-review.md' if arm == 'a' else 'review/preformal-gate-review.md'))
        pilot.raw(E / 'review/functional-proof-scope.md'); pilot.raw(H / 'oracles.py')
        return True
    pilot.check(pilot_checks, 'arm_scoped_strict_three_pilot', pilot_check)
    seen = set()
    for lane, plan in config['lanes'].items():
        directory = arm_dir / lane; e = Evidence(); e.refs.update(pilot.refs); checks = dict(pilot_checks)
        identities = []; traffic = []
        for name, count in native.phases(lane, plan):
            def validate_phase(name=name, count=count):
                identity, recipe, intervals = phase_checks(e, directory / name, lane, name, count, arm, frozen=frozen[0] if frozen else None)
                identities.append(identity); traffic.extend(intervals)
                if pilot_result:
                    pilot_recipe = copy.deepcopy(pilot_result[0][1])
                    pilot_recipe['serve']['flags'].remove('--verify-host-cache-transfers')
                    if recipe != pilot_recipe:
                        raise ValueError('pilot/formal package/allocation identity differs beyond audit mode')
                return True
            e.check(checks, f'native_{name}', validate_phase)
        checks['one_fresh_incarnation'] = bool(identities) and len(identities) == len(native.phases(lane, plan)) and len(set(identities)) == 1 and identities[0][0] not in seen
        if identities: seen.add(identities[0][0])
        e.issues.extend(pilot.issues)
        output[directory / 'functional.json'] = e.proof('functional', checks,
            scope='native formal execution plus arm-scoped strict-three pilot',
            formal_semantic_rescoring=False, pilot_audit_enabled=True, closure_normalization=CLOSURE_VERSION,
            pilot_scope='pilot incarnation only; excluded from formal attempt denominator')
        monitor_checks = {'native_phases_and_identity': all(v is True for v in checks.values())}
        e.check(monitor_checks, 'generation_up_freshness_and_traffic_ranges', lambda: monitoring(e, directory, traffic))
        output[directory / 'monitoring.json'] = e.proof('monitoring', monitor_checks,
            readiness_scope='retrospective raw Prometheus evidence at pre-warmup timestamp; no original-enforcement claim',
            query_step_seconds=15)
        negative = Evidence(); negative_checks = {'qualified_numerical_equivalence': False}
        for path in (E / 'diagnostic-amendment.json', E / 'pilot-a-restore-comparison.json', E / 'analysis/proof-assembly-map.md'):
            negative.check({}, str(path.name), lambda path=path: bool(negative.raw(path)))
        for gate in ('independent_oracles', 'restore_fidelity', 'causal_chain'):
            output[directory / f'{gate}.json'] = negative.proof(gate, negative_checks,
                status='pending matched A/B pressure-reuse-latency analysis' if gate == 'causal_chain' else 'retained numerical failure; diagnostic amendment',
                diagnostic_only=True, performance_eligible=False, promoted=False,
                limits=['real cancellation/DMA overlap unexercised', 'no teacher-forced/logit oracle'])
        pointers = {gate: {'path': str(path), 'sha256': hashlib.sha256(encoded(output[path])).hexdigest()}
                    for gate, path in [('restoration', arm_dir / 'restoration.json'),
                        *[(gate, directory / f'{gate}.json') for gate in ('functional','monitoring','independent_oracles','restore_fidelity','causal_chain')]]}
        output[directory / 'proofs.json'] = {'schema': 'flare-cache-fix-lane-proofs/v1', 'proofs': pointers}
    return output


def write(outputs):
    # Preflight every destination before writing any result; differing evidence is immutable.
    for path, value in outputs.items():
        if path.exists() and path.read_bytes() != encoded(value):
            raise ValueError(f'refusing differing existing proof: {path}')
    for path, value in outputs.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            with path.open('xb') as stream: stream.write(encoded(value))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('closed_arm', type=Path)
    args = parser.parse_args()
    outputs = assemble(args.closed_arm)
    write(outputs)
    print(json.dumps({'proof_files': len(outputs), 'arm': str(args.closed_arm.resolve()),
                      'diagnostic_only': True, 'performance_eligible': False}, sort_keys=True))
