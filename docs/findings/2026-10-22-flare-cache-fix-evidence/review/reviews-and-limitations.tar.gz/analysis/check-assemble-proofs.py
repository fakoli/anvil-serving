"""Small synthetic rejection checks; receipt schema is covered by check-normalize.py."""
import importlib.util
import json
from pathlib import Path
import tempfile

spec = importlib.util.spec_from_file_location('assembler', Path(__file__).with_name('assemble-proofs.py'))
a = importlib.util.module_from_spec(spec); spec.loader.exec_module(a)
expected = [('0', 'a'), ('1:2', 'b')]
good = [{'case_id': key, 'body_sha256': sha, 'ok': True} for key, sha in expected]
assert a.rows_match(good, expected)
assert not a.rows_match(good[:1], expected)
assert not a.rows_match([good[0], {**good[1], 'ok': False}], expected)
assert not a.rows_match([good[0], good[0]], expected)
assert not a.rows_match([good[0], {**good[1], 'body_sha256': 'changed'}], expected)
assert not a.rows_match(list(reversed(good)), expected)
# Real preflight/v2 result shape: observations may legitimately be absent.
names = ['smoke (short coding)', 'structured JSON', 'needle @ ~8192 ctx',
    'shared-prefix tool batch x20', 'streaming tool call', 'tool-result continuation', 'Responses API subset']
preflight = {'schema_version': 'preflight/v2', 'passed': True, 'model': 'served',
    'observations': [], 'results': [{'name': name, 'passed': True,
        'detail': '20/20 clean (sample: synthetic)' if 'batch' in name else 'ok'} for name in names]}
assert a.preflight_valid(preflight, 'served')
bad = a.copy.deepcopy(preflight); bad['results'][3]['detail'] = '19/20 clean'
assert not a.preflight_valid(bad, 'served')
bad = a.copy.deepcopy(preflight); bad['results'][1]['name'] = names[0]
assert not a.preflight_valid(bad, 'served')
preflight['observations'] = [{'test': 'tools', 'passed': True, 'request_index': i} for i in range(20)]
assert a.preflight_valid(preflight, 'served')
preflight['observations'][-1]['request_index'] = 20
assert not a.preflight_valid(preflight, 'served')
assert a.phase_tags([{'phase': 'measured'}], {'lane': 'correctness', 'phase': 'measured'}, 'correctness', 'measured')
assert not a.phase_tags([{'phase': 'prime'}], {'lane': 'correctness', 'phase': 'measured'}, 'correctness', 'measured')
assert not a.phase_tags([{'phase': 'measured'}], {'lane': 'other', 'phase': 'measured'}, 'correctness', 'measured')
assert not a.formal_plan_matches({'prospective_sha256': 'changed', 'prior_harness_sha256': 'b'}, 'a', 'b')
assert a.formal_plan_matches({'prospective_sha256': 'a', 'prior_harness_sha256': 'b'}, 'a', 'b')
selected = {'container_id': 'exact', 'registry_digest': 'registry', 'recipe_digest': 'recipe',
    'image_digest': 'image', 'container': a.native.phase.CONTAINER, 'running': True,
    'started_at': 'started', 'model': 'model', 'revision': 'revision', 'gpu_selection': ['g0', 'g1']}
status = {'container_id': 'exact', 'image_id': 'image', 'started_at': 'started', 'model': 'model', 'revision': 'revision'}
running = {'inventory': {'containers': [selected]}, 'verified': a.copy.deepcopy(selected)}
load = {'ok': True, 'command': 'models recipes load model --gpu-device g0,g1'}
assert a.assigned_gpus(load, running, status, 'registry', 'recipe') == {'g0', 'g1'}
for bad in [dict(load, command='models recipes load model --gpu-device g0,wrong')]:
    try:
        a.assigned_gpus(bad, running, status, 'registry', 'recipe')
        raise AssertionError('requested/actual GPU mismatch accepted')
    except ValueError:
        pass
bad = a.copy.deepcopy(running); bad['verified']['container_id'] = 'unrelated'
try:
    a.assigned_gpus(load, bad, status, 'registry', 'recipe')
    raise AssertionError('unrelated verified record accepted')
except ValueError:
    pass
series = [{'metric': {'__name__': name}} for name in ['node_memory_MemAvailable_bytes',
    'operator:gpu_collection_success', 'operator:gpu_last_success_timestamp_seconds']]
series += [{'metric': {'__name__': name, 'gpu_uuid': gpu}} for gpu in ['g0', 'g1']
    for name in ['operator:gpu_utilization_ratio', 'operator:gpu_power_watts']]
assert a.required_series('gpu_and_host', series, {'g0', 'g1'})
assert not a.required_series('gpu_and_host', series[:-1], {'g0', 'g1'})
assert not a.required_series('gpu_and_host', series[1:], {'g0', 'g1'})
# Only the exact declared batch filename is exempted; unrelated malformed starts remain.
original = a._original_phase_artifacts
def synthetic_native(directory, lane, name, count, arm, refs, issues):
    issues.append(f'{directory / "http/batch-before.prom"}: invalid request index')
    if (directory / 'http/bogus-before.prom').exists():
        issues.append(f'{directory / "http/bogus-before.prom"}: invalid request index')
    return [], {}, False, ('id',), 1, []
a._original_phase_artifacts = synthetic_native
try:
    with tempfile.TemporaryDirectory() as temp:
        directory = Path(temp); (directory / 'http').mkdir()
        issues = []; a.closure_phase_artifacts(directory, 'decode-c1', 'measured', 1, 'A', {}, issues)
        assert not issues
        (directory / 'http/bogus-before.prom').write_text('synthetic invalid prefix')
        issues = []; a.closure_phase_artifacts(directory, 'decode-c1', 'measured', 1, 'A', {}, issues)
        assert len(issues) == 1 and 'bogus-before' in issues[0]
finally:
    a._original_phase_artifacts = original
with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary); e = a.Evidence(); checks = {}
    e.check(checks, 'missing_raw', lambda: bool(e.raw(root / 'absent.json')))
    assert checks == {'missing_raw': False} and not e.proof('functional', checks)['ok']
    path = root / 'proof.json'
    a.write({path: {'ok': False}}); a.write({path: {'ok': False}})
    try:
        a.write({path: {'ok': True}})
        raise AssertionError('differing overwrite accepted')
    except ValueError:
        pass
    assert json.loads(path.read_text()) == {'ok': False}
    try:
        a.assemble(root / 'r1-a')
        raise AssertionError('unclosed arm accepted')
    except ValueError:
        pass
    # Existing freeze chain, with tiny synthetic contents instead of the real corpus.
    fixture = root / 'freeze-fixture'; harness = fixture / 'harness'; harness.mkdir(parents=True)
    (fixture / 'formal').mkdir(); producer = root / 'prior/cache-replay.py'; producer.parent.mkdir(); producer.write_text('pinned producer')
    digest = lambda path: a.hashlib.sha256(path.read_bytes()).hexdigest()
    (harness / 'oracle-fixtures.json').write_text('{}')
    (harness / 'source-references.json').write_text(json.dumps({'files': [{'path': str(producer), 'sha256': digest(producer)}]}))
    (fixture / 'runtime-pins.json').write_text('{}')
    freeze = {'files': {name: digest(harness / name) for name in ['oracle-fixtures.json', 'source-references.json']}}
    (fixture / 'preformal-freeze.json').write_text(json.dumps(freeze))
    (fixture / 'formal/execution-plan.json').write_text(json.dumps({'preformal_freeze_sha256': digest(fixture / 'preformal-freeze.json'), 'runtime_pins_sha256': digest(fixture / 'runtime-pins.json')}))
    old_e, old_h, old_prior, old_bodies = a.E, a.H, a.replay.PRIOR, a.replay.PLAN['original_bodies']
    a.E, a.H, a.replay.PRIOR, a.replay.PLAN['original_bodies'] = fixture, harness, producer.parent, []
    try:
        a.frozen_inputs(a.Evidence())
        (harness / 'oracle-fixtures.json').write_text('{"changed":true}')
        try:
            a.frozen_inputs(a.Evidence())
            raise AssertionError('drifted frozen fixture accepted')
        except ValueError:
            pass
    finally:
        a.E, a.H, a.replay.PRIOR, a.replay.PLAN['original_bodies'] = old_e, old_h, old_prior, old_bodies
    lane = root / 'formal/r1-a/cold'; (lane / 'warmup').mkdir(parents=True)
    (lane / 'warmup/plan.json').write_text(json.dumps({'epoch_ns': 100000000000}))
    queries = json.loads((a.E / 'monitoring/queries.json').read_text())
    up = queries['identity'].replace('GENERATION', 'g')
    expressions = {'up': up, 'scrape_count': f'count_over_time({up}[45s])',
        'scrape_min': f'min_over_time({up}[45s])', 'sample_age': f'time()-timestamp({up})',
        'collection_freshness': queries['collection_freshness']}
    proof = {'schema': 'flare-cache-fix-historical-readiness/v1', 'generation': 'g',
        'lane': 'cold', 'arm': 'a', 'repetition': 1, 'traffic_plan_epoch': 100,
        'kind': 'retrospective synthetic check', 'queries': {}}
    for key, expression in expressions.items():
        proof['queries'][key] = {'query': expression, 'evaluation_epoch': 100,
            'response': {'status': 'success', 'data': {'result': [
                {'metric': {'registration_generation': 'g'},
                 'value': [100, str(2 if key == 'scrape_count' else 1)]}]}}}
    fake_root = root / 'evidence'; (fake_root / 'monitoring').mkdir(parents=True)
    (fake_root / 'monitoring/queries.json').write_text(json.dumps(queries))
    historical = fake_root / 'analysis/readiness-history/r1-a/cold.json'
    historical.parent.mkdir(parents=True)
    original_root = a.E; a.E = fake_root
    try:
        closed = root / 'missing-formal/r1-a'; closed.mkdir(parents=True)
        (closed / 'closeout.json').write_text('{}')
        outputs = a.assemble(closed)
        functional = [value for path, value in outputs.items() if path.name == 'functional.json']
        assert len(functional) == 9 and all(value['ok'] is False for value in functional)
        historical.write_text(json.dumps(proof))
        assert a.readiness(a.Evidence(), lane, 'g', 101)
        restored = {**proof, 'purpose': 'incumbent-restoration', 'verification_epoch': 100}
        assert a.historical_values(restored, expressions, 100, 'g')
        proof['queries']['scrape_count']['response']['data']['result'][0]['value'][1] = '1'
        historical.write_text(json.dumps(proof))
        assert not a.readiness(a.Evidence(), lane, 'g', 101)
        proof['queries']['up']['query'] = 'different query'
        historical.write_text(json.dumps(proof))
        try:
            a.readiness(a.Evidence(), lane, 'g', 101)
            raise AssertionError('mismatched query accepted')
        except ValueError:
            pass
    finally:
        a.E = original_root
print('PASS: denominator/order/failure guards; declared decode batch exception; seven-result aggregate/optional zero-based tools; historical scrape proof; exact-container GPU assignment and required two-GPU/host families; pilot tags; frozen fixture/plan drift; immutable writes')
