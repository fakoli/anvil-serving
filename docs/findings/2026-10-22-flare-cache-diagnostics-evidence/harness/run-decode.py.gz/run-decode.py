"""Execute frozen diagnostic HTTP/capture cells; never manages serving lifecycle."""
import hashlib, importlib.util, json, os, signal, subprocess, time
from pathlib import Path
E = Path(__file__).parent
W = Path('OPERATOR_PATH_cc25b9dd30c4/anvil-serving')
PY = 'OPERATOR_PATH_9ba32d4067f1/python'
spec = importlib.util.spec_from_file_location('phase', E/'run-phase.py')
phase = importlib.util.module_from_spec(spec); spec.loader.exec_module(phase)
env = os.environ.copy(); env['ANVIL_SERVING_HOME']='OPERATOR_PATH_601ba1a688c8/operator-home'
expected = json.loads((E/'b-prime-after.json').read_text())['data']
if isinstance(expected,str): expected=json.loads(expected)
def identity(label):
    args=[PY,'-m','anvil_serving.cli','models','recipes','status','local-inference-lab/GLM-5.3-Flash-NVFP4-MXFP8-CSF-QAD','--container','glm53-flare-wave-instrumented','--registry',str(E/'flare-instrumented-recipe.toml'),'--json']
    r=subprocess.run(args,cwd=W,env=env,capture_output=True,text=True,timeout=15)
    (E/(label+'-identity.json')).open('x').write(r.stdout); r.check_returncode()
    d=json.loads(r.stdout); data=d['data']; data=json.loads(data) if isinstance(data,str) else data
    if not d['ok'] or not data['running'] or data['containment_error'] or data['host_memory']['oom_killed']: raise RuntimeError('identity or containment failure')
    phase.same_identity(expected,data)
key,_=phase.replay.read_key(phase.replay.KEY)
frozen=json.loads((E/'decode-frozen-r2.json').read_text())
for cell in json.loads((E/'decode-order-plan.json').read_text())['cells']:
    if time.time()+240 > json.loads((E/'outage-start.json').read_text())['at']+4200: raise RuntimeError('restoration reserve reached')
    for p,digest in json.loads((E/'frozen-inputs.json').read_text())['files'].items():
        if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=digest: raise RuntimeError('frozen source drift')
    for p,digest in frozen['files'].items():
        if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=digest: raise RuntimeError('decode source drift')
    (E/(cell['name']+'-reserved.json')).open('x').write(json.dumps({'at':time.time(),'cell':cell}))
    identity(cell['name']+'-before')
    phase.replay.idle(key)
    try:
        process=subprocess.Popen([PY,str(E/'decode-cell.py'),cell['name'],str(cell['concurrency']),str(cell['capture']).lower(),str(cell['warmup']).lower()],cwd=W,env=env,start_new_session=True)
        try:
            if process.wait(timeout=140): raise RuntimeError('decode cell failed')
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
            raise RuntimeError('decode cell hard timeout')
    finally:
        phase.replay.idle(key)
        identity(cell['name']+'-after')
