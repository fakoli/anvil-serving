import json,os,subprocess,time,urllib.request
from pathlib import Path
import sys
NAME=sys.argv[1]; CONCURRENCY=int(sys.argv[2]); PROFILED=sys.argv[3]=="true"; WARMUP=sys.argv[4]=="true"
E=Path('OPERATOR_PATH_8461e2630ba6/2026-10-22-flare-cache-diagnostics')
H=Path('OPERATOR_PATH_601ba1a688c8/operator-home')
py='OPERATOR_PATH_9ba32d4067f1/python'
env=os.environ.copy();env['ANVIL_SERVING_HOME']=str(H);env['PYTHONPATH']='OPERATOR_PATH_cc25b9dd30c4/anvil-serving'
name=NAME
c=CONCURRENCY
profiled=PROFILED
fixture=[py,str(E/'decode-fixture.py'),'--api-key-file','OPERATOR_PATH_6f3ccf38bed5/flare.key','--phase','warmup' if WARMUP else ('profiled' if profiled else 'unprofiled'),'--concurrency',str(c),'--seconds','60','--output',str(E/name)]
def metrics():
 with urllib.request.urlopen('http://127.0.0.1:39130/metrics',timeout=5) as r:raw=r.read(4<<20).decode()
 return {l.split()[0]:float(l.split()[-1]) for l in raw.splitlines() if l and not l.startswith('#') and '{' not in l.split()[0]}
before=metrics()
(E/(name+'-commands.json')).open('x').write(json.dumps({'fixture_argv':fixture,'capture_config':'scheduler-capture.json' if profiled else None,'at':time.time()},indent=2)+'\n')
with (E/(name+'.log')).open('x') as out:
 process=subprocess.Popen(fixture,env=env,stdout=out,stderr=subprocess.STDOUT)
 try:
  if profiled:
   deadline=time.monotonic()+30
   while True:
    m=metrics()
    if m['flare_active_requests']==c and m['flare_generated_tokens_total']-before['flare_generated_tokens_total']>=64:break
    if process.poll() is not None or time.monotonic()>deadline:raise RuntimeError('decode window not admitted')
    time.sleep(.1)
   a=[py,'-m','anvil_serving.cli','models','recipes','scheduler-trace','--config',str(E/'scheduler-capture.json'),'--output',str(E/(name+'-trace.json')),'--confirm']
   r=subprocess.run(a,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=40)
   if r.returncode != 0: raise RuntimeError('scheduler capture gate failed')
  status=process.wait(timeout=65)
  summary=json.loads((E/name/'summary.json').read_text())
  if status != 0 or summary.get('error'): raise RuntimeError('fixture validation failed')
  print(json.dumps({'name':name,'concurrency':c,'profiled':profiled,'valid_requests':sum(len(x['requests']) for x in summary['cases'])}),flush=True)
 finally:
  if process.poll() is None:
   # Bounded fixture self-terminates at its HTTP deadline; do not kill the model.
   try: process.wait(timeout=5)
   except subprocess.TimeoutExpired:
    process.kill(); process.wait(timeout=5)
