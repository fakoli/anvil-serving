"""One bounded loopback transport check for baseline-adapter-canonical.py; no model or lifecycle calls."""
import http.server
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import time

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('baseline_adapter_canonical', ROOT / 'baseline-adapter-canonical.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
KEY = 'fake"credential'
MODEL = 'synthetic-current'
CANONICAL = module.CANONICAL_MODEL_ID
METRICS = '\n'.join(prefix + 'synthetic"} 0' for prefix in module.METRIC_PREFIXES)

assert 'flare_host_cache_lookup_outcomes_total{reason="' in module.METRIC_PREFIXES
assert not any('row_pressure' in item or 'page_pressure' in item for item in module.METRIC_PREFIXES)
assert all(module.metric_presence(METRICS).values())
assert module.contains_secret({'echo': KEY}, KEY)
for url in ('http://127.0.0.1:30000', 'http://127.0.0.1:1/'):
    assert module.parse_base_url(url) == url.rstrip('/')
for url in ('http://127.0.0.1:80@evil.test/', 'https://127.0.0.1:1', 'http://127.0.0.1/', 'http://127.0.0.1:1/?x=1'):
    try:
        module.parse_base_url(url)
    except ValueError:
        pass
    else:
        raise AssertionError(url)
for lane, phase, repeat, count, first, last in (
    ('fixed1', 'measured', 1, 52, '51:0', '0:0'),
    ('small12', 'measured', 2, 24, '40:0', '51:1'),
    ('pageheavy', 'prime', 1, 12, '0:0', '11:0'),
    ('warmup', 'warmup', 1, 3, '0:0', '2:0'),
):
    rows, _contract = module.lane_rows(lane, ROOT / 'frozen-prior' / module.LANES[lane]['file'], phase, repeat)
    assert len(rows) == count and rows[0][0] == first and rows[-1][0] == last
row = {'http_status': 200, 'complete': True, 'usage': {'completion_tokens': 1}, 'finish_reasons': ['stop'],
       'output_token_ids': [7], 'requested_model': MODEL, 'catalog_model': MODEL,
       'catalog_root': CANONICAL, 'canonical_model': CANONICAL, 'response_model': CANONICAL,
       'observed_model': CANONICAL, 'sse_models': [CANONICAL], 'client_generated_ttft_seconds': 0.01}
assert module.response_complete(row, MODEL) and module.work_valid('fixed1', row)
for bad in ({**row, 'output_token_ids': ['7']}, {**row, 'usage': {'completion_tokens': 2}},
            {**row, 'usage': {'completion_tokens': True}}, {**row, 'sse_models': ['wrong-stream']}):
    assert not module.response_complete(bad, MODEL)
assert not module.metrics_valid({'status': 500, 'error': 'HTTPError:500', 'presence': module.metric_presence(METRICS)})
try:
    module.sanitize({'nested': [KEY]}, KEY)
except ValueError:
    pass
else:
    raise AssertionError('escaped credential accepted')


class State:
    mode = 'good'
    model_calls = 0


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, _format, *_args):
        pass

    def send_body(self, status, body, content_type='application/json'):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == '/v1/models':
            State.model_calls += 1
            if State.mode == 'post_identity' and State.model_calls >= 2:
                self.send_body(500, b'{"error":"post identity"}')
                return
            cards = [{'id': MODEL, 'root': CANONICAL}]
            if State.mode == 'wrong_alias':
                cards = [{'id': 'wrong-alias', 'root': CANONICAL}]
            elif State.mode == 'wrong_root':
                cards = [{'id': MODEL, 'root': 'wrong-root'}]
            elif State.mode == 'extra_card':
                cards.append({'id': 'other', 'root': CANONICAL})
            self.send_body(200, json.dumps({'object': 'list', 'data': cards}).encode())
            return
        if self.path == '/metrics':
            if State.mode == 'metrics500':
                self.send_body(500, METRICS.encode(), 'text/plain')
            elif State.mode == 'metrics_key':
                self.send_body(200, (METRICS + '\n' + KEY).encode(), 'text/plain')
            else:
                self.send_body(200, METRICS.encode(), 'text/plain')
            return
        self.send_body(404, b'{}')

    def do_POST(self):
        if self.path != '/v1/chat/completions':
            self.send_body(404, b'{}')
            return
        _payload = self.rfile.read(int(self.headers.get('Content-Length', '0')))
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.end_headers()
        if State.mode == 'trickle':
            self.wfile.write(b'data: ')
            self.wfile.flush()
            time.sleep(16)
            return
        if State.mode == 'wrong_stream':
            event_model = 'wrong-stream'
        elif State.mode == 'empty_stream':
            event_model = ''
        elif State.mode == 'null_stream':
            event_model = None
        else:
            event_model = CANONICAL
        start = {'id': 'synthetic-request', 'model': event_model,
                 'choices': [{'delta': {'content': ''}, 'finish_reason': None}], 'prompt_token_ids': [1, 2]}
        self.wfile.write(b'data: ' + json.dumps(start).encode() + b'\n\n')
        if State.mode == 'partial':
            self.wfile.flush()
            return
        if State.mode == 'ids':
            ids, count = ['bad'], 1
        elif State.mode == 'count':
            ids, count = [7], 2
        else:
            ids, count = [7], 1
        terminal = {'id': 'synthetic-request', 'model': event_model,
                    'choices': [{'delta': {'content': 'x'}, 'token_ids': ids, 'finish_reason': 'stop'}],
                    'usage': {'completion_tokens': count}, 'performance': {'ingress_ns': 1, 'enqueue_ns': 2}}
        self.wfile.write(b'data: ' + json.dumps(terminal).encode() + b'\n\ndata: [DONE]\n\n')
        self.wfile.flush()


def invoke(base, out, proof, bodies, command, extra=()):
    now = time.time() + 17
    args = [sys.executable, str(ROOT / 'baseline-adapter-canonical.py'), command,
            '--arm', 'upstream_plus_compat25', '--base-url', base, '--model', MODEL,
            '--api-key-env', 'SYNTHETIC_ADAPTER_KEY', '--incarnation-proof', str(proof),
            '--output', str(out), '--deadline-epoch', str(now)]
    if command == 'fixture':
        args += ['--bodies', str(bodies), '--lane', 'fixed1', '--case-index', '0']
    else:
        args += ['--fixture', str(extra[0]), '--bodies', str(bodies), '--lane', 'fixed1', '--phase', 'prime', '--repeat', '1']
    env = {**os.environ, 'SYNTHETIC_ADAPTER_KEY': KEY}
    return subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, timeout=25)


with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    bodies = tmp / 'fixed1-bodies.json'
    shutil.copy2(ROOT / 'frozen-prior' / 'fixed1-bodies.json', bodies)
    proof = tmp / 'proof.json'
    proof.write_text(json.dumps({'verified': {'running': True, 'served_identity': MODEL, 'container_id': 'synthetic', 'revision': 'synthetic'}}))
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    try:
        State.mode = 'good'; State.model_calls = 0
        good = tmp / 'good'
        result = invoke(base, good, proof, bodies, 'fixture')
        assert result.returncode == 0, (result.stderr, (good / 'adapter-error.json').read_text() if (good / 'adapter-error.json').exists() else 'no error')
        fixture = good / 'fixture.json'
        record = json.loads(fixture.read_text())
        assert record['requested_model'] == MODEL and record['catalog_root'] == CANONICAL and record['response_model'] == CANONICAL
        assert fixture.exists()
        for mode in ('ids', 'count', 'metrics500', 'metrics_key', 'partial', 'wrong_alias', 'wrong_root', 'wrong_stream', 'empty_stream', 'null_stream', 'extra_card'):
            State.mode = mode; State.model_calls = 0
            output = tmp / mode
            result = invoke(base, output, proof, bodies, 'fixture')
            assert result.returncode != 0, (mode, result.stderr)
            assert (output / 'adapter-error.json').exists(), mode
            if mode in ('ids', 'count', 'partial', 'wrong_stream', 'empty_stream', 'null_stream'):
                assert (output / 'response.json').exists(), mode
            assert KEY not in ''.join(path.read_text(errors='ignore') for path in output.rglob('*') if path.is_file()), mode
        State.mode = 'post_identity'; State.model_calls = 0
        output = tmp / 'post-identity'
        result = invoke(base, output, proof, bodies, 'phase', (fixture,))
        assert result.returncode != 0, result.stderr
        assert (output / 'attempts.json').exists() and (output / 'summary.json').exists()
        summary = json.loads((output / 'summary.json').read_text())
        assert summary['phase_error'] == 'ValueError'
        State.mode = 'trickle'; State.model_calls = 0
        output = tmp / 'trickle'
        start = time.monotonic()
        result = invoke(base, output, proof, bodies, 'fixture')
        elapsed = time.monotonic() - start
        assert result.returncode != 0 and elapsed < 22, (elapsed, result.stderr)
        assert (output / 'adapter-error.json').exists()
    finally:
        server.shutdown()
        thread.join(timeout=5)
print(json.dumps({'ok': True, 'transport': '127.0.0.1 synthetic only', 'lifecycle': False}))
