"""Offline plan and frozen-input integrity check; never opens a network connection."""
import hashlib, json
from pathlib import Path
ROOT=Path(__file__).parent
plan=json.loads((ROOT/'plan.json').read_text())
assert plan['schema']=='flare-upstream-refresh-plan/v1'
assert plan['status']=='prepared_not_executed_current_baseline_pending'
assert plan['counts']['timing_http_total']==864
assert plan['counts']['timing_http_total']==sum(plan['counts'][key] for key in ('fixed1_http','small12_http','pageheavy_http'))
assert plan['counts']['timing_incarnations']==14
assert plan['order']['protected_abba']==['A-upstream_plus_compat25','B-conditional_row_share75','B-conditional_row_share75','A-upstream_plus_compat25']
assert len(plan['order']['fixed1_repeats'])==3
assert plan['source']['baseline']=='upstream_plus_compat25'
assert plan['source']['candidate']=='conditional_minimal_row_share_patch_75_not_implemented'
assert 'flare_host_cache_lookup_outcomes_total{reason="..."}' in plan['required_metrics']['native_prometheus_raw_presence']
assert plan['required_metrics']['unknown_unless_separately_measured']==['row pressure','page pressure']
assert (ROOT/'plan-r1.json').is_file()
for name in ('replay.py','run-phase.py','fixed1-bodies.json','pageheavy-bodies.json','warmup-bodies.json'):
    assert (ROOT/'frozen-prior'/name).is_file(), name
print(json.dumps({'ok':True,'plan_sha256':hashlib.sha256((ROOT/'plan.json').read_bytes()).hexdigest(),'network':False,'lifecycle':False}))
