"""Bounded current-upstream HTTP receipt collector; no lifecycle actions."""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import signal
import threading
import time
from urllib.parse import urlsplit
import urllib.error
import urllib.request

ROOT = Path(__file__).parent
FROZEN = ROOT / 'frozen-prior'
MAX_BODY_BYTES = 2 << 20
MAX_METRICS_BYTES = 8 << 20
MAX_IDENTITY_BYTES = 1 << 20
MAX_RESPONSE_BYTES = 8 << 20
MAX_LINE_BYTES = 1 << 20
MAX_PHASE_SECONDS = 1800
# Signed package ModelConfig.model_id for this dedicated current-upstream baseline.
CANONICAL_MODEL_ID = 'dec48abd33efa73c3bb7c95b74eee10cad34f9be'
METRIC_PREFIXES = (
    'flare_host_cache_lookup_outcomes_total{reason="',
    'flare_host_cache_store_reasons_total{reason="',
    'flare_host_cache_row_refills_total',
    'flare_host_cache_missing_tokens_',
    'flare_host_cache_estimated_transfer_ns_',
    'flare_host_cache_estimated_prefill_ns_',
)
LANES = {
    'fixed1': {'file': 'fixed1-bodies.json', 'sha256': '199ce268f4d0f845ca0453706792778cfaaed6b2812ab2797a49561ca87739ca',
               'bytes': 1661999, 'count': 52, 'case_ids': tuple(range(52)),
               'orders': {'prime': 'forward', 'measured': 'reverse'}, 'repeats': {'prime': (1,), 'measured': (1,)}},
    'small12': {'file': 'fixed1-bodies.json', 'sha256': '199ce268f4d0f845ca0453706792778cfaaed6b2812ab2797a49561ca87739ca',
                'bytes': 1661999, 'count': 12, 'case_ids': tuple(range(40, 52)),
                'orders': {'prime': 'forward', 'measured': 'forward'}, 'repeats': {'prime': (1,), 'measured': (2,)}},
    'pageheavy': {'file': 'pageheavy-bodies.json', 'sha256': 'ac323a0ea8548c34ad5fc2cc5928f7c1e307400775df0c08050622beb7e2dc50',
                  'bytes': 1277631, 'count': 12, 'case_ids': tuple(range(12)),
                  'orders': {'prime': 'forward', 'measured': 'forward'}, 'repeats': {'prime': (1,), 'measured': (1,)}},
    'warmup': {'file': 'warmup-bodies.json', 'sha256': 'c3a3571abc8a7b0fbefe2504ea6b2665abfc9ed3e9b6466dc8c78bf56981cf42',
               'bytes': 320079, 'count': 3, 'case_ids': (0, 1, 2),
               'orders': {'warmup': 'forward'}, 'repeats': {'warmup': (1,)}},
}


class DeadlineExpired(TimeoutError):
    pass


def bounded_read(path, limit):
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    try:
        raw = os.read(fd, limit + 1)
    finally:
        os.close(fd)
    if len(raw) > limit:
        raise ValueError('file exceeds bounded size')
    return raw


def lane_rows(lane, supplied_path, phase, repeat):
    spec = LANES[lane]
    if phase not in spec['orders'] or repeat not in spec['repeats'][phase]:
        raise ValueError('lane phase/repeat contract mismatch')
    supplied = Path(supplied_path)
    if supplied.name != spec['file']:
        raise ValueError('body file name differs from frozen lane contract')
    raw = bounded_read(supplied, spec['bytes'])
    if len(raw) != spec['bytes'] or hashlib.sha256(raw).hexdigest() != spec['sha256']:
        raise ValueError('frozen corpus identity mismatch')
    rows = json.loads(raw)
    if not isinstance(rows, list):
        raise ValueError('frozen corpus is not a JSON list')
    if lane == 'small12':
        rows = rows[-12:]
    elif lane == 'warmup':
        if not all(isinstance(row, dict) and row.get('index') == index and isinstance(row.get('body'), dict)
                   and hashlib.sha256(json.dumps(row['body']).encode()).hexdigest() == row.get('body_sha256')
                   for index, row in enumerate(rows)):
            raise ValueError('warmup wrapper/body contract mismatch')
        rows = [row['body'] for row in rows]
    if len(rows) != spec['count'] or not all(isinstance(row, dict) for row in rows):
        raise ValueError('frozen lane count/body contract mismatch')
    paired = list(zip(spec['case_ids'], rows))
    if spec['orders'][phase] == 'reverse':
        paired.reverse()
    return [(f'{case_id}:{cycle}', body) for cycle in range(repeat) for case_id, body in paired], spec


def contains_secret(value, key):
    if not key or key == 'unavailable':
        return False
    if isinstance(value, str):
        return key in value
    if isinstance(value, dict):
        return any(contains_secret(item, key) for pair in value.items() for item in pair)
    if isinstance(value, (list, tuple)):
        return any(contains_secret(item, key) for item in value)
    return False


def sanitize(value, key):
    if contains_secret(value, key):
        raise ValueError('literal API key appeared in retained evidence')
    return value


def parse_base_url(value):
    parsed = urlsplit(value)
    if (parsed.scheme != 'http' or parsed.hostname != '127.0.0.1' or parsed.port is None
            or parsed.username is not None or parsed.password is not None or parsed.path not in ('', '/')
            or parsed.query or parsed.fragment):
        raise ValueError('base URL must be exact http://127.0.0.1:PORT')
    return f'http://127.0.0.1:{parsed.port}'


def reserve_output(path):
    path = Path(path)
    parent = path.parent
    if not parent.is_dir() or parent.is_symlink():
        raise ValueError('output parent must be an existing non-symlink directory')
    try:
        os.mkdir(path, 0o700)
    except FileExistsError as error:
        raise FileExistsError('output directory already exists') from error
    return path


def write_bytes(path, value, key):
    sanitize(value.decode('utf-8', 'replace'), key)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(path, flags, 0o600)
    try:
        os.write(fd, value)
        os.fsync(fd)
    finally:
        os.close(fd)


def write_json(output, name, value, key):
    sanitize(value, key)
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    write_bytes(output / name, data, key)
    return hashlib.sha256(data).hexdigest()


def remaining(deadline):
    value = deadline - time.monotonic()
    if value <= 0:
        raise DeadlineExpired('absolute phase deadline elapsed')
    return value


@contextmanager
def hard_deadline(seconds):
    if threading.current_thread() is not threading.main_thread():
        raise RuntimeError('hard deadline requires main thread')
    old_handler = signal.getsignal(signal.SIGALRM)
    old_timer = signal.getitimer(signal.ITIMER_REAL)
    def expired(_signum, _frame):
        raise DeadlineExpired('hard process deadline elapsed')
    signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old_handler)
        if old_timer != (0.0, 0.0):
            signal.setitimer(signal.ITIMER_REAL, *old_timer)


def metric_presence(raw):
    return {prefix: prefix in raw for prefix in METRIC_PREFIXES}


def metrics_valid(receipt):
    return receipt.get('status') == 200 and receipt.get('error') is None and all(receipt.get('presence', {}).values())


def request_raw(url, key, deadline, data=None, headers=None, limit=MAX_RESPONSE_BYTES):
    headers = dict(headers or {})
    headers['Authorization'] = 'Bearer ' + key
    request = urllib.request.Request(url, data=data, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=min(60, remaining(deadline))) as response:
            payload = response.read(limit + 1)
            if len(payload) > limit:
                raise ValueError('HTTP capture bound exceeded')
            return response.status, payload, None
    except urllib.error.HTTPError as error:
        payload = error.read(limit + 1)
        if len(payload) > limit:
            payload = payload[:limit]
        return error.code, payload, f'HTTPError:{error.code}'


def capture_models(base, key, deadline):
    status, raw, error = request_raw(base + '/v1/models', key, deadline, limit=MAX_IDENTITY_BYTES)
    text = raw.decode('utf-8', 'replace')
    if error or status != 200:
        return {'status': status, 'error': error, 'body': text}
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return {'status': status, 'error': 'invalid_json', 'body': text}
    return {'status': status, 'data': payload}


def validate_models(receipt, model):
    data = receipt.get('data')
    cards = data.get('data') if isinstance(data, dict) else None
    if (not isinstance(data, dict) or data.get('object') != 'list' or not isinstance(cards, list)
            or len(cards) != 1 or not isinstance(cards[0], dict)
            or cards[0].get('id') != model or cards[0].get('root') != CANONICAL_MODEL_ID):
        raise ValueError('authenticated endpoint catalog alias/root mismatch')


def capture_metrics(base, key, deadline):
    status, raw, error = request_raw(base + '/metrics', key, deadline, limit=MAX_METRICS_BYTES)
    text = raw.decode('utf-8', 'replace')
    return {'status': status, 'error': error, 'raw': text, 'presence': metric_presence(text)}


def stream_request(base, key, model, body, deadline):
    """Request catalog alias; require canonical signed-package ID in every SSE event."""
    payload = dict(body)
    payload['model'] = model
    encoded = json.dumps(payload, separators=(',', ':')).encode()
    start = time.monotonic_ns()
    row = {'body_sha256': hashlib.sha256(encoded).hexdigest(), 'started_monotonic_ns': start,
           'events': [], 'output_token_ids': [], 'finish_reasons': [], 'request_ids': [],
           'complete': False, 'observed_model': None, 'requested_model': model,
           'catalog_model': model, 'catalog_root': CANONICAL_MODEL_ID,
           'canonical_model': CANONICAL_MODEL_ID, 'response_model': None, 'sse_models': []}
    request = urllib.request.Request(base + '/v1/chat/completions', data=encoded,
                                    headers={'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key})
    try:
        with urllib.request.urlopen(request, timeout=min(60, remaining(deadline))) as response:
            row['http_status'] = response.status
            if response.status != 200:
                raise ValueError('non-200 HTTP response')
            total = 0
            socket = getattr(getattr(getattr(response, 'fp', None), 'raw', None), '_sock', None)
            while True:
                if socket is not None:
                    socket.settimeout(min(60, remaining(deadline)))
                line = response.readline(MAX_LINE_BYTES + 1)
                arrived = time.monotonic_ns()
                if not line:
                    break
                total += len(line)
                if len(line) > MAX_LINE_BYTES or total > MAX_RESPONSE_BYTES:
                    raise ValueError('SSE capture bound exceeded')
                if not line.startswith(b'data:'):
                    continue
                data = line[5:].strip()
                if data == b'[DONE]':
                    row['complete'] = True
                    break
                event = json.loads(data)
                sanitize(event, key)
                row['events'].append({'client_monotonic_ns': arrived, 'event': event})
                if 'model' in event:
                    observed = event['model']
                    if not isinstance(observed, str) or not observed or observed != CANONICAL_MODEL_ID:
                        raise ValueError('SSE canonical model identity mismatch')
                    row['sse_models'].append(observed)
                    row['observed_model'] = observed
                    row['response_model'] = observed
                if event.get('error'):
                    row['error'] = {'kind': 'upstream_sse_error', 'body': event['error']}
                    break
                if event.get('id') and event['id'] not in row['request_ids']:
                    row['request_ids'].append(event['id'])
                if event.get('usage'):
                    row['usage'] = event['usage']
                if event.get('performance'):
                    row['performance'] = event['performance']
                for choice in event.get('choices', []):
                    ids = choice.get('token_ids') or []
                    row['output_token_ids'].extend(ids)
                    if ids and 'client_generated_ttft_seconds' not in row:
                        row['client_generated_ttft_seconds'] = (arrived - start) / 1e9
                    if choice.get('finish_reason'):
                        row['finish_reasons'].append(choice['finish_reason'])
    except urllib.error.HTTPError as error:
        row['http_status'] = error.code
        row['error'] = {'kind': 'http_error', 'body': error.read(MAX_RESPONSE_BYTES).decode('utf-8', 'replace')}
    except Exception as error:
        row['error'] = {'kind': type(error).__name__}
    row['e2e_seconds'] = (time.monotonic_ns() - start) / 1e9
    return row


def valid_token_ids(ids):
    return isinstance(ids, list) and all(type(token_id) is int for token_id in ids)


def response_complete(row, model):
    if row.get('error') or row.get('http_status') != 200 or not row.get('complete') or not isinstance(row.get('usage'), dict):
        return False
    if (row.get('requested_model') != model or row.get('catalog_model') != model
            or row.get('catalog_root') != CANONICAL_MODEL_ID or row.get('canonical_model') != CANONICAL_MODEL_ID
            or row.get('response_model') != CANONICAL_MODEL_ID or row.get('observed_model') != CANONICAL_MODEL_ID
            or not row.get('sse_models') or any(item != CANONICAL_MODEL_ID for item in row['sse_models'])
            or not row.get('finish_reasons') or not valid_token_ids(row.get('output_token_ids'))):
        return False
    completion = row['usage'].get('completion_tokens')
    if type(completion) is not int or completion < 0 or completion != len(row['output_token_ids']):
        return False
    return not (set(row['finish_reasons']) - {'stop', 'length', 'tool_calls'})


def work_valid(lane, response):
    if not response_complete(response, response.get('requested_model')):
        return False
    if lane == 'fixed1':
        return (len(response['output_token_ids']) == 1
                and response['usage'].get('completion_tokens') == 1
                and response.get('client_generated_ttft_seconds') is not None)
    return bool(response.get('output_token_ids'))


def load_incarnation(path, model, key):
    raw = bounded_read(path, MAX_IDENTITY_BYTES)
    parsed = json.loads(raw)
    sanitize(parsed, key)
    verified = parsed.get('verified') if isinstance(parsed, dict) else None
    if not isinstance(verified, dict) or verified.get('running') is not True or verified.get('served_identity') != model:
        raise ValueError('owner incarnation proof does not bind the served model')
    if not isinstance(verified.get('container_id'), str) or not isinstance(verified.get('revision'), str):
        raise ValueError('owner incarnation proof lacks container/revision')
    return parsed, hashlib.sha256(raw).hexdigest()


def closed_fixture(path, model, arm, lane, corpus_sha):
    record = json.loads(bounded_read(path, MAX_IDENTITY_BYTES))
    if (record.get('schema') != 'flare-upstream-current-response-fixture/v2' or record.get('arm') != arm
            or record.get('model') != model or record.get('lane') != lane or record.get('corpus_sha256') != corpus_sha
            or record.get('closed') is not True or not response_complete(record.get('response', {}), model)):
        raise ValueError('fixture identity/schema/work mismatch')
    return record


def persist_metrics(output, name, receipt, key):
    write_bytes(output / name, receipt['raw'].encode(), key)
    return hashlib.sha256(receipt['raw'].encode()).hexdigest()


def record_fixture(args, base, key, deadline, output, proof, proof_sha):
    rows, spec = lane_rows(args.lane, args.bodies, 'prime' if args.lane != 'warmup' else 'warmup', 1)
    if not 0 <= args.case_index < len(rows):
        raise ValueError('fixture case index outside frozen lane')
    case_id, body = rows[args.case_index]
    identity_before = capture_models(base, key, deadline)
    identity_before.update({'catalog_model': args.model, 'catalog_root': CANONICAL_MODEL_ID, 'response_model': CANONICAL_MODEL_ID})
    write_json(output, 'identity-before.json', identity_before, key)
    validate_models(identity_before, args.model)
    before = capture_metrics(base, key, deadline)
    before_sha = persist_metrics(output, 'before.prom', before, key)
    response = stream_request(base, key, args.model, body, deadline)
    response_sha = write_json(output, 'response.json', response, key)
    after = capture_metrics(base, key, deadline)
    after_sha = persist_metrics(output, 'after.prom', after, key)
    identity_after = capture_models(base, key, deadline)
    identity_after.update({'catalog_model': args.model, 'catalog_root': CANONICAL_MODEL_ID, 'response_model': CANONICAL_MODEL_ID})
    write_json(output, 'identity-after.json', identity_after, key)
    validate_models(identity_after, args.model)
    if not metrics_valid(before) or not metrics_valid(after):
        raise ValueError('current-native metric gate failed')
    record = {'schema': 'flare-upstream-current-response-fixture/v2', 'arm': args.arm, 'model': args.model,
              'lane': args.lane, 'case_id': case_id, 'corpus_sha256': spec['sha256'], 'response_sha256': response_sha,
              'incarnation_proof_sha256': proof_sha, 'incarnation_proof': proof,
              'requested_model': args.model, 'catalog_model': args.model, 'catalog_root': CANONICAL_MODEL_ID,
              'canonical_model': CANONICAL_MODEL_ID, 'response_model': CANONICAL_MODEL_ID, 'response': response,
              'metric_before': {'status': before['status'], 'error': before['error'], 'presence': before['presence'], 'raw_sha256': before_sha},
              'metric_after': {'status': after['status'], 'error': after['error'], 'presence': after['presence'], 'raw_sha256': after_sha},
              'closed': response_complete(response, args.model) and work_valid(args.lane, response)}
    if not record['closed']:
        raise ValueError('fixture retained but does not satisfy lane work contract')
    write_json(output, 'fixture.json', record, key)


def record_phase(args, base, key, deadline, output, proof, proof_sha):
    rows, spec = lane_rows(args.lane, args.bodies, args.phase, args.repeat)
    fixture = closed_fixture(args.fixture, args.model, args.arm, args.lane, spec['sha256'])
    plan = {'schema': 'flare-upstream-current-phase/v2', 'arm': args.arm, 'model': args.model, 'lane': args.lane,
            'phase': args.phase, 'repeat': args.repeat, 'expected': len(rows), 'case_ids': [case for case, _ in rows],
            'corpus_sha256': spec['sha256'], 'fixture_sha256': hashlib.sha256(bounded_read(args.fixture, MAX_IDENTITY_BYTES)).hexdigest(),
            'incarnation_proof_sha256': proof_sha, 'incarnation_proof': proof,
            'requested_model': args.model, 'catalog_model': args.model, 'catalog_root': CANONICAL_MODEL_ID,
            'canonical_model': CANONICAL_MODEL_ID, 'response_model': CANONICAL_MODEL_ID,
            'metric_rule': 'HTTP 200, error-free raw current-native reason-labelled presence; row/page pressure unknown unless separately measured'}
    write_json(output, 'plan.json', plan, key)
    attempts = []
    phase_error = None
    identity_after = None
    try:
        identity_before = capture_models(base, key, deadline)
        identity_before['catalog_model'] = args.model
        write_json(output, 'identity-before.json', identity_before, key)
        validate_models(identity_before, args.model)
        for serial, (case_id, body) in enumerate(rows):
            attempt = {'case_id': case_id, 'ok': False, 'response_path': f'{serial:03d}-response.json'}
            attempts.append(attempt)
            try:
                before = capture_metrics(base, key, deadline)
                before_sha = persist_metrics(output, f'{serial:03d}-before.prom', before, key)
                response = stream_request(base, key, args.model, body, deadline)
                response_sha = write_json(output, attempt['response_path'], response, key)
                after = capture_metrics(base, key, deadline)
                after_sha = persist_metrics(output, f'{serial:03d}-after.prom', after, key)
                attempt.update({'response_sha256': response_sha,
                                'metric_before': {'status': before['status'], 'error': before['error'], 'presence': before['presence'], 'raw_sha256': before_sha},
                                'metric_after': {'status': after['status'], 'error': after['error'], 'presence': after['presence'], 'raw_sha256': after_sha},
                                'completed': response_complete(response, args.model), 'work_valid': work_valid(args.lane, response)})
                attempt['ok'] = attempt['completed'] and attempt['work_valid'] and metrics_valid(before) and metrics_valid(after)
                if not attempt['ok']:
                    break
            except Exception as error:
                attempt['error'] = type(error).__name__
                break
    except Exception as error:
        phase_error = type(error).__name__
    finally:
        try:
            identity_after = capture_models(base, key, deadline)
            identity_after['catalog_model'] = args.model
            write_json(output, 'identity-after.json', identity_after, key)
            validate_models(identity_after, args.model)
        except Exception as error:
            attempts.append({'case_id': 'post-phase-identity', 'ok': False, 'error': type(error).__name__})
            if phase_error is None:
                phase_error = type(error).__name__
        attempted = len([a for a in attempts if a['case_id'] != 'post-phase-identity'])
        summary = {'expected': len(rows), 'attempted': attempted,
                   'completed': sum(a.get('completed') is True for a in attempts), 'work_valid': sum(a.get('work_valid') is True for a in attempts),
                   'failed': sum(a.get('ok') is False for a in attempts), 'missing': len(rows) - attempted,
                   'phase_error': phase_error, 'performance_eligible': False,
                   'fixture_response_sha256': fixture['response_sha256']}
        write_json(output, 'attempts.json', attempts, key)
        write_json(output, 'summary.json', summary, key)
    if phase_error or len(attempts) != len(rows) or not all(a.get('ok') for a in attempts):
        raise SystemExit(1)


def cli():
    parser = argparse.ArgumentParser(description=__doc__)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument('--arm', required=True, choices=('upstream_plus_compat25', 'conditional_row_share75'))
    common.add_argument('--base-url', required=True)
    common.add_argument('--model', required=True)
    common.add_argument('--api-key-env', required=True)
    common.add_argument('--incarnation-proof', required=True, type=Path)
    common.add_argument('--output', required=True, type=Path)
    common.add_argument('--deadline-epoch', required=True, type=float)
    commands = parser.add_subparsers(dest='command', required=True)
    fixture = commands.add_parser('fixture', parents=(common,))
    fixture.add_argument('--bodies', required=True, type=Path)
    fixture.add_argument('--lane', required=True, choices=tuple(LANES))
    fixture.add_argument('--case-index', type=int, default=0)
    phase = commands.add_parser('phase', parents=(common,))
    phase.add_argument('--fixture', required=True, type=Path)
    phase.add_argument('--bodies', required=True, type=Path)
    phase.add_argument('--lane', required=True, choices=tuple(LANES))
    phase.add_argument('--phase', required=True, choices=('prime', 'measured', 'warmup'))
    phase.add_argument('--repeat', required=True, type=int)
    args = parser.parse_args()
    try:
        base = parse_base_url(args.base_url)
        seconds = args.deadline_epoch - time.time()
        if not 15 <= seconds <= MAX_PHASE_SECONDS:
            raise ValueError('deadline must be 15..1800 seconds in the future')
        key = os.environ.get(args.api_key_env)
        if not key:
            raise ValueError('named API-key environment variable is unset')
        proof, proof_sha = load_incarnation(args.incarnation_proof, args.model, key)
        output = reserve_output(args.output)
        deadline = time.monotonic() + seconds
        with hard_deadline(seconds):
            if args.command == 'fixture':
                record_fixture(args, base, key, deadline, output, proof, proof_sha)
            else:
                record_phase(args, base, key, deadline, output, proof, proof_sha)
    except BaseException as error:
        if 'output' in locals() and output.exists():
            try:
                write_json(output, 'adapter-error.json', {'error': type(error).__name__}, locals().get('key', 'unavailable'))
            except Exception:
                pass
        parser.error(type(error).__name__)


if __name__ == '__main__':
    cli()
