"""Summarize only a CLOSED current-upstream baseline; no HTTP or lifecycle."""
import argparse
import os
import stat
import hashlib
import json
import math
from pathlib import Path
import re

EXPECTED = {
    '00-fixtures': {'adapter': 4, 'smoke': 1, 'phases': {}},
    '01-fixed1': {'adapter': 107, 'phases': {'warmup': 3, 'prime': 52, 'measured': 52}},
    '02-fixed1': {'adapter': 107, 'phases': {'warmup': 3, 'prime': 52, 'measured': 52}},
    '03-fixed1': {'adapter': 107, 'phases': {'warmup': 3, 'prime': 52, 'measured': 52}},
    '04-small12': {'adapter': 39, 'phases': {'warmup': 3, 'prime': 12, 'measured': 24}},
    '05-pageheavy': {'adapter': 27, 'phases': {'warmup': 3, 'prime': 12, 'measured': 12}},
}
MAX_READ = 8 << 20
CANONICAL = 'dec48abd33efa73c3bb7c95b74eee10cad34f9be'
CORPUS = {'fixed1':'199ce268f4d0f845ca0453706792778cfaaed6b2812ab2797a49561ca87739ca','small12':'199ce268f4d0f845ca0453706792778cfaaed6b2812ab2797a49561ca87739ca','pageheavy':'ac323a0ea8548c34ad5fc2cc5928f7c1e307400775df0c08050622beb7e2dc50','warmup':'c3a3571abc8a7b0fbefe2504ea6b2665abfc9ed3e9b6466dc8c78bf56981cf42'}
PROM = re.compile(r'^([A-Za-z_:][A-Za-z0-9_:]*(?:\{[^}]*\})?)\s+([-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)$')


def raw(path, issues, limit=MAX_READ):
    try:
        fd=os.open(path, os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)); before=os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size>limit: raise ValueError('unsafe_or_oversize')
        data=os.read(fd,limit+1); after=os.fstat(fd); os.close(fd)
        if len(data)>limit or (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns): raise ValueError('unstable_read')
        return data
    except (OSError,ValueError) as exc: issues.append({'path':str(path),'error':type(exc).__name__}); return None

def digest(path,issues):
    value=raw(path,issues); return hashlib.sha256(value).hexdigest() if value is not None else None

def read(path, issues):
    value=raw(path,issues)
    if value is None:return None,None
    try:return json.loads(value),hashlib.sha256(value).hexdigest()
    except json.JSONDecodeError as exc: issues.append({'path':str(path),'error':type(exc).__name__});return None,None


def nearest_rank(values):
    values = sorted(value for value in values if isinstance(value, (int, float)) and math.isfinite(value))
    if not values:
        return None
    return values[math.ceil(.95 * len(values)) - 1]


def distribution(values):
    values = [value for value in values if isinstance(value, (int, float)) and math.isfinite(value)]
    return {'count': len(values), 'median': sorted(values)[len(values)//2] if len(values) % 2 else (sorted(values)[len(values)//2-1] + sorted(values)[len(values)//2])/2 if values else None,
            'p95_nearest_rank': nearest_rank(values)}


def prom_values(path, issues):
    values = {}
    try:
        lines = (raw(path, issues) or b'').decode('utf-8','replace').splitlines()
    except OSError as exc:
        issues.append({'path': str(path), 'error': type(exc).__name__})
        return None
    for line in lines:
        match = PROM.match(line)
        if match:
            
            if match.group(1) in values: issues.append({'path':str(path),'error':'duplicate_metric'}); return None
            value=float(match.group(2))
            if not math.isfinite(value): issues.append({'path':str(path),'error':'nonfinite_metric'}); return None
            values[match.group(1)] = value
    return values


def cache_counter(key):
    name = key.split('{', 1)[0]
    return name.startswith('flare_host_cache_') and name.endswith(('_total', '_sum', '_count', '_bucket'))


def counter_delta(before, after):
    if before is None or after is None: return None
    keep = cache_counter
    before={k:v for k,v in before.items() if keep(k)}; after={k:v for k,v in after.items() if keep(k)}
    if not before or set(before)!=set(after) or any(after[k]<v for k,v in before.items()): return None
    return {k:after[k]-v for k,v in sorted(before.items())}


def prompt_ids(response):
    for record in response.get('events', []):
        event = record.get('event') if isinstance(record, dict) else None
        ids = event.get('prompt_token_ids') if isinstance(event, dict) else None
        if isinstance(ids, list) and all(type(value) is int for value in ids):
            return ids
    return None


def output_timestamps(response):
    values = []
    found = False
    for record in response.get('events', []):
        event = record.get('event') if isinstance(record, dict) else None
        choices = event.get('choices') if isinstance(event, dict) else None
        if not isinstance(choices, list):
            continue
        for choice in choices:
            timestamps = choice.get('token_timestamps_ns') if isinstance(choice, dict) else None
            if timestamps is not None:
                found = True
                if not isinstance(timestamps, list) or not all(type(value) is int for value in timestamps):
                    return None
                values.extend(timestamps)
    return values if found else None


def response_record(path, issues):
    response, response_sha = read(path, issues)
    if not isinstance(response, dict):
        return {'valid': False, 'response_sha256': response_sha}
    ids = response.get('output_token_ids')
    usage = response.get('usage')
    valid_ids = isinstance(ids, list) and all(type(value) is int for value in ids)
    timing_ok = all(type(response.get(x)) in (int,float) and math.isfinite(response[x]) for x in ('client_generated_ttft_seconds','e2e_seconds'))
    performance = response.get('performance')
    performance_fields = ({name: performance.get(name) for name in ('enqueue_ns', 'ingress_ns', 'reused_prompt_tokens')}
                          if isinstance(performance, dict) else None)
    return {'valid': response.get('error') is None and response.get('complete') is True and response.get('http_status') == 200 and valid_ids and timing_ok and isinstance(usage, dict) and type(usage.get('completion_tokens')) is int and usage['completion_tokens'] == len(ids),
            'response_sha256': response_sha, 'body_sha256': response.get('body_sha256'),
            'output_token_ids': ids if valid_ids else None, 'prompt_token_ids': prompt_ids(response),
            'output_token_timestamps_ns': output_timestamps(response),
            'usage_completion_tokens': usage.get('completion_tokens') if isinstance(usage, dict) else None,
            'native_performance': performance_fields,
            'work_dimensions': {'speculative': 'unknown:not_observed_in_current_response_schema',
                                'accepted': 'unknown:not_observed_in_current_response_schema',
                                'emitted': 'unknown:not_observed_in_current_response_schema'},
            'client_generated_ttft_seconds': response.get('client_generated_ttft_seconds'),
            'e2e_seconds': response.get('e2e_seconds')}


def expected_case_ids(incarnation, phase):
    lane='fixed1' if incarnation.endswith('fixed1') else 'small12' if incarnation=='04-small12' else 'pageheavy'
    if phase=='warmup': return [f'{i}:0' for i in range(3)]
    base=list(range(52)) if lane=='fixed1' else list(range(40,52)) if lane=='small12' else list(range(12))
    if phase=='measured' and lane=='fixed1': base.reverse()
    repeat=2 if phase=='measured' and lane=='small12' else 1
    return [f'{i}:{cycle}' for cycle in range(repeat) for i in base]

def phase(root, incarnation, name, expected, issues):
    http = root / incarnation / name / 'http'
    summary, summary_sha = read(http / 'summary.json', issues)
    attempts, attempts_sha = read(http / 'attempts.json', issues)
    result = {'expected': expected, 'summary_sha256': summary_sha, 'attempts_sha256': attempts_sha,
              'summary': summary if isinstance(summary, dict) else None, 'attempts': [],
              'ttft': distribution([]), 'e2e': distribution([]), 'native_counter_deltas': [], 'complete': False}
    if not isinstance(attempts, list):
        return result
    ttft, e2e = [], []
    for index, attempt in enumerate(attempts):
        row = {'index': index, 'case_id': attempt.get('case_id') if isinstance(attempt, dict) else None,
               'attempt_ok': attempt.get('ok') is True if isinstance(attempt, dict) else False}
        if not isinstance(attempt, dict) or attempt.get('response_path') != f'{index:03d}-response.json':
            row['error'] = attempt.get('error') if isinstance(attempt, dict) else 'invalid_attempt'
            result['attempts'].append(row); continue
        response = response_record(http / attempt['response_path'], issues)
        row.update(response)
        before = prom_values(http / f'{index:03d}-before.prom', issues)
        after = prom_values(http / f'{index:03d}-after.prom', issues)
        delta = counter_delta(before, after)
        row['native_counter_delta'] = delta
        row['native_metric_complete'] = delta is not None
        row['native_gauges_before'] = {k:v for k,v in (before or {}).items() if not cache_counter(k)}
        row['native_gauges_after'] = {k:v for k,v in (after or {}).items() if not cache_counter(k)}
        row['reason_labelled_cache_delta'] = ({key: value for key, value in (delta or {}).items() if key.startswith('flare_host_cache_') and 'reason=' in key} if delta is not None else None)
        result['attempts'].append(row)
        if row['valid'] and isinstance(row['client_generated_ttft_seconds'], (int, float)): ttft.append(row['client_generated_ttft_seconds'])
        if row['valid'] and isinstance(row['e2e_seconds'], (int, float)): e2e.append(row['e2e_seconds'])
        if delta is not None: result['native_counter_deltas'].append(delta)
    result['ttft'], result['e2e'] = distribution(ttft), distribution(e2e)
    required = {'expected': expected, 'attempted': expected, 'completed': expected, 'work_valid': expected, 'failed': 0, 'missing': 0}
    result['complete'] = isinstance(summary, dict) and summary.get('phase_error') is None and all(summary.get(key) == value for key, value in required.items()) and len(result['attempts']) == expected and [row.get('case_id') for row in result['attempts']] == expected_case_ids(incarnation, name) and all(row.get('attempt_ok') and row.get('valid') and row.get('native_metric_complete') for row in result['attempts'])
    return result


def exact_equal(left, right):
    """Return unknown for absent dimensions; never turn two absent fields into a match."""
    if left is None or right is None:
        return None
    return left == right


def fixed1_bounded_gate(prime, measured):
    by_case = {row.get('case_id'): row for row in prime['attempts'] if row.get('valid')}
    rows = []
    counts = {name: {'known': 0, 'equal': 0} for name in ('output_token_ids', 'prompt_token_ids', 'body_sha256', 'completion_tokens')}
    one_output = {'known': 0, 'equal': 0}
    for candidate in measured['attempts']:
        base = by_case.get(candidate.get('case_id'))
        if base is None or not candidate.get('valid'):
            rows.append({'case_id': candidate.get('case_id'), 'valid_pair': False,
                         'reason': 'missing_or_invalid'})
            continue
        comparisons = {
            'output_token_ids': exact_equal(base['output_token_ids'], candidate['output_token_ids']),
            'prompt_token_ids': exact_equal(base['prompt_token_ids'], candidate['prompt_token_ids']),
            'body_sha256': exact_equal(base['body_sha256'], candidate['body_sha256']),
            'completion_tokens': exact_equal(base['usage_completion_tokens'], candidate['usage_completion_tokens']),
        }
        for name, value in comparisons.items():
            if value is not None:
                counts[name]['known'] += 1
                counts[name]['equal'] += int(value)
        one_output_equal = None
        if comparisons['output_token_ids'] is not None:
            one_output['known'] += 1
            one_output_equal = (comparisons['output_token_ids'] is True
                                and len(base['output_token_ids']) == 1
                                and len(candidate['output_token_ids']) == 1
                                and base['usage_completion_tokens'] == 1
                                and candidate['usage_completion_tokens'] == 1)
            one_output['equal'] += int(one_output_equal)
        rows.append({'case_id': candidate['case_id'], 'valid_pair': True,
                     'output_token_ids_equal': comparisons['output_token_ids'],
                     'prompt_token_ids_equal': comparisons['prompt_token_ids'],
                     'body_sha256_equal': comparisons['body_sha256'],
                     'completion_tokens_equal': comparisons['completion_tokens'],
                     'bounded_one_output_gate': one_output_equal,
                     'speculative_work_equal': None,
                     'speculative_work_status': 'unknown:not_observed_in_current_response_schema',
                     'ttft_delta_seconds': candidate['client_generated_ttft_seconds'] - base['client_generated_ttft_seconds']
                                           if one_output_equal is True else None})
    return {'expected_pairs': 52, 'valid_pairs': sum(row.get('valid_pair') is True for row in rows),
            'dimension_counts': counts, 'bounded_one_output_gate': one_output,
            'full_speculative_work_match': {'status': 'unknown:not_observed_in_current_response_schema'},
            'rows': rows}


def valid_proof(value, model, image):
    v=value.get('verified') if isinstance(value,dict) else None
    return isinstance(v,dict) and v.get('running') is True and v.get('served_identity') == model and v.get('image_digest') == image and v.get('revision') == CANONICAL and isinstance(v.get('container_id'),str) and bool(v.get('container_id')) and isinstance(v.get('started_at'),str) and bool(v.get('started_at')) and value.get('recipe_sha256') == 'a7722a9591c7255fe4c3f73750de212136095db2a2d3c8f857a41f5eb250d343' and value.get('registry_sha256') == 'ac8f679cf6560bab1d459d33b55a0cb064ccec898d6e58c282a08777664179b6'

def valid_fixture(value, lane, model, proof_sha, response_sha):
    return isinstance(value,dict) and value.get('schema')=='flare-upstream-current-response-fixture/v2' and value.get('closed') is True and value.get('lane')==lane and value.get('model')==model and value.get('requested_model')==model and value.get('catalog_model')==model and value.get('catalog_root')==CANONICAL and value.get('canonical_model')==CANONICAL and value.get('response_model')==CANONICAL and value.get('corpus_sha256')==CORPUS[lane] and value.get('incarnation_proof_sha256')==proof_sha and value.get('response_sha256')==response_sha

def valid_smoke(value, model):
    obs=value.get('observations') if isinstance(value,dict) else None
    return isinstance(value,dict) and value.get('schema_version')=='preflight/v2' and value.get('model')==model and value.get('passed') is True and value.get('checks')==['smoke'] and isinstance(obs,list) and len(obs)==1 and obs[0].get('test')=='smoke' and obs[0].get('passed') is True

def build(root):
    root = Path(root)
    issues=[]
    closeout, closeout_sha = read(root / 'closeout.json', issues)
    closure_ok=isinstance(closeout,dict) and closeout.get('restored') is True and closeout.get('experiment_error') is None and closeout.get('recovery_errors') == [] and closeout.get('wall_deadline_met') is True and closeout.get('recovery_required') is True
    window, window_sha = read(root / 'window.json', issues)
    if not isinstance(window, dict):
        raise ValueError('window.json invalid')
    if window.get('adapter_requests_planned') != 391 or window.get('smoke_requests_planned') != 1 or window.get('incarnations') != 6:
        raise ValueError('unexpected baseline denominator contract')
    incarnations, adapter_observed = {}, 0
    for name, contract in EXPECTED.items():
        node = {'expected_adapter_requests': contract['adapter'], 'phases': {}, 'hashes': {}}
        proof = root / name / 'owner-proof.json'
        proof_value, proof_sha = read(proof, issues); node['hashes']['owner_proof'] = proof_sha
        node['owner_proof_valid'] = valid_proof(proof_value, window.get('model'), window.get('image'))
        complete_value, complete_sha = read(root/name/'complete.json', issues)
        node['hashes']['complete'] = complete_sha
        verified=proof_value.get('verified',{}) if isinstance(proof_value,dict) else {}
        node['complete_valid'] = isinstance(complete_value,dict) and complete_value.get('container_id') == verified.get('container_id') and complete_value.get('expected_adapter_requests') == contract['adapter'] and isinstance(complete_value.get('generation'),str) and bool(complete_value.get('generation'))
        if name == '00-fixtures':
            for lane in ('fixed1', 'small12', 'pageheavy', 'warmup'):
                fixture = root / name / ('fixture-' + lane) / 'http' / 'fixture.json'
                response = root / name / ('fixture-' + lane) / 'http' / 'response.json'
                value, fsha=read(fixture,issues); response_sha=digest(response,issues)
                fixture_proof, fixture_proof_sha = read(fixture.parent.parent/'owner-proof.json', issues)
                same_incarnation = valid_proof(fixture_proof, window.get('model'), window.get('image')) and all(fixture_proof['verified'].get(k) == proof_value['verified'].get(k) for k in ('container_id', 'started_at'))
                node.setdefault('fixtures', {})[lane] = {'fixture_sha256': fsha, 'owner_proof_sha256': fixture_proof_sha, 'valid': same_incarnation and isinstance(value,dict) and value.get('incarnation_proof') == fixture_proof and valid_fixture(value,lane,window.get('model'),fixture_proof_sha,response_sha), 'response': response_record(response, issues)}
            smoke,_=read(root/name/'smoke'/'result.json',issues); node['smoke']={'observed':smoke is not None,'passed':valid_smoke(smoke,window.get('model'))}
            adapter_observed += sum(1 for item in node['fixtures'].values() if item['response'] is not None)
        else:
            for phase_name, expected in contract['phases'].items():
                item = phase(root, name, phase_name, expected, issues)
                node['phases'][phase_name] = item
                adapter_observed += len(item['attempts'])
            node['fixed1_bounded_gate'] = fixed1_bounded_gate(node['phases']['prime'], node['phases']['measured']) if name.endswith('fixed1') else None
        incarnations[name] = node
    return {'schema': 'flare-current-baseline-summary/v1', 'source_root': str(root),
            'source_hashes': {'window.json': window_sha, 'closeout.json': closeout_sha}, 'closure': {'valid': closure_ok, 'record': closeout},
            'denominators': {'adapter_expected': 391, 'adapter_observed': adapter_observed, 'smoke_expected': 1, 'incarnations_expected': 6},
            'identity': {'window_model': window.get('model'), 'image': window.get('image'), 'boundary_sha256': window.get('boundary_sha256')},
            'comparison_context': {'driver': '615.71.10', 'prior_campaign': '2026-10-22-flare-cache-fix'},
            'incarnations': incarnations, 'issues': issues,
            'complete': closure_ok and not issues and adapter_observed == 391 and all(node.get('owner_proof_valid') is True for node in incarnations.values()) and len({node.get('hashes',{}).get('owner_proof') for node in incarnations.values()}) == 6 and all(node.get('complete_valid') is True for node in incarnations.values()) and len({(read(root/name/'owner-proof.json',[])[0] or {}).get('verified',{}).get('container_id') for name in EXPECTED}) == 6 and set(closeout.get('container_ids',[])) == {(read(root/name/'owner-proof.json',[])[0] or {}).get('verified',{}).get('container_id') for name in EXPECTED} and len(set(closeout.get('generations',[]))) == 6 and set(closeout.get('generations',[])) == {read(root/name/'complete.json',[])[0].get('generation') for name in EXPECTED} and all(x.get('valid') is True and x.get('response',{}).get('valid') is True for x in incarnations['00-fixtures']['fixtures'].values()) and incarnations['00-fixtures']['smoke']['passed'] is True and all(all(x['complete'] for x in node['phases'].values()) for node in incarnations.values() if node['phases']), 'metric_limits': {'row_page_pressure': 'unknown: current-native reason-labelled counter families only', 'causal_claim': False, 'performance_eligible': False, 'promoted': False}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists(): raise ValueError('refuse overwrite')
    report = build(args.root)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')

if __name__ == '__main__': main()
