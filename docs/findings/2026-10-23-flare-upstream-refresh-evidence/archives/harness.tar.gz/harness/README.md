# Upstream refresh harness

This directory is offline preparation only. `frozen-prior/` is copied from the
closed cache-fix harness; it is not a new workload. `analyze-upstream.py` is the
retained protected-bracket analyzer, to be run only after the lifecycle owner
closes a new result directory with the same per-incarnation layout.

Run the only local preparation check with `python3 check-plan.py`. It does not
contact a model, load an image, or create an output directory. The lifecycle
owner must bind the upstream-plus-compat25 source, image, package, registry, geometry, and cold
state before any request.

`analyze-upstream.py` is a frozen protected-lane baseline. A fixed1 normalizer must wait for one closed current-schema fixture; this plan makes no response-shape assumption.

## Current-baseline gate

`plan-r1.json` is the immutable initial count/provenance record. The active
plan uses `upstream_plus_compat25`: current upstream plus the smallest legacy
GLM-template compatibility patch required for startup. It is not pristine
upstream, and it is not an allocator patch. A 75% row-share candidate remains
conditional and unimplemented until the compatible baseline reproduces the
need.

Current native #38 exposes raw host decision metrics with the exact label
`reason`; the plan retains their raw exposition and a presence receipt. It does
not require or synthesize old row/page-pressure counter families. Row or page
pressure is unknown unless a separate measurement establishes it.

## Current-baseline adapter

`baseline-adapter.py` reuses the frozen body JSON and SSE receipt shape, while
requiring explicit arm, model, loopback port, body path, and fresh output path.
It has no lifecycle logic. It writes raw before/after Prometheus receipts and
checks only current-native host metric families; the lookup label is exactly
`reason`. It never assumes a retired row- or page-pressure metric.

The first permitted HTTP action is one closed fixture, followed only by an
approved phase. Substitute the managed arm's exact loopback port, model alias,
and the **name** of its existing secret environment variable; do not put a key
in a command or artifact. Both output directories must not exist.

```sh
python3 baseline-adapter.py fixture --arm upstream_plus_compat25 --base-url http://127.0.0.1:PORT --model MODEL --api-key-env API_KEY_ENV --incarnation-proof OWNER_PROOF.json --deadline-epoch DEADLINE_EPOCH --bodies frozen-prior/fixed1-bodies.json --lane fixed1 --case-index 0 --output ../formal/current-baseline/fixture
python3 baseline-adapter.py phase --arm upstream_plus_compat25 --base-url http://127.0.0.1:PORT --model MODEL --api-key-env API_KEY_ENV --incarnation-proof OWNER_PROOF.json --deadline-epoch DEADLINE_EPOCH --fixture ../formal/current-baseline/fixture/fixture.json --bodies frozen-prior/fixed1-bodies.json --lane fixed1 --phase prime --repeat 1 --output ../formal/current-baseline/fixed1-prime
```

The phase command rejects a fixture from a different arm, model, lane, or corpus; it requires the lifecycle owner's verified-incarnation receipt and an absolute 15–1800 second deadline. It reserves the output directory before network activity, binds frozen count/case/order/warmup extraction, and records all attempted failures and partial response receipts. It does not imply performance eligibility. Use
`python3 check-baseline-adapter.py` for the offline check; it uses an ephemeral synthetic loopback HTTP server and makes no live model or
lifecycle call.
