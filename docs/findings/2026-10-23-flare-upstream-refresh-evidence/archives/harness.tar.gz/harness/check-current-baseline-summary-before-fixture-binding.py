"""Offline failure-sensitive contract check for summarize-current-baseline.py."""
import importlib.util
import json
from pathlib import Path
import tempfile

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('summary', ROOT / 'summarize-current-baseline.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
PROM = '\n'.join((
    'flare_host_cache_lookup_outcomes_total{reason="hit"} 1',
    'flare_host_cache_store_reasons_total{reason="ok"} 2',
    'flare_host_cache_row_refills_total 3',
    'flare_host_cache_missing_tokens_total 0',
    'flare_host_cache_estimated_transfer_ns_sum 4',
    'flare_host_cache_estimated_prefill_ns_sum 5',
    'flare_host_cache_missing_tokens_bucket{le="+Inf"} 6',
    'flare_host_cache_rows 8',
)) + '\n'

def response(valid=True):
    return {'http_status': 200, 'complete': valid, 'error': None if valid else {'kind':'ValueError'},
            'body_sha256':'body','output_token_ids':[7], 'usage':{'completion_tokens':1},
            'client_generated_ttft_seconds':.1, 'e2e_seconds':.2,
            'performance': {'enqueue_ns': 2, 'ingress_ns': 1, 'reused_prompt_tokens': 0},
            'events':[{'event':{'prompt_token_ids':[1,2], 'choices':[{'token_timestamps_ns':[3]}]}}]}

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True); path.write_text(json.dumps(value))

def phase(root, inc, name, expected, invalid=False):
    http=root/inc/name/'http'; attempts=[]
    for index in range(expected):
        rpath=f'{index:03d}-response.json'; write(http/rpath,response(not invalid));
        (http/f'{index:03d}-before.prom').write_text(PROM)
        (http/f'{index:03d}-after.prom').write_text(PROM.replace('} 1','} 2',1).replace('} 6','} 7').replace('rows 8','rows 7'))
        attempts.append({'case_id':m.expected_case_ids(inc,name)[index], 'ok':not invalid, 'response_path':rpath})
    write(http/'attempts.json',attempts)
    write(http/'summary.json',{'expected':expected,'attempted':expected,'completed':expected if not invalid else 0,
                               'work_valid':expected if not invalid else 0,'failed':0 if not invalid else expected,'missing':0})

with tempfile.TemporaryDirectory() as raw:
    root=Path(raw); write(root/'closeout.json',{'restored':True,'experiment_error':None,'recovery_errors':[],'wall_deadline_met':True,'recovery_required':True,'container_ids':list(m.EXPECTED),'generations':['g'+x for x in m.EXPECTED]}); write(root/'window.json',{'adapter_requests_planned':391,'smoke_requests_planned':1,'incarnations':6,'model':'m','image':'i','boundary_sha256':'b'})
    for inc, contract in m.EXPECTED.items():
        write(root/inc/'owner-proof.json',{'verified':{'running':True,'served_identity':'m','container_id':inc,'revision':m.CANONICAL,'image_digest':'i','started_at':'s'},'recipe_sha256':'a7722a9591c7255fe4c3f73750de212136095db2a2d3c8f857a41f5eb250d343','registry_sha256':'ac8f679cf6560bab1d459d33b55a0cb064ccec898d6e58c282a08777664179b6'})
        write(root/inc/'complete.json',{'container_id':inc,'generation':'g'+inc,'expected_adapter_requests':contract['adapter']})
        if inc == '00-fixtures':
            for lane in ('fixed1','small12','pageheavy','warmup'):
                write(root/inc/f'fixture-{lane}'/'http'/'response.json',response())
                import hashlib
                rp=root/inc/f'fixture-{lane}'/'http'/'response.json'; fp=root/inc/f'fixture-{lane}'/'http'/'fixture.json'; write(fp,{'schema':'flare-upstream-current-response-fixture/v2','closed':True,'lane':lane,'model':'m','requested_model':'m','catalog_model':'m','catalog_root':m.CANONICAL,'canonical_model':m.CANONICAL,'response_model':m.CANONICAL,'corpus_sha256':m.CORPUS[lane],'incarnation_proof_sha256':hashlib.sha256((root/inc/'owner-proof.json').read_bytes()).hexdigest(),'response_sha256':hashlib.sha256(rp.read_bytes()).hexdigest()})
            write(root/inc/'smoke'/'result.json',{'schema_version':'preflight/v2','model':'m','passed':True,'checks':['smoke'],'observations':[{'test':'smoke','passed':True}]})
        else:
            for name, expected in contract['phases'].items(): phase(root,inc,name,expected)
    original_closeout=json.loads((root/'closeout.json').read_text())
    report=m.build(root)
    assert report['complete'] is True, report['issues']
    first=report['incarnations']['01-fixed1']['phases']['prime']['attempts'][0]
    assert first['native_counter_delta']['flare_host_cache_lookup_outcomes_total{reason="hit"}']==1
    assert first['native_counter_delta']['flare_host_cache_missing_tokens_bucket{le="+Inf"}']==1
    assert first['native_gauges_before']['flare_host_cache_rows']==8
    assert first['native_gauges_after']['flare_host_cache_rows']==7
    assert report['denominators']['adapter_expected']==391 and report['denominators']['adapter_observed']==391
    gate=report['incarnations']['01-fixed1']['fixed1_bounded_gate']
    assert gate['bounded_one_output_gate']['equal']==52
    assert gate['full_speculative_work_match']['status'].startswith('unknown:')
    assert report['metric_limits']['performance_eligible'] is False
    assert report['incarnations']['01-fixed1']['phases']['prime']['attempts'][0]['work_dimensions']['speculative'].startswith('unknown:')
    write(root/'closeout.json',{})
    assert m.build(root)['complete'] is False
    write(root/'closeout.json',original_closeout)
    assert m.build(root)['complete'] is True
    attempts=json.loads((root/'04-small12'/'prime'/'http'/'attempts.json').read_text()); attempts[1]['case_id']=attempts[0]['case_id']; write(root/'04-small12'/'prime'/'http'/'attempts.json',attempts)
    assert m.build(root)['complete'] is False
    attempts[1]['case_id']='41:0'; write(root/'04-small12'/'prime'/'http'/'attempts.json',attempts)
    assert m.build(root)['complete'] is True
    fixture=root/'00-fixtures'/'fixture-fixed1'/'http'/'fixture.json'; value=json.loads(fixture.read_text()); value['closed']=False; write(fixture,value)
    assert m.build(root)['complete'] is False
    value['closed']=True; write(fixture,value)
    assert m.build(root)['complete'] is True
    proof=root/'02-fixed1'/'owner-proof.json'; original=json.loads(proof.read_text())
    changed=json.loads(proof.read_text()); changed['verified']['container_id']='01-fixed1'; write(proof,changed)
    assert m.build(root)['complete'] is False
    write(proof,original)
    assert m.build(root)['complete'] is True
    target=root/'01-fixed1'/'measured'/'http'/'000-response.json'
    write(target,response(False))
    report=m.build(root)
    item=report['incarnations']['01-fixed1']['phases']['measured']
    assert not item['complete'] and item['attempts'][0]['valid'] is False
    assert report['incarnations']['01-fixed1']['fixed1_bounded_gate']['bounded_one_output_gate']['equal'] < 52
print(json.dumps({'ok':True,'network':False,'lifecycle':False,'failure_visible':True}))
