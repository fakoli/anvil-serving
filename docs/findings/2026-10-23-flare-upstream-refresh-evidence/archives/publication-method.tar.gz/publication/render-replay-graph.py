"""Offline custom-schema adapter using the unchanged product SVG renderer."""
import hashlib
import importlib.util
import json
from pathlib import Path

N = Path(__file__).resolve().parents[1]
HELPER = Path('OPERATOR_PATH_b2b97c6c5a4e/plot_benchmark_matrix.py')
D = N / 'publication/source-docs'
raw = (D / 'summary.json').read_bytes()
source = json.loads(raw)
if source['schema'] != 'flare-upstream-refresh-decision/v1' or source['complete'] is not True:
    raise ValueError('closed native decision summary required')
points = []
for i in range(1, 4):
    key = f'{i:02d}-fixed1'
    cell = source['cells'][key]
    if cell['count'] != 52 or cell['one_token_output_matches'] != 52:
        raise ValueError('exact 52-request replay required')
    points.append({'x': f'Repetition {i}', 'value': cell['median_ttft_ms'],
                   'artifact': 'summary.json', 'artifact_sha256': hashlib.sha256(raw).hexdigest(),
                   'metric': f'cells.{key}.median_ttft_ms', 'sample_count': 52})
data = {'schema': 'anvil-serving.benchmark-graph-data/v1',
        'title': 'Current compatible Flare baseline: reverse replay',
        'subtitle': 'Same configuration, three fresh incarnations; 52 one-token requests each. Diagnostic only.',
        'metric_semantics': {'timing': 'Client time to first generated-token event, milliseconds; median within each complete replay population.',
                             'comparison': 'Repetitions, not a two-arm improvement; protected warm lanes excluded.',
                             'qualification': 'False; full speculative work unknown, historical sampled-output equality gate remains failed.'},
        'native_source_schema': source['schema'],
        'renderer_sha256': hashlib.sha256(HELPER.read_bytes()).hexdigest(),
        'charts': [{'title': 'Client first-generated-token latency', 'metric': 'per-point exact paths',
                    'x_label': 'Fresh incarnation', 'y_label': 'Median TTFT (ms)',
                    'series': [{'label': 'Current upstream + compatibility, 25%', 'points': points}]}]}
spec = importlib.util.spec_from_file_location('retained_graph_renderer', HELPER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
out = D / 'graphs'; out.mkdir(exist_ok=True)
svg = module._svg(data)
(out / 'replay.svg').write_text(svg)
(out / 'replay-data.json').write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
print(json.dumps({'svg_sha256': hashlib.sha256(svg.encode()).hexdigest(),
                  'data_sha256': hashlib.sha256((out/'replay-data.json').read_bytes()).hexdigest()}))
