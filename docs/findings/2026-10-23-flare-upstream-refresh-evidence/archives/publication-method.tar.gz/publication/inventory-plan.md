# Upstream refresh publication inventory plan

Status: preparation only. The canonical baseline is active; exact closed-source inventory, outcome analysis, privacy acceptance, bundle generation, documentation edits and hosting are deferred. This plan does not authorize lifecycle, publication or upstream submission. Root owns execution. Preserve all predecessor evidence and other writers' files.

## Helper provenance and bounded changes

`publish-evidence.py` derives from `../2026-10-23-flare-state-diagnostics/publication/publish-evidence.py`, SHA256 `110a20ad1b59c0bbb25dc5c17d3e97d85c4c3358614790601a29aabd30f8b3d4`. Its existing imported deterministic redactor remains `../2026-10-21-flare-inference-diagnostics/wave-v1/publish-evidence.py`; freeze that dependency at closure too.

Changes are campaign docstring/schema (`flare-upstream-refresh-publication-inventory/v1`), deterministic pseudonymization of `/root/…` verification-profile/key-reference paths before the inherited scrubber, and emitting relative string paths in the manifest-source role ledger as the product finalizer requires. Provenance retains original/private source hashes, sanitized payload hashes, compressed public hashes and archive-member identities. Native schemas and negative results are preserved; this does not manufacture `benchmark/v1` evidence.

Unchanged: explicit source selection only; UTF-8 text inputs; JSON/JSONL parse validation; contained regular source paths with symlink-ancestor rejection; new contained output directory only; normalized duplicate/reserved/prefix-colliding public path rejection; deterministic USTAR members with fixed metadata and gzip mtime zero; container IDs collected from all selected structured sources, including archive inputs. Archives preserve directory-relative names, not basenames. USTAR member names are bounded to 100 bytes; use reviewed provenance-bound short aliases for longer source names, retaining originals privately. Do not silently omit them.

## Required closed-source selection

After all producers stop, review an explicit `final-inventory.json` (no live glob selection):

- Upstream issues/PR inventory and reviews, observed-time/source SHA pins, pristine baseline/build provenance, exact compatibility commit/diff and focused tests. Include relevant `source/`, `review/upstream-*.md`, `review/legacy-glm-compat-*`, and registry/image identity. Do not include build binaries or package weights as text artifacts.
- All three predecessor windows: `formal/current-baseline`, `formal/current-baseline-driver6157110`, `formal/current-baseline-monitorfix`. Include their partial/failed requests, logs, commands, identities and cleanup/restoration. They remain failed attempts; later adaptation cannot retroactively pass them.
- Driver recovery and validation: `formal/post-driver-restoration`, `formal/post-driver-restoration-validated`, and relevant `runtime/driver-*`, `runtime/post-driver-*`, associated review receipts. Preserve the driver 615.71.09 to 615.71.10 boundary; no causal code-only comparison to older timing.
- Monitoring and wire-contract corrections: `runtime/monitor-contract-correction.json`, `review/monitor-registration-diagnosis.md`, `review/stream-model-identity-diagnosis.md`, predecessor/final adapter checks and independent reviews. Catalog alias, catalog root and canonical response model have distinct exact identities; do not describe the collector schema mismatch as a proven server defect.
- Complete closed `formal/current-baseline-canonical`: every fixture/warmup/prime/measured raw response, before/after metrics, request accounting, status samples, owner proofs, signed startup evidence, monitoring generations/readiness/ranges, failures, unloads and exact incumbent restoration/direct+routed preflight/readmission receipts. Keep all denominators. Planned 391 adapter requests plus smoke are not completed counts.
- Frozen corpus/body bytes or their reviewed reconstruction copies, exact hashes, selection/order and workload contracts. Include final adapter/check/analyzer, source action/plan/boundary and prior revisions used by failed attempts. Exclude any credential file referenced by these records.
- Final independently reviewed analysis, bounded summary, source registry, friction/disposition record, restoration summary and coverage gaps. Private `report.md` is the detailed operator record; public prose is a separately sanitized derivative.

Every selected source is accounted for once in the source selection receipt; multiple semantic roles may reference one public artifact without implying independent evidence. Put directly linked analyses, indexes and reconstruction instructions in direct artifacts; use deterministic archives for bulky native trees. Check direct Markdown links, gzip link targets and archive member references after staging. No source is dropped to meet size limits. Measure actual compressed sizes before recording a verified size policy.

## Privacy mapping and limitations

Mapping is deterministic and must be independently checked against the final selected corpus, including archives:

| Private input class | Public replacement |
| --- | --- |
| Known host/tailnet labels | inherited synthetic primary/secondary/companion/mobile node and example domain labels |
| `/data/…`, `/home/…`, `/run/…` references | inherited `OPERATOR_PATH_<hash>/<basename>` pseudonyms |
| `/root/…` references, including verification profile/key mount paths | `OPERATOR_PATH_<hash>` (no basename) |
| Non-loopback private/tailnet IPv4 | deterministic synthetic `100.64.0.x` address |
| UUIDs and GPU-prefixed truncated UUID fragments | deterministic synthetic identifiers/device pseudonyms |
| Collected container IDs | sorted deterministic `container-N` aliases |
| Known operator name | inherited generic operator label |

These are source-reference transformations, never permission to inspect a credential file. No actual secret file, account grant, signing key, protected API key or shared environment file enters selection or redactor inputs. The inherited scrubber is not a general secret detector, arbitrary-hostname sanitizer or IPv6 privacy proof. Independently scan rendered text, JSON keys/values, JSONL, archive members/names, filenames, code literals and compressed payloads for current identities and secrets before acceptance. Record explicit exceptions only after exact contextual review. Preserve private originals and hash mapping; publish no raw private identity map. New identities or paths not covered by the reviewed mapping are blockers, not automatically safe.

## Artifact roles and deferred completion

Use the canonical benchmark-docs artifact-set contract. Exactly ten roles: evidence-index, source-registry, workload-manifest, run-plan, configuration-and-identity, raw-run-evidence, failures-and-friction, restoration, decision-summary, publication-summary. Final statuses are retained, missing, or not-applicable with a reason; never pending. Missing captures remain missing. A public social-copy summary is not required for this diagnostic; if absent, declare publication-summary not-applicable explicitly.

After independent selection/privacy preparation review, run the helper with a reviewed inventory and a NEW output path, then the product finalizer twice and require identical manifest bytes. The finalizer checks the closed inventory and computes public hashes; source role files are relative strings. Final privacy review follows actual staging and covers both payload and public documents. No bundle, full test suite, hosting or source publication is performed during measurement. This preparation has only an offline AST syntax check; synthetic/corpus validation is deferred to the independent reviewer and closure stage. All qualification/promotion claims remain separate and false unless established by their own evidence and authority.
