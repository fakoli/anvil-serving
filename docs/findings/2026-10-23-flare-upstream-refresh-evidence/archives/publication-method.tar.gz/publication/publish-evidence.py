"""Offline, inventory-driven sanitizer for the Flare upstream refresh public bundle."""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import tarfile
import re
from pathlib import Path

E = Path(__file__).resolve().parents[1]
PRIOR = E.parent / "2026-10-21-flare-inference-diagnostics" / "wave-v1" / "publish-evidence.py"
ROLES = ("evidence-index", "source-registry", "workload-manifest", "run-plan", "configuration-and-identity", "raw-run-evidence", "failures-and-friction", "restoration", "decision-summary", "publication-summary")
GENERATED = ("provenance.json", "artifact-manifest-source.json", "artifact-manifest.json")

def load_redactor():
    spec = importlib.util.spec_from_file_location("flare_prior_redactor", PRIOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    prior_scrub = module.scrub
    def scrub(text):
        # The retained image uses a verification profile below /root; do not
        # publish that private mount/key-reference path. Never read its file.
        text = re.sub(r"/root/[A-Za-z0-9_./:@+%-]+",
                      lambda match: "OPERATOR_PATH_" + digest(match.group().encode())[:12], text)
        return prior_scrub(text)
    module.scrub = scrub
    return module

def digest(data):
    return hashlib.sha256(data).hexdigest()

def safe_relative(value):
    if not isinstance(value, str) or not value or "\\" in value or (len(value) > 1 and value[1] == ":"):
        raise ValueError("unsafe relative path")
    path = Path(value)
    if path.is_absolute() or ".." in path.parts or str(path) == ".":
        raise ValueError("unsafe relative path: " + value)
    return path

def source_path(value):
    relative = safe_relative(value)
    root, path = E.resolve(), E / relative
    for index in range(1, len(relative.parts) + 1):
        if (E / Path(*relative.parts[:index])).is_symlink():
            raise ValueError("source contains symlink component: " + value)
    if path.is_symlink() or not path.is_file() or root not in path.resolve().parents:
        raise ValueError("source must be a regular contained file: " + value)
    return path

def output_path(value):
    output = value if value.is_absolute() else Path.cwd() / value
    root = E.resolve()
    resolved = output.resolve()
    if output.exists() or root not in resolved.parents and resolved != root:
        raise ValueError("output must be a new directory contained in evidence root")
    try:
        relative = output.relative_to(E)
    except ValueError as exc:
        raise ValueError("output must be contained in evidence root") from exc
    for index in range(1, len(relative.parts)):
        if (E / Path(*relative.parts[:index])).is_symlink():
            raise ValueError("output contains symlink ancestor")
    return output

def collect_container_ids(value, target):
    if isinstance(value, dict):
        for key, item in value.items():
            if key == "container_id" and isinstance(item, str):
                if not item:
                    raise ValueError("empty container_id")
                target.add(item)
            collect_container_ids(item, target)
    elif isinstance(value, list):
        for item in value:
            collect_container_ids(item, target)

def structured_values(source):
    if source.suffix == ".json":
        return [json.loads(source.read_text())]
    if source.suffix == ".jsonl":
        return [json.loads(line) for line in source.read_text().splitlines() if line.strip()]
    return []

def public_relative(redactor, value):
    safe_relative(value)
    result = redactor.scrub(value)
    return safe_relative(result).as_posix()

def scrub_value(redactor, value):
    if isinstance(value, str):
        return scrub_gpu_uuid_fragments(redactor.scrub(value))
    if isinstance(value, list):
        return [scrub_value(redactor, item) for item in value]
    if isinstance(value, dict):
        return {scrub_value(redactor, key): scrub_value(redactor, item) for key, item in value.items()}
    return value

def scrub_gpu_uuid_fragments(text):
    # Retain a deterministic pseudonym for a GPU-prefixed hexadecimal UUID or
    # fragment; the historical redactor handles full UUIDs but native status
    # text can truncate the value.
    pattern = r"\b(?:GPU-[0-9a-f]{8,}(?:(?:\.\.\.|…)[0-9a-f]{4,})?(?![0-9a-f-])|REDACTED_GPU_UUID_[A-Z0-9_]+(?:\.\.\.|…)[0-9a-f]{4,})\b"
    return re.sub(pattern, lambda match: "synthetic-device-" + digest(match.group().encode())[:12], text, flags=re.I)


def sanitized(redactor, source):
    raw = source.read_bytes()
    try:
        text = raw.decode()
    except UnicodeDecodeError as exc:
        raise ValueError("publication input must be UTF-8 text: " + source.name) from exc
    public = scrub_gpu_uuid_fragments(redactor.scrub(text)).encode()
    if source.suffix == ".json":
        json.loads(public)
    if source.suffix == ".jsonl":
        for line in public.decode().splitlines():
            if line.strip(): json.loads(line)
    return raw, public

def add_provenance(records, source, raw, public, public_path, redactor, **extra):
    row = {"source_name": public_relative(redactor, source.relative_to(E).as_posix()), "source_sha256": digest(raw), "sanitized_payload_sha256": digest(public), "public_path": public_path, "redacted": raw != public}
    row.update(extra)
    records.append(row)

def ensure_no_conflicts(paths):
    normalized = set(paths)
    if len(normalized) != len(paths):
        raise ValueError("duplicate public output path")
    for path in normalized:
        for parent in Path(path).parents:
            parent = parent.as_posix()
            if parent == ".":
                break
            if parent in normalized:
                raise ValueError("colliding public output paths: " + parent + " and " + path)

def preflight(inventory, redactor):
    selected, planned = [], []
    for kind, entries in (("artifact", inventory.get("artifacts", [])), ("archive", inventory.get("archives", []))):
        for entry in entries:
            if not isinstance(entry.get("roles"), list) or not entry["roles"] or set(entry["roles"]) - set(ROLES):
                raise ValueError(kind + " needs known roles")
            path = public_relative(redactor, entry["path"])
            sources = [source_path(entry["source"])] if kind == "artifact" else [source_path(item) for item in entry.get("sources", [])]
            if not sources: raise ValueError("archive needs sources")
            members = []
            for source in sources:
                member = public_relative(redactor, source.relative_to(E).as_posix())
                if len(member.encode()) > 100: raise ValueError("USTAR member name exceeds 100 bytes: " + member)
                members.append(member); selected.append(source)
            ensure_no_conflicts(members)
            planned.append((kind, entry, path, sources, members))
    ensure_no_conflicts([item[2] for item in planned] + list(GENERATED))
    return planned, selected

def role_ledger(inventory, retained, redactor):
    overrides = inventory.get("role_overrides", {})
    if set(overrides) - set(ROLES): raise ValueError("unknown role overrides")
    result = []
    for role in ROLES:
        if retained[role]:
            result.append({"role": role, "status": "retained", "files": [item["path"] for item in retained[role]], "reason": "Selected sanitized campaign evidence."}); continue
        override = overrides.get(role)
        if not isinstance(override, dict) or override.get("status") not in ("missing", "not-applicable") or not override.get("reason"):
            raise ValueError("empty role requires explicit missing/not-applicable reason: " + role)
        result.append({"role": role, "status": override["status"], "files": [], "reason": scrub_value(redactor, override["reason"])})
    return result

def build(inventory_path, output):
    inventory = json.loads(inventory_path.read_text())
    if inventory.get("schema") != "flare-upstream-refresh-publication-inventory/v1": raise ValueError("unexpected inventory schema")
    output = output_path(output)
    redactor = load_redactor(); redactor.container_ids.clear()
    planned, selected = preflight(inventory, redactor)
    for source in selected:
        for value in structured_values(source): collect_container_ids(value, redactor.container_ids)
    planned, selected = preflight(inventory, redactor)
    retained, provenance = {role: [] for role in ROLES}, []
    output.mkdir(parents=True)
    for kind, entry, path, sources, members in planned:
        if kind == "artifact":
            raw, public = sanitized(redactor, sources[0]); encoded = gzip.compress(public, mtime=0) if entry.get("gzip", False) else public
            target = output / path; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(encoded)
            add_provenance(provenance, sources[0], raw, public, path, redactor, gzip=entry.get("gzip", False), public_sha256=digest(encoded))
        else:
            payload = io.BytesIO()
            with tarfile.open(fileobj=payload, mode="w", format=tarfile.USTAR_FORMAT) as bundle:
                for source, member in sorted(zip(sources, members), key=lambda item: item[1]):
                    raw, public = sanitized(redactor, source)
                    info = tarfile.TarInfo(member); info.size, info.mode, info.mtime = len(public), 0o644, 0
                    bundle.addfile(info, io.BytesIO(public)); add_provenance(provenance, source, raw, public, path, redactor, archive_member=member)
            encoded = gzip.compress(payload.getvalue(), mtime=0)
            target = output / path; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(encoded)
        record = {"path": path, "sha256": digest(encoded), "bytes": len(encoded)}
        for role in entry["roles"]: retained[role].append(record)
    provenance_bytes = (json.dumps({"note": "Original hashes bind private source bytes; public hashes bind sanitized output. Archive members name deterministic tar.gz members. Reviewed inputs must exclude credentials.", "files": provenance}, indent=2) + "\n").encode()
    (output / "provenance.json").write_bytes(provenance_bytes)
    retained["evidence-index"].append({"path": "provenance.json", "sha256": digest(provenance_bytes), "bytes": len(provenance_bytes)})
    manifest = {"schema": "anvil-serving.benchmark-artifact-set-source/v1", "campaign": scrub_value(redactor, inventory["campaign"]), "native_evidence_schemas": scrub_value(redactor, inventory["native_evidence_schemas"]), "bundle_size_policy_verified": inventory.get("bundle_size_policy_verified", False), "size_policy": scrub_value(redactor, inventory.get("size_policy", "Not verified at preparation time.")), "artifact_roles": role_ledger(inventory, retained, redactor)}
    (output / "artifact-manifest-source.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest

def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--inventory", type=Path, required=True); parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(); print(json.dumps({"manifest": build(args.inventory, args.output)["schema"], "output": str(args.output)}))

if __name__ == "__main__": main()
