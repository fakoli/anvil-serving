# Independent canonical-response adapter review

```yaml
schema_version: operator-workflow/v1
request: Review only the canonical catalog-root and SSE-model semantic adaptation plus its offline check before any live retry.
gate_state: hold
targets:
  - harness/baseline-adapter-canonical.py
  - harness/check-baseline-adapter-canonical.py
  - review/stream-model-identity-diagnosis.md
tools_used:
  - read-only exact-hash verification
  - read-only semantic diff against the accepted baseline adapter
  - read-only focused-check inspection
artifacts:
  findings_summary:
    critical: 0
    high: 3
    medium: 0
    low: 0
  reviewed_adapter_sha256: 7adf318c288f3206e79b66d25c2ab549398400f4c30f12babff9e990fde8567d
  reviewed_check_sha256: c11d7ac2eb23c3cc1cdfc75d27d9ad58ea38bd74c82dd04092e52d44babca6cb
  diagnosis_sha256: 5095e7ae9a551018a5fb5fd8069574a750c92c0a2479139755c28400ef7d9524
advisory_priors:
  - The source diagnosis supports three distinct roles: served/catalog alias, catalog root, and canonical response model.
  - The implementing agent is GPT-6-based Codex with exact variant unavailable; this reviewer is GPT-5.6 Sol high and did not generate or grade model output.
recommendation: hold all canonical fixture and phase execution; repair the three bounded contract defects and rerun the focused canonical check
human_gate_required: true
promoted: false
```

## Findings

### HIGH — The catalog root is never validated

**Concrete response and wrong result (confirmed).** `validate_models` extracts only each card's `id` and accepts one exact alias; it never reads `root` (`harness/baseline-adapter-canonical.py:213-217`). `record_fixture` and `record_phase` then add `catalog_model=args.model` to the local receipt (`:355-358,397-400`), which is authored metadata rather than observed server root evidence. A catalog response with the right alias and any missing or wrong root passes both before/after identity gates, contrary to the independently pinned canonical contract.

Require exactly one catalog row with `id == served alias` and `root == CANONICAL_MODEL_ID`. Preserve the raw catalog receipt and do not replace root evidence with a harness-authored field.

### HIGH — Valid canonical responses are made work-invalid

**Concrete response and wrong result (confirmed).** `response_complete(row, model)` now expects `requested_model` and `catalog_model` to equal the served alias while `observed_model` equals the canonical ID (`:299-311`). But `work_valid` calls it with `response.get('observed_model')`, which is the canonical ID (`:314-321`). The alias therefore cannot equal the supplied model, so every otherwise valid canonical response is work-invalid. The fixture computes `closed` using both the correct alias call and this always-false work check (`:371-379`); no canonical fixture can close.

Pass the frozen requested alias into `response_complete` from the caller, or have `work_valid` use the response's already-bound `requested_model` after validating it. Do not accept canonical ID as a request/catalog alias.

### HIGH — The canonical check executes the old adapter and misses empty model drift

**Concrete state and wrong result (confirmed).** `check-baseline-adapter-canonical.py` imports `baseline-adapter.py` and launches that same old path (`:15,123`). Its synthetic catalog provides only `id` and its SSE echoes the alias (`:74-81,115-117`), so it exercises none of the new canonical behavior. Its digest is identical to the previously accepted old-adapter check.

Separately, the new parser validates a model only when `event.get('model')` is truthy (`baseline-adapter-canonical.py:261-269`). After one valid canonical event, a later event containing `"model": ""` or `null` is ignored and can still close. This violates the required rule that every model-bearing event equal the pinned canonical ID.

The focused check must import/launch the canonical adapter, return exact alias plus root from `/v1/models`, return canonical SSE model, prove a valid canonical fixture/work result, and reject wrong alias/root, alias-valued SSE, later changed SSE model, and present-but-empty/null model fields.

## Breakage-probe and coverage disposition

The probes were defined before reading the canonical check:

| Axis | Concrete probe | Result |
|---|---|---|
| Fail closed | Correct alias with missing/wrong catalog root | **Confirmed defect:** accepted. |
| Malformed/boundary | First canonical SSE event followed by a model-bearing empty/null event | **Confirmed defect:** the later field is ignored. |
| Resource/deadline | Existing bounded stream and hard-deadline paths | **Refuted:** unchanged from the accepted adapter. |
| State drift | Request alias remains fixed while canonical response identity differs; valid canonical response enters work gate | Wrong nonempty identity is rejected, but **valid canonical work is incorrectly rejected** by the alias/canonical argument mix-up. |

The supplied check covers only the old adapter, so it provides no test evidence for this delta. Existing accepted tests remain useful for unchanged URL, custody, secret, output-ID, metrics, and deadline behavior.

## Verdict

**HOLD** the canonical fixture and all subsequent phases. The source diagnosis is sound, but the implementation neither proves catalog root nor permits valid canonical work, and its check does not execute the changed file. This is a bounded adapter repair, not evidence of a Flare source/model failure. No promotion, upstream change, or identity allowlist is authorized.
