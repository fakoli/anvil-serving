# Final independent current-baseline summary-reader rereview

```yaml
schema_version: operator-workflow/v1
request: Rereview only the previously held current-baseline summary-reader findings after repair.
gate_state: hold
targets:
  - harness/summarize-current-baseline.py@719b63d11c0744711fc93cd9351dd3896bce98e0d65d6e6d6356ba93137bf69c
  - harness/check-current-baseline-summary.py@e3ff59e4e13c8a852b1d08732a3fe5821ddfb6a4b952ab0ac0a0c36bce85a68c
  - formal/current-baseline-canonical/01-fixed1/{owner-proof.json,warmup,prime,measured}
tools_used:
  - read-only source and closed-artifact inspection
  - sha256sum
  - focused offline contract check
artifacts:
  findings_summary:
    high: 2
    resolved_from_prior_review:
      - empty or failed closeout makes complete false
      - exact ordered case populations and exact response basenames
      - fixture metadata and smoke presence/result
      - bounded no-follow regular-file reads
      - duplicate and nonfinite metric rejection
      - finite response timings
      - absent speculative work remains explicitly unknown
advisory_priors:
  implementing_model: GPT-6-based Codex; exact variant unavailable
  reviewing_model: GPT-5.6 Sol, independent from the implementer
  evaluated_model: none; offline evidence-reader review
recommendation: hold
human_gate_required: false
promoted: false
```

## Findings

### High — The six owner proofs are valid-looking, but are not bound to the frozen image or closeout identity sets

`valid_proof()` checks only `running`, the served alias, and nonempty `container_id`/`revision` (`harness/summarize-current-baseline.py:228-230`). It does not require the pinned canonical revision, the window image, recipe/registry identity, or membership in the closeout's exact container/generation sets. `build()` reports `window.image` but never compares it with `verified.image_digest`, and does not require six distinct incarnation identities (`:242-276`).

**State-drift probe — confirmed:** copy one otherwise valid owner proof into all six incarnation directories, or change its image/revision while leaving them nonempty. All six `owner_proof_valid` values remain true. A same-alias replacement can therefore be summarized as the frozen six-incarnation baseline.

**Minimum correction:** bind every proof's exact container ID, generation/started-at identity, image digest, canonical revision, and recipe/registry identity to the frozen window/closeout records; require the expected six distinct incarnation identities. Add one negative check for a repeated proof and one for an image or revision mismatch.

### High — Overall completeness still accepts failed fixture responses and missing native counter deltas

Fixture metadata is now checked, but top-level `complete` requires only `fixture.valid`; it does not require `fixture.response.valid` (`harness/summarize-current-baseline.py:255-276`). A failed HTTP response can be rehashed into a syntactically closed fixture and still satisfy the overall fixture gate.

Separately, `prom_values()` ingests all numeric Prometheus series (`:57-72`) and `counter_delta()` rejects the entire snapshot if any value decreases (`:75-80`). The real closed `01-fixed1` metrics contain gauges such as free pages, free snapshots, cached pages, memory bytes, and throughput rates that legitimately decrease. Read-only recomputation found null deltas for **3/3 warmup, 37/52 prime, and 36/52 measured requests: 76/107 total**. `phase.complete` does not require a usable delta or record a reset/key mismatch as an issue (`:142-172`), so the phase and final baseline can still be complete while most native deltas are absent.

**Malformed/failure probes — confirmed:** (1) retain `closed: true` and update `response_sha256` around a failed fixture response; metadata validity passes and response validity is omitted from the final gate. (2) supply equal key sets with one decreasing gauge; `native_counter_delta` becomes null but phase completeness is unchanged. The revised check validates an ordinary phase-response failure, duplicate case ID, fixture `closed: false`, and empty closeout, but does not exercise either remaining path (`check-current-baseline-summary.py:40-73`).

**Minimum correction:** require every fixture response's independent `response.valid` result. Parse Prometheus type declarations or restrict delta arithmetic to the required monotonic counter/histogram families, retain gauges as before/after observations, and make a missing/reset/key-drift delta explicitly visible and completeness-failing for each expected request.

## Accepted repairs and probe disposition

The focused offline check passed. Exact phase response filenames refute the prior traversal/metacharacter attack; bounded `O_NOFOLLOW` reads address ordinary symlink and oversize inputs; `splitlines()` continues to handle CRLF. Duplicate metrics and nonfinite timings now fail closed. The reader still correctly reports speculative/accepted/emitted work as unknown rather than inferring equality from absent SSE fields.

**Recommendation: HOLD.** The remaining changes are limited to exact incarnation binding and making fixture-response/native-metric validity part of the existing completeness gate. No lifecycle, performance, promotion, or upstream conclusion is authorized by this review.
