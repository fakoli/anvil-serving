# Independent current-baseline lifecycle-action review

```yaml
schema_version: operator-workflow/v1
request: Review the bounded current-upstream baseline lifecycle action before the parent freezes or executes it.
gate_state: hold
targets:
  - runtime/current-baseline-tool-action.json
  - runtime/current-baseline-plan.md
tools_used:
  - read-only source, plan, registry, and reused-helper inspection
  - offline hash and embedded-Python integrity checks
  - offline JSON-escaping breakage probe
artifacts:
  findings_summary:
    critical: 0
    high: 1
    medium: 0
    low: 0
  reviewed_action_sha256: a9d2fb5a99d8119fe4fb91abc6d83f4d8dab7db5938f7941167ecd8827d3feee
  reviewed_executable_sha256: 49dbf054bdffe0403ffb6a0953b95b57d9fc4455ed4d759a173a552cf5e857c4
  reviewed_plan_sha256: 61b477de31b4b4c54e6306a7ca84e9864b996494ebd38444d5e56c79aa7e1ca5
advisory_priors:
  - The final baseline adapter has an independent GO and is outside this lifecycle-action finding.
  - The implementing agent is GPT-6-based Codex with exact variant unavailable; this reviewer is GPT-5.6 Sol high and did not generate or evaluate model output.
recommendation: hold execution until child output is checked before its first persistent write and secret checks cover encoded representations
human_gate_required: true
promoted: false
```

## Finding

### HIGH — The orchestration can persist a credential before its exclusion check

**Concrete state and wrong result (confirmed).** `run_child` opens `execution.log` and gives that file directly to the authenticated child as stdout/stderr. It reads and checks the file only after the child exits; when a credential is found, it overwrites the file with a withholding marker (`runtime/current-baseline-tool-action.json:26`, embedded Python lines 293–325). A child error that echoes either resolved credential therefore writes the credential to persistent storage first. Rewriting the pathname is not prevention or reliable erasure of the earlier bytes.

The generic evidence guard has a second exact bypass. `put` serializes an object before searching for each unescaped secret (embedded Python lines 27–34). The offline probe `secret='abc"def'` showed that `secret in json.dumps({'value': secret})` is false while the escaped representation is present. The protected recipe-key reader permits visible ASCII including quote and backslash, so this input is valid under the source contract (`anvil_serving/recipe_secrets.py:46-49`). No real secret was inspected.

This contradicts the action's stated secret-exclusion boundary even though the accepted adapter has its own recursive guard. The lifecycle owner also launches the preflight child, so adapter-only protection is insufficient.

**Minimum repair.** Keep authenticated child stdout/stderr out of persistent evidence until a bounded in-memory or equivalently pre-write scanner accepts it, and scan both structured values before serialization and relevant encoded text forms. Preserve the current fail-closed behavior: detection should retain only a non-secret receipt and enter the existing cleanup/restoration finalizer. A new action hash and executable hash require a narrow rereview before boundary freeze.

## Breakage probes

The probes were defined before considering any action-specific validation claims:

| Axis | Concrete probe | Result |
|---|---|---|
| Unreadable state/tools | Missing or changed boundary manifest, unreadable managed inventory, preexisting candidate | **Refuted:** execution fails before quiesce or candidate load; exact incumbent and candidate absence are checked. |
| Malformed/boundary input | Visible-ASCII credential containing `"`; child emits the literal credential; fixture input other than exact `continue\n` | **Confirmed defect** for both credential paths; **refuted** for the fixture gate. |
| Resource exhaustion/bounds | Child exceeds its phase deadline; candidate sequence reaches the 45-minute cutoff; recovery passes the 60-minute target | **Refuted for the intended operation:** only the owned child is TERM/KILLed, new requests stop at cutoff, and managed recovery calls use the separate bounded recovery deadline. The child log has no byte cap, but the child commands are frozen and this is residual risk rather than a second blocker. |
| State drift | Container restart/replacement, source/registry/helper mutation, stale monitoring generation, stopped-incumbent cgroup absence | **Refuted:** identity includes container ID/StartedAt/restart count, frozen files are rehashed, generations must be fresh, and stopped versus running incumbent containment is explicitly distinguished. |

The action has only offline AST/compile validation; there is no focused orchestration test that exercises credential-bearing child output or encoded secrets. The accepted adapter tests do not cover this parent-owned persistence path.

## Accepted lifecycle properties and residual limits

The reviewed bytes otherwise implement the requested bounded shape. They bind the exact worktree, image, registry, source head, helper/corpus hashes, and final adapter review; reject a preexisting candidate; validate exact incumbent identity and running containment before quiesce; preserve the stopped incumbent; require retained-restore preview before candidate load; sample exact candidate identity/containment; require fresh monitoring generations; terminate only the owned request child; and always enter managed candidate cleanup plus exact incumbent restore, direct/routed 7-group and 20-tool checks, router readmission, and monitoring readiness before `restored=true` (`runtime/current-baseline-plan.md:5-15`; embedded Python lines 378–479).

The parent-requested earlier action digest `ce0e5980...` is stale. This review binds the author's final static digest `a9d2fb5a...` and executable digest `49dbf054...`. The boundary manifest is intentionally absent before this review; it must bind the repaired final bytes and this review. Any later “consistency” edit changes the reviewed object and requires rereview.

## Verdict

**HOLD** the lifecycle execution. The ownership, identity, deadlines, interruption handling, and restoration design are acceptable, but the secret-exclusion defect is an escalation blocker. This review authorizes no live request, lifecycle mutation, promotion, or upstream submission; `promoted=false` remains mandatory.
