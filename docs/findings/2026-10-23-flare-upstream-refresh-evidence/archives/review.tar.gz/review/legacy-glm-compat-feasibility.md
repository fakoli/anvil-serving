# Exact-byte legacy GLM frontend compatibility feasibility

2026-10-23. Read-only source review at `d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4`. Only this note was written. No source edits, compilation, model loading, CUDA work, package modification, or re-export.

**Conclusion: a minimal addition to the existing exact-byte legacy-template upgrader is feasible. Full package re-export is not inherently required to resolve this particular frontend rejection.** This does not make old package graphs gain the package-bound correctness or requested-logprob capabilities from PR #16/#35, nor establish overall current-runtime compatibility or numerical correctness.

## Direct comparison

Read the complete current source template and the preserved checkpoint template at `2026-10-21-flare-optimization/glm53-upstream-chat-template.jinja`. A bounded stdlib Python comparison produced:

| Bytes | Length | SHA-256 |
|---|---:|---|
| Current `ignition/recipes/glm53/assets/chat_template.jinja` | 11,022 | `1c80fbd2e9e8a2321e06af17f71ec312a012f8597a098726a28b070a061eebde` |
| Preserved retained template | 10,950 | `0c4099f3382d6c92700dfb99725025360966fd73032f0ecf32377c0d9e6309c5` |
| Current template after removing its six literal `{%- mark -%}` annotations | 10,950 | `0c4099f3382d6c92700dfb99725025360966fd73032f0ecf32377c0d9e6309c5` |

The final two byte strings compare **exactly equal**, with an empty unified diff. No normalized whitespace, line-ending conversion, fuzzy comparison, or semantic approximation was used. The retained hash and length equal the parent's newly reported CPU image inspection of the signed package's embedded chat-template asset. This task independently verified the preserved template bytes; the package extraction/hash assertion comes from the parent's inspection, not a second package read by this task.

## Why the existing mechanism is sufficient

- `helios/src/frontend/mod.rs:432–451` reads the supplied template asset and passes Jinja templates to `frontend/templates.rs::compile`.
- `templates.rs:3–17` already embeds annotated Qwen, Step, and Kimi templates, compares their annotation-stripped **exact source bytes** to the provided legacy source, and compiles the known annotated template only on equality. Otherwise it compiles the source normally and requires annotations. GLM is simply missing from this compatibility list.
- The smallest production delta is a `GLM` include constant, adding it to the same compatibility list, and correcting the error's supported-family list. Extend the existing test list too. Do not add a model-ID branch, substring matching, mark insertion into arbitrary templates, a package-format exception, or a signing bypass.
- `jinja/compiler.rs:935–947` compiles a mark to a position instruction; `jinja/vm.rs:474–483` appends a position to the marks vector without emitting text. The tokenizer still consumes rendered text through the existing frontend path; marks supply boundary metadata.
- Zero-output alone is not sufficient to prove whitespace equivalence because the lexer honors tag trim delimiters (`compiler.rs:570–578,629–638`). Here the six inserted marks are adjacent to existing trimming tags: the first is next to the existing namespace-setting tag; the four tool-result marks follow right-trimmed output expressions; the last precedes the left-trimmed loop end. They do not introduce a new whitespace-removal boundary. The original source is otherwise byte-identical.

Thus the legacy route would compile precisely the same annotated template as a current export and preserve its prompt text/token IDs under identical inputs and tokenizer. This is a narrowly source-backed feasibility conclusion. It does **not** assert that every old renderer behavior equals the new compiled renderer, or that GPU execution/sampling agrees; those require their own tests.

## Existing tests and smallest added behavioral regression

1. `frontend/templates.rs::tests::compatibility_requires_exact_legacy_bytes` already checks accepted annotated and exact stripped forms, rejects a trailing-space variant, and rejects an arbitrary unannotated template. Add GLM to the same tested family list; retain those negative cases. This covers selection, not rendering or tokenization.
2. The non-ignored `frontend::jinja::tests::recipe_templates_match_on_messages_tools_images_and_options` already includes GLM. It compares the annotated native renderer against an independent MiniJinja oracle over the unmarked template, including Unicode/whitespace, system and assistant messages, tools, reordered tool results, reasoning settings, image markers, and generation-prompt options. Reuse this test rather than inventing a second general renderer framework. It has been inspected, **not rerun here**.
3. Add one CPU behavioral test in `helios/tests/message_boundaries.rs`, using its existing synthetic byte-level tokenizer helper, modeled on `segmented_xtml_preserves_boundaries_before_seeded_assistant_and_later_turns`. Construct two frontends from the current annotated GLM source and its exact stripped legacy form with `TemplateEncoding::Text`. For a short system/user/assistant/follow-up history containing Unicode, compare rendered text, token IDs, and boundary lists; assert boundaries are nonempty and unchanged-prefix token cuts survive replacing the final user suffix. Include one reordered tool-result history because four marks live in that branch. This verifies the actual `Frontend::load` → legacy selection → render/token/boundary path without a model or GPU. Do not require every physical tool message to be a prefix boundary: the GLM template reorders/coalesces tool results, so use explicit expected rendered order and valid cuts rather than blindly applying `check_messages` to every list prefix.
4. For exact retained-tokenizer assurance, reuse the existing ignored CPU integration test `helios/tests/glm_frontend.rs::checkpoint_template_tokenization_requests_and_message_boundaries_match_transformers`. It currently loads only the annotated source asset after asserting that stripping marks equals the snapshot template. The smallest enhancement is to run its same existing reference cases with both the annotated asset and the snapshot's original `chat_template.jinja` asset. Its assertions already cover rendered text, exact token IDs, message boundaries, output state, and request encoding. Reference generation in `tests/frontend/generate_glm_fixtures.py` independently uses Transformers and verifies marker removal preserves rendered text. This requires the existing snapshot/reference inputs; it is CPU frontend work, not package re-preparation or model inference.

Suggested focused checks after an authorized implementation/build: the existing `compatibility_requires_exact_legacy_bytes` and `recipe_templates_match_on_messages_tools_images_and_options` library tests under `--features server`, the new single `message_boundaries` integration test, and, if the retained tokenizer/reference are available, the existing ignored `glm_frontend` test with its documented two fixture environment inputs. No checks were run in this feasibility task beyond bounded byte/hash/diff comparison.

## Scope boundary

A clean CPU regression for this exact legacy upgrader would remove the specific template-annotation startup blocker while keeping the signed package and captured graphs unchanged. The old signed template bytes still pass their ordinary asset hash/authentication path; the loader applies the same trusted exact-match compatibility transform it already supports for other families. Do not modify the embedded package, change signer/namespace acceptance, or allow an unrecognized template.

The earlier statement that the retained package is rejected by **unmodified** current main remains correct. The broader implication that a **full re-export is the only remedy for this frontend gap** is too strong in light of the exact-byte comparison. A small separately reviewed compatibility fix is a legitimate alternative, and should remain separate from the proposed row-share allocation patch. Any baseline using it must be labeled current upstream plus that compatibility patch; it is not byte-pristine upstream. Independent package-bound numerical/state changes and serving validation remain open.
