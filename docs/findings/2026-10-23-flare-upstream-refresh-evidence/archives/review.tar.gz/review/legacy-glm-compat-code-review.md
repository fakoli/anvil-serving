# Independent legacy GLM frontend compatibility review

```yaml
schema_version: operator-workflow/v1
request: Review the exact-byte legacy GLM chat-template compatibility patch without running serving or GPU work.
gate_state: source_accepted_pending_reported_cpu_tests_and_release_build
targets:
  - NVIDIA/flare-local-inference@d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4
  - helios/src/frontend/templates.rs
  - helios/tests/message_boundaries.rs
  - retained package d5aec1543dc32413175462d17d374e54d27def24129f878045358c4db128c357
tools_used:
  - read-only Git diff and source inspection
  - read-only design and renderer-contract review
  - bounded independent byte/hash comparison
  - read-only test inspection after breakage probes were defined
artifacts:
  findings_summary:
    - No material correctness, security, or architecture blocker was found in the two-file patch.
    - Exact matching keeps altered, CRLF-converted, partial, and unrelated unannotated templates fail-closed.
    - The legacy and annotated routes compile the same trusted GLM constant; marks emit boundary metadata without output bytes.
    - CPU tests and the release build were not complete at review time; no GPU, signature, package-wide, or serving compatibility claim is accepted.
advisory_priors:
  - PR 16 and PR 35 remain package-bound and still require re-export; this patch addresses only frontend compatibility.
recommendation: accept_source_delta_after_focused_cpu_tests_and_release_build_pass
human_gate_required: true
promoted: false
```

Reviewer: GPT-5.6 Sol high. I did not author the change and no model output is being qualified. The implementation was produced by the separate `OPERATOR_PATH_41255bccbe8c` agent; trusted context identifies it only as Codex based on GPT-6, not an exact model identifier. That is distinct from this GPT-5.6 Sol reviewer, while the missing exact identifier remains an evidence limitation. The evaluated GLM did not author or grade the patch.

## Findings

No blocking finding.

The production change is the smallest compatible extension of the existing mechanism. `helios/src/frontend/templates.rs:3-17` embeds the current annotated GLM template and adds it to the same exact-byte compatibility loop already used for Qwen, Step, and Kimi. It does not branch on model identity, mutate package bytes, bypass asset authentication, normalize input, or accept a fuzzy match. A source differing by one case change, CRLF conversion, or trailing byte remains unrecognized and then fails the general nonempty-annotation requirement.

The retained input is bound narrowly. Removing the six literal `{%- mark -%}` tags from the 11,022-byte current GLM asset independently produced the preserved 10,950-byte retained template exactly and reproduced SHA-256 `0c4099f3382d6c92700dfb99725025360966fd73032f0ecf32377c0d9e6309c5`. `retained-frontend-inspection.json` reports the same asset length and hash for the retained package, while correctly recording `signatures_verified=false` and `frontend_compiled=false`. This supports compatibility selection, not package authentication.

Rendered output is preserved by construction and by the focused behavioral test. The upgrader compiles the trusted annotated `GLM` constant, so annotated and exact stripped legacy inputs enter the same compiled template. The compiler emits `Mark` for these tags (`helios/src/frontend/jinja/compiler.rs:935-947`), and the VM records the current output length without emitting bytes (`helios/src/frontend/jinja/vm.rs:474-483`). The inserted trim-tag boundaries do not change the surrounding source; the exact stripped-byte identity rules out hidden whitespace changes. The integration test additionally compares rendered text, token IDs, and boundary lists for ordinary and reordered-tool histories, checks literal rendered text and tool order, and exercises unchanged-prefix cuts.

The change follows the package-compatibility requirement in `AGENTS.md` and `docs/design-review.md`: it keeps a previously exported package usable through shared frontend compatibility code, without a new package field, fallback renderer, runtime compilation, or model-specific scheduling/cache behavior. Startup allocation, CUDA graphs, PR 16 state layout, and PR 35 requested-token buffers remain untouched.

## Breakage probes defined before test inspection

| Axis | Concrete input or state and wrong result | Classification after source/test review |
|---|---|---|
| Fail closed | An unreadable asset, changed GLM prose, or unrelated unannotated template is silently upgraded | Refuted: asset reads already fail; exact equality is required; changed prose and arbitrary unannotated input are rejected |
| Malformed/boundary | CRLF conversion, a trailing byte, partial mark removal, or command/path-like template text receives compatibility treatment | Refuted for CRLF/trailing/changed content by exact-match tests and loop semantics; partial/command-like content also cannot equal the canonical stripped bytes |
| Resource bound | Compatibility scans or compilation grow with request traffic or unbounded external input | Refuted: four embedded templates of fixed size are examined during frontend startup; no request-time path or new allocation lifetime is introduced |
| State drift | Tests validate reconstructed bytes while the retained package carries a different template, or a different source/image is credited | Refuted for the recorded asset identity by matching 10,950-byte hash; still conditional on exact source/image/package binding in any later run |
| Renderer semantics | Added trim tags change text/token IDs or marks fall at invalid token cuts | Refuted for the tested ordinary/tool paths and structurally refuted for text output by zero-output marks plus exact stripped identity; retained-tokenizer serving remains unrun |

## Validation and residual limits

The inspected tests cover exact selection, altered input, CRLF, trailing space, arbitrary unannotated input, rendered text, token IDs, sorted unique boundaries, Unicode, reasoning, reordered tool results, and changed-suffix prefix reuse. The pre-existing independent MiniJinja differential test includes GLM over a broader message/options matrix. At review time I did not receive completed focused-test or release-build output; those are required before using the image.

This review does not establish verified package signatures, GPU startup, HTTP readiness, current-runtime compatibility beyond this frontend seam, numerical parity, PR 16 correctness, PR 35 requested-ID support, or a passing historical 128-token gate. A later managed run must retain the exact patch/source/image/package identities and label the runtime as current upstream plus this local compatibility patch. No promotion or upstream submission is authorized by this review.

## Recommendation

**Conditional GO** for the two-file source change after the planned focused CPU tests and release build pass. Hold any GPU or serving use on failure or identity drift. Re-export remains mandatory for PR 16 and PR 35 behavior, but it is not the only remedy for this isolated frontend rejection.
