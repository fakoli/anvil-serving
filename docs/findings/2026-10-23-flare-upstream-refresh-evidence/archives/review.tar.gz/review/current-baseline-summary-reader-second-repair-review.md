# Independent second-repair summary-reader review

```yaml
schema_version: operator-workflow/v1
request: Review only exact incarnation binding and monotonic native metrics plus fixture-response validity after the final summary-reader repair.
gate_state: hold
targets:
  - harness/summarize-current-baseline.py@5bc8038e248aabf962b15f2e80c2bcfab0b131b803f2d10d5c1da9cd5afbab99
  - harness/check-current-baseline-summary.py@858e9d35fac1e3d476a46f8ee73a1f23019235165754064c5e8b50476aaaca08
  - formal/current-baseline-canonical/01-fixed1 closed metrics and identity receipts
tools_used:
  - read-only source and closed-artifact inspection
  - focused offline contract check
  - closed 01-fixed1 metric-delta recomputation
artifacts:
  findings_summary:
    high: 1
    resolved:
      - exact window image and canonical revision binding
      - exact recipe and registry binding
      - distinct proof hashes and container IDs
      - per-incarnation complete generation and closeout set binding
      - fixture response validity participates in overall completeness
      - legitimate gauges are retained separately and no longer invalidate deltas
advisory_priors:
  implementing_model: GPT-6-based Codex; exact variant unavailable
  reviewing_model: GPT-5.6 Sol, independent from the implementer
  evaluated_model: none; offline evidence-reader review
recommendation: hold
human_gate_required: false
promoted: false
```

## Finding

### High — Labeled monotonic counters are silently excluded from every native delta

`counter_delta()` classifies a series by applying `endswith('_total'|'_sum'|'_count'|'_bucket')` to the full Prometheus key (`harness/summarize-current-baseline.py:75-80`). Labeled keys end in `}`, for example `flare_host_cache_lookup_outcomes_total{reason="admitted"}` and `..._bucket{le="64"}`, so the classifier drops them. The same full-key suffix test incorrectly places those counters in `native_gauges_before/after` (`:163-167`). Consequently `reason_labelled_cache_delta` is always empty even though the current baseline specifically retains current-native reason counters.

**Closed-data probe — confirmed:** recomputing the closed `01-fixed1` data now gives non-null deltas for all 3 warmup, 52 prime, and 52 measured requests, but each delta has exactly 19 keys and **zero reason-labelled keys**. The useful monotonic phase populations such as lookup outcome, `no_match`, `admitted`, and store-reason totals are therefore absent from the summary.

The focused check passes, but its synthetic labeled lookup/store metrics are not asserted in the resulting delta (`check-current-baseline-summary.py:10-17`, `:53-59`). Its later negative assertions are also made after rebuilding `closeout.json` without the required container/generation sets (`:60-74`), so those top-level `complete is False` checks are already satisfied by closure identity and do not isolate the intended corruption.

**Minimum correction:** classify on the metric name before the first `{`, use that same classification for gauge separation, and assert that the expected reason-labelled and histogram series survive. In the check, assert the initial report is complete, restore the full valid closeout after the closeout-negative case, and then independently demonstrate the identity/fixture/response/metric negatives.

## Accepted scope

The previous incarnation-binding blocker is resolved in source: proofs now bind the frozen image, canonical revision, recipe/registry hashes and started identity; completion receipts bind container/generation; closeout sets and distinct proof/container identities participate in the final gate (`summarize-current-baseline.py:231-283`). Fixture response validity also participates in completeness. Absent SSE speculative work remains unknown.

**Recommendation: HOLD** only for the labeled-counter classification and its focused regression coverage. No active-root summary, lifecycle action, performance conclusion, promotion, or upstream submission was reviewed or authorized.
