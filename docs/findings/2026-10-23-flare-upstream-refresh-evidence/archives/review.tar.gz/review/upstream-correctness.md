# Independent upstream correctness review

```yaml
schema_version: operator-workflow/v1
request: Review PRs 16 and 35 and adjacent reports for applicability to the retained GLM TP2 package and its latency/output inconsistency.
gate_state: diagnostic_path_identified_fix_unproven
targets:
  - NVIDIA/flare-local-inference@d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4
  - GLM-5.3-Flash-NVFP4-MXFP8-CSF-QAD@dec48abd33efa73c3bb7c95b74eee10cad34f9be
  - retained package d5aec1543dc32413175462d17d374e54d27def24129f878045358c4db128c357
tools_used:
  - read-only Git and GitHub PR, issue, review, comment, and check inspection
  - read-only source and retained-evidence inspection
artifacts:
  findings_summary:
    - PR 16 demonstrates a GLM shifted-draft-page restore defect that is present in current main and the retained package; it can reduce MTP acceptance after restore, but does not establish sampled-output corruption.
    - PR 35 is merged into current main and supplies a stronger fixed-token logprob discriminator, but the retained package predates its manifest buffers and must be re-exported to use it.
    - The older GLM selection-width and page-table-extent fixes are already ancestors of source 47581cca and are not new candidate fixes.
    - A same-package MTP-disabled arm is the smallest active-speculation isolation; a re-export is the minimum test of PR 16 or PR 35.
advisory_priors:
  - The retained numerical gate remains failed and the protected regressions remain diagnostic.
recommendation: run_mtp0_isolation_then_reexport_pr16_correct_package_for_restore_and_logprob_discrimination
human_gate_required: true
promoted: false
```

Reviewer: GPT-5.6 Sol high. The PR 16 implementation and disclosure identify GPT-6/Codex authorship; this review is independent. The evaluated GLM model did not grade itself.

## Findings

### F1 — High: PR #16 is directly applicable, but its demonstrated effect is speculative efficiency after restore

[PR #16](https://github.com/NVIDIA/flare-local-inference/pull/16) identifies a concrete GLM defect: the draft page table is shifted by one physical page and the draft cursor lags the target, while the generic maintenance graph saves only one trailing page. At endpoints such as 257, the preceding complete draft page and current partial page can both remain private. The PR changes maintenance capture to save both parts, expands the two GLM draft continuation regions, and increases TP2 continuation-row cost from 81,464,576 to 81,608,192 bytes.

The current `d5fd9824` source still contains the one-page implementation: validation subtracts one from the endpoint and validates only that page, copying through `ENDPOINT_SHIFT` ([current validation](https://github.com/NVIDIA/flare-local-inference/blob/d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4/ignition/components/state_transfer.py#L106-L134), [current copy](https://github.com/NVIDIA/flare-local-inference/blob/d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4/ignition/components/state_transfer.py#L152-L177)). The GLM layout still allocates one `draft.latent_page` and one `draft.index_page` region ([current layout](https://github.com/NVIDIA/flare-local-inference/blob/d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4/ignition/recipes/glm53/pool.py#L37-L40)). The existing test also clones the target page table instead of representing Helios's shifted draft table. PR #16 replaces those seams with two saved parts and boundary cases 1, 2, 4, 255, 256, 257, 258, 511, 512, and 513 ([PR head](https://github.com/NVIDIA/flare-local-inference/blob/c9f1c4f96988ef844c83f72dbc0216900756c19e/ignition/components/state_transfer.py)).

The retained package's observed 81,464,576-byte TP2 state row matches the unfixed cost exactly. A newer runtime cannot repair already captured maintenance graphs or enlarge their stored continuation layout. PR #16 explicitly preserves package load compatibility while requiring re-export for the fix. The earlier Snapshot→Restore→Snapshot oracle does not refute this defect: an incomplete serialization can compare byte-exact against itself while omitting the same private draft page on both snapshots.

**Demonstrated:** the PR author reports a GPU reproducer at endpoint 257 losing both draft planes without a transfer error, then restoring them byte-exact after the patch. The diff contains the relevant boundary and cross-part-alias tests.

**Author-reported, not independently established here:** 32 GLM CUDA tests passed with two TP tests skipped; full GLM serving and TP2/TP4 serving were not run. The PR is open and mergeable, with no GitHub review, comment, status-check, or check-run record.

**Allowed hypothesis:** after a prefix restore, missing draft history can lower draft acceptance and increase latency. **Disallowed conclusion:** it explains the retained sampled-output differences. The PR says target outputs stay exact, and correct speculative decoding must preserve the target distribution. No retained evidence ties the missing pages to the observed case-51 top-20 change or historical 128-token mismatch.

### F2 — Medium: PR #35 is useful observability, not a model fix, and requires re-export

[PR #35](https://github.com/NVIDIA/flare-local-inference/pull/35) is merged as squash commit [`48bae6bb`](https://github.com/NVIDIA/flare-local-inference/commit/48bae6bb6d5888da6da40706f2dcfcfaf1ab6614) and is an ancestor of `d5fd9824`. It adds up to 128 caller-selected token IDs and reports each selected token's raw target logit minus the existing log-sum-exp, before sampling transforms. This is materially stronger than comparing the natural top 20 because cold and restored arms can observe one identical, prospectively fixed token set at every position. It still is not a full-vocabulary logit vector, RNG-state view, independent reference, or correction.

The package contract adds named `logprob_token_ids`, counts, and widened completion buffers ([manifest contract](https://github.com/NVIDIA/flare-local-inference/blob/48bae6bb6d5888da6da40706f2dcfcfaf1ab6614/helios/manifest.md#L99-L131)). Admission deliberately rejects requested IDs for older packages with a re-export message ([admission](https://github.com/NVIDIA/flare-local-inference/blob/d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4/helios/src/model/admission.rs#L123-L140)). Therefore the retained `47581cca` package cannot gain this discriminator merely by running under `d5fd9824`.

The merged PR has no visible GitHub review/comment/check records. Its author reports broad CPU coverage and an earlier-revision CUDA/TP2/TP4 run within `9e-7` of an FP64 reference, while explicitly leaving this revision's GPU runs and DeepSeek validation undone. Those are author claims, not current-revision check evidence.

### F3 — Medium: adjacent reports do not supply a new GLM TP2/C4 fix

- [`docs/glm-batched-speculation-defect.md`](https://github.com/NVIDIA/flare-local-inference/blob/d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4/docs/glm-batched-speculation-defect.md) records the selection-width export bug fixed by `22887c1` and the later page-table-extent change `eb770324`. Both commits are already ancestors of source `47581cca`; they are not new remedies for this package. The document's residual timing-sensitive invalid-distribution observation is TP4/C16, while this workload is TP2/C4. Its `neighbour` classification is explicitly a model-level miss, not corruption.
- [Issue #14](https://github.com/NVIDIA/flare-local-inference/issues/14) demonstrates NaNs from unused paged-attention V-cache tails and points to FlashInfer PR #43. Its demonstrated routes are Qwen and related paged-attention call sites; the issue does not establish applicability to GLM's sparse-MLA/indexed-attention path. It requires re-export even for affected recipes.
- [Issue #61](https://github.com/NVIDIA/flare-local-inference/issues/61) is Gemma-specific, [issue #24](https://github.com/NVIDIA/flare-local-inference/issues/24) is DeepSeek-specific, and repository search found no separate GLM seed/sampling report that explains the retained behavior.

### F4 — Decision: MTP-disabled first for isolation; re-export first for testing either upstream change

`--mtp-draft-tokens 0` is the smallest meaningful **active-speculation isolation** on the existing package. Current selection sets `enabled = false` when drafts are zero, prunes speculative/proposal/verification variants, retains ordinary decode graphs, and requires decode coverage for each batch ([selection](https://github.com/NVIDIA/flare-local-inference/blob/d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4/helios/src/runtime_package/selection.rs#L127-L172), [catalog filtering](https://github.com/NVIDIA/flare-local-inference/blob/d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4/helios/src/runtime_package/selection.rs#L336-L425)). It can answer: does the latency/output symptom recur when learned speculation is not executed? It cannot test PR #16, repair the captured state layout, or enable PR #35.

The retained first MTP0 preflight is not a clean control: three C4 requests hit a rank-zero invalid-distribution status followed by TP completion divergence and runtime exit. A later successful probe would not erase that failure. A new MTP0 control must be prospective, repeated, same-package, and retain all failures; separate cold/no-restore and restored-prefix cells are needed so a pass is not mistaken for proof that restore state is correct.

A **re-export is the minimum meaningful next step for upstream-fix validation and numerical localization**. The narrow package should use `d5fd9824` plus PR #16's source change, the same `dec48abd` checkpoint, TP2/C4 and existing sampling policy. Because PR #35 is already in `d5fd9824`, that one re-export can also expose a fixed prospectively chosen requested-ID set. Compare same-history cold and restored arms, first with MTP0 and then MTP enabled, while retaining draft offered/accepted counts, graph shapes, prompt reuse, requested-token logprobs, output IDs, and every failure. This is a new package identity and cannot retroactively qualify the retained package or rewrite the historical exact-output gate.

## Breakage probes applied before accepting the PR tests

| Axis | Concrete failure mode | Review result |
|---|---|---|
| Fail closed | Missing/out-of-range shifted draft pages silently copy an invalid page | PR #16 adds error paths and alias validation across both saved parts; retained package remains unfixed |
| Boundary input | Endpoints on either side of 256/512 boundaries save the wrong full or partial page | PR #16 adds the material boundary set, but TP2 serving is untested |
| Resource bound | Doubling saved draft-page regions is omitted from row planning or exceeds package storage | PR #16 updates TP1/2/4 row costs; a re-export and startup allocation check remain required |
| State drift | New runtime is credited with fixing an old package, or requested logprob IDs silently degrade to top-20 | Both changes are package-bound; PR #35 rejects old packages and PR #16 explicitly requires re-export |
| Numerical attribution | Lower acceptance, different output IDs, and requested logprob changes are collapsed into one cause | Refuted: each is a separate gate; no reviewed change proves a production numerical fix |

## Recommendation

Do not open a duplicate fix for PR #16 or claim PR #35 repairs the inconsistency. Reference PR #16 as a correctness dependency in the row-allocation issue/PR, offer current-hardware TP2 validation if requested, and keep the older 95–96% cache result diagnostic. Run the bounded same-package MTP0 isolation first if the immediate question is whether active speculation is involved. Re-export only when ready to test the PR #16 mechanism and PR #35 discriminator together; that re-export is mandatory before either upstream change can bear on the retained artifact.

No source, package, model, lifecycle, GPU, public issue, or PR mutation occurred in this review. `promoted=false` remains mandatory.

## Addendum — retained-package frontend compatibility at `d5fd9824`

### F5 — High: hold the retained package on current main; its GLM template is not accepted

Current main compiles every Jinja frontend through `templates::compile`. An unannotated template is accepted only when its bytes exactly equal the mark-stripped deployed Qwen3.8, Step, or Kimi K3 template; every other template with no annotation span fails with `chat template requires message-boundary mark annotations` (`helios/src/frontend/templates.rs:3-17`). `Frontend::load_with_settings` reaches that check while loading the package's `chat_template` asset (`helios/src/frontend/mod.rs:432-451`), and `Bootstrap::load` treats the resulting error as a startup failure (`helios/src/server/config.rs:220-271`).

The retained artifact predates that contract. Source `47581cca` prepared GLM by putting the checkpoint's `chat_template.jinja` directly in the package asset map (`ignition/recipes/glm53/bootstrap.py` at that revision, lines 553-568). The retained checkpoint template is independently preserved at `2026-10-21-flare-optimization/glm53-upstream-chat-template.jinja`, SHA-256 `0c4099f3382d6c92700dfb99725025360966fd73032f0ecf32377c0d9e6309c5`; it contains no `mark` annotation and byte-compares unequal to each of the three allowed legacy templates. The retained package/index identity remains `d5aec1543dc32413175462d17d374e54d27def24129f878045358c4db128c357` / `0fdced23da87f99c3669dc05ab87ecd7f17a6572773c6b61021d077f68a09ed9` in `cap16-p2048-package-identity.json` and the later source bindings.

Therefore the old package cannot complete startup under **unmodified** `d5fd9824`; an actual serve may allocate/load GPUs before reaching this frontend failure, so a GPU trial is not an appropriate compatibility probe. This is a package/frontend incompatibility, not evidence about PR #16, sampling, or model quality. Current source's new GLM recipe asset is annotated and has a different SHA-256 (`1c80fbd2e9e8a2321e06af17f71ec312a012f8597a098726a28b070a061eebde`). Re-export remains the remedy for package-bound PR #16/#35 behavior, but the exact-byte [legacy GLM compatibility review](legacy-glm-compat-code-review.md) confirms that a narrowly reviewed loader compatibility addition can resolve this frontend rejection alone without changing the signed package.

### Smallest CPU-only evidence check

The supported CPU-only command is `flare inspect --unverified --frontend --json PACKAGE`. Source documents that this reads bounded primary-file metadata, does not initialize CUDA, and does not open companion weight files (`helios/src/runtime_package/metadata.rs:1-19`). Run the command from the already managed-built image `sha256:a5e9fbc4bde4b35bc14c9304235e234939ef519bb795251e2a0d59a868a40ede` in a bounded `host docker-image build` validation target whose context contains only a root-copied, hash-checked 2,645,178-byte primary package file. Assert the package index SHA-256 above and that `assets[name=chat_template].sha256` equals the retained unannotated-template hash. Use one CPU, a small fixed memory limit, no network, and a short build timeout; no recipe load, GPU flag, secret, package companion, or raw `docker run` is needed.

That command verifies identity and the decisive asset hash; it does **not** compile the frontend. The CLI has no metadata-only `validate frontend` mode, and `flare run --stage-only` configures package devices before returning (`flare/src/main.rs:130-210`), so it is not a CPU-safe substitute. The subsequently reviewed compatibility patch exercises `Frontend::load_with_settings` through focused CPU tests and remains subject to its own build/test gate. Until such validated code is present in the runtime image, the source-plus-exact-asset proof above is sufficient to hold the unmodified old-package runtime attempt.

Breakage probes: unreadable or hash-drifting package input must fail closed; missing/partial/CRLF-altered marks must not be treated as compatible; inspection must retain primary-file and output bounds/timeouts; and image/source/package digests must be checked together so an old host binary cannot stand in for `d5fd9824`. Current exact-byte matching refutes silent legacy GLM auto-upgrade, but no existing test covers this retained package directly.
