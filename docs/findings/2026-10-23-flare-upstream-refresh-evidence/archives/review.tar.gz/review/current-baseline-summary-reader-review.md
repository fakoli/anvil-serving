# Independent current-baseline summary-reader review

```yaml
schema_version: operator-workflow/v1
request: Independently review the bounded current-upstream baseline summary reader against the closed canonical fixture schema, exact denominators, failure visibility, and unknown work dimensions.
gate_state: hold
targets:
  - harness/summarize-current-baseline.py@45e38d7e7247f0d31ec7228d76dc44be18f79b4931a7e970a4d67ba3580741c6
  - harness/check-current-baseline-summary.py@fac8ee50576ffb9327fd6012b825d2c7cdedbfe17c2cd0f3be8cf7f55d1376d1
  - formal/current-baseline-canonical/00-fixtures/fixture-{fixed1,small12,pageheavy,warmup}/http/{fixture,response}.json
tools_used:
  - read-only source and fixture inspection
  - sha256sum
  - python3 harness/check-current-baseline-summary.py
artifacts:
  findings_summary:
    high: 2
    medium: 1
    accepted_behavior:
      - The requested 391 adapter-request denominator is encoded correctly.
      - Speculative, accepted, and emitted work remain explicitly unknown when absent from the response schema.
      - Ordinary invalid attempts remain visible and disqualify the affected phase.
advisory_priors:
  implementing_model: GPT-6-based Codex; exact variant unavailable
  reviewing_model: GPT-5.6 Sol, independent from the implementer
  evaluated_model: none; this is an offline evidence-reader review
recommendation: hold
human_gate_required: false
promoted: false
```

## Findings

### High — A dictionary named `closeout.json` is treated as proof that the baseline is closed

At `harness/summarize-current-baseline.py:203-213`, `build()` accepts any JSON object as `closeout.json`. It does not require `restored: true`, an empty recovery-error population, a successful wall-deadline/restoration state, or hashes binding the six incarnations. It also discards closeout read errors into a fresh list and publishes no top-level `complete`/`closed` result (`:205`, `:233-239`).

**Breakage probe — confirmed:** replace a valid closeout with `{}` while leaving the synthetic phase tree intact. The source path passes the only closeout check and can emit an issue-free report whose docstring says it summarizes only a closed baseline. The test creates `{"restored": true}` but never corrupts or removes its required fields (`check-current-baseline-summary.py:40-62`).

**Required correction:** validate the actual closeout contract and exact closure/restoration success fields, bind the six expected incarnation proofs, and publish an explicit overall completeness state that is false on any closure, identity, phase, fixture, smoke, or read issue.

### High — Exact populations and the required smoke are not authenticated

Phase completion checks only aggregate counts, list length, and per-row validity (`summarize-current-baseline.py:117-147`). It does not require the exact case-ID set/order, unique IDs, or exact response filenames. A duplicate case can replace a missing case while `phase.complete` remains true; this is especially silent in `small12` and `pageheavy`, which have no pair gate. The fixed1 map also collapses duplicate prime IDs (`:157-165`).

The four fixture files are only hashed: their `flare-upstream-current-response-fixture/v2` schema, `closed: true`, lane, corpus, alias, catalog root, canonical response model, incarnation proof, and response hash are not checked (`:219-225`). The smoke result is never read or counted even though the returned denominator says `smoke_expected: 1` (`:235`). Owner proofs are likewise hashed but not validated (`:217-218`). Thus the reader cannot yet substantiate **391 adapter requests + 1 smoke across 6 bound incarnations**.

**Breakage probes — confirmed:** (1) duplicate a phase case ID and omit another while retaining the declared count; the phase remains complete. (2) set a fixture to `closed: false` or change its canonical response identity while retaining a valid response; `adapter_observed` still counts it. (3) omit/fail the smoke; no reported field changes. The focused check covers none of these cases (`check-current-baseline-summary.py:40-62`).

**Required correction:** enforce exact ordered case populations per phase, validate each fixture and owner proof against the frozen window identity, and retain an observed/pass/failure record for the one smoke request. Failed and missing rows must stay in their declared denominators.

### Medium — Evidence reads are not contained or bounded, and one malformed timing can abort the whole summary

An attempt-controlled `response_path` is joined directly beneath `http` without requiring a basename or contained resolved path (`summarize-current-baseline.py:127-135`). JSON, response, and Prometheus files are read without regular-file, symlink, size, or stat-stability checks (`:20-29`, `:45-56`). Duplicate Prometheus series silently overwrite earlier values (`:52-55`). If a one-token pair has a nonnumeric TTFT, subtraction at `:195` raises instead of retaining the malformed attempt as a visible failure.

**Breakage probes:** `../` or an absolute `response_path` reads outside the evidence root (**confirmed**); a large/special file can consume unbounded resources (**plausible** in this trusted private staging context); duplicate Prometheus keys overwrite (**confirmed**); CRLF metric input is handled by `splitlines()` (**refuted**). The focused check does not cover these boundaries.

**Required correction:** accept only the exact expected local response filename, use bounded no-follow regular-file reads with stability checks, reject duplicate metrics, and validate finite numeric timing fields before arithmetic.

## Accepted interpretation and residual limits

The inspected closed fixtures use schema `flare-upstream-current-response-fixture/v2`, are marked closed, and bind the requested alias to canonical catalog/response model `dec48abd33efa73c3bb7c95b74eee10cad34f9be`. Their responses expose only `enqueue_ns`, `ingress_ns`, `reused_prompt_tokens`, and token timestamps for the relevant timing path. The reader correctly records speculative/accepted/emitted work as `unknown:not_observed_in_current_response_schema` (`summarize-current-baseline.py:94-114`, `:193-200`); absent fields must not become equality claims.

The focused offline check passed and proves that one ordinary invalid response remains visible and reduces the bounded fixed1 output gate. It does not establish closure, exact population, smoke, identity, containment, or malformed-input safety.

**Recommendation: HOLD** the final summary reader and any closed/complete baseline claim until the two high findings are fixed and covered by negative checks. This does not invalidate the already closed fixture artifacts or authorize any lifecycle change, performance claim, promotion, or upstream submission.
