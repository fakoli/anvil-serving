# Synthesis and private issue-draft accuracy review

**Scope:** read-only comparison of `upstream-review.md` and
`publication/issue-draft.md` with the upstream cache-overlap, correctness, and
latency reviews. This review identifies only material factual, attribution, or
scope errors. It does not approve an upstream submission, source change, GPU
run, or promotion.

## Result

**No material error requiring a rewrite was found.** The two documents preserve
the required decision boundaries:

- The `d5fd9824` clean-image build is stated only as build success. Both
  documents keep the compatible-package/current-main GPU baseline pending; they
  do not compare that build to the historical GPU baseline.
- PR #16 is described as a re-export-required draft-state candidate. Neither
  document attributes the retained output mismatch or protected latency to it.
- PR #38 and proposed PR #57 metrics are used to avoid duplicate aggregate
  telemetry. Both documents retain the missing request-to-slot/generation and
  host-index-span seam rather than claiming existing histograms provide causal
  attribution.
- The 95.04–96.06% fixed-one-token result remains explicitly historical and
  diagnostic-only. The sampled-output failure, protected regressions, and
  incomplete numerical/state-oracle scope remain visible.
- PR #43 and #69 stay separate concurrency/prefill candidates; their triggers
  are not claimed for the zero-prefill protected measurement.
- The issue draft remains private, awaiting a compatible current-main baseline,
  and requires failed-gate retention and design review before any submission.

The source/pin statements that matter to this conclusion match the reviewed
records: #38 is in the selected baseline; #16 and #57 remain open and require
new package/source selection respectively; #35 is package-bound despite being
merged; and the retained package cannot be treated as current-main compatible.

`promoted=false` remains required.
