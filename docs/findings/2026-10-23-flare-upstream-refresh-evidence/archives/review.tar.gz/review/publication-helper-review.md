# Publication helper review

Verdict: **GO for closed-input offline preparation at the exact hashes below.** No new blocker was found in the bounded helper changes. This is a static helper/plan review, not final inventory, payload privacy, size-policy, hosting, or publication approval. The active run and growing evidence root were not inspected.

## Exact reviewed inputs

- `publication/publish-evidence.py`: SHA256 `aaf892db52dee2f220c0ad9fcc3fc73b2605dbd4abb0a93cb1c1b4e019704e46`.
- `publication/inventory-plan.md`: SHA256 `a8f35fd3e1bb5345329bd2f84a9714184499ca5dea0c7fdfafc7cb41d958297f`.
- Reviewed predecessor helper: SHA256 `110a20ad1b59c0bbb25dc5c17d3e97d85c4c3358614790601a29aabd30f8b3d4`.
- Imported historical redactor dependency: SHA256 `42954231b75dda79e806c7abb4be8cf19af1cc5e3c69102c5aa9f9b7e4c307c1`. The helper loads this by path, so closure must recheck this digest as the plan requires.

## Assessment

The diff against the reviewed predecessor is limited to the campaign docstring/schema, a `/root/…` reference pseudonymizer, and relative string entries in the role ledger. The new path transformation reads only selected source text and hashes the matched reference itself; it does not dereference or inspect any referenced verification/key file. It removes the basename rather than retaining a potentially identifying key/profile name. Wrapping the historical scrubber preserves its cleared container-ID set and all existing transformations. The final GPU fragment replacement retains the reviewed `synthetic-device-` prefix, avoiding the intermediate predecessor pseudonym that matched the semantic GPU rule.

Contained regular-file sources, symlink-component rejection, contained new output directories, safe relative public paths, generated-name and prefix collision rejection, and 100-byte USTAR member limits remain intact. Archive members are sorted and emitted as regular text files with fixed metadata; gzip timestamps are zero. No live discovery, glob selection, lifecycle call, network operation, or credential-file read occurs in the helper. Given frozen input bytes, ordered inventory, imported redactor, and the same Python environment, the construction is deterministic.

Original source SHA256, sanitized payload SHA256, compressed/direct public SHA256, and archive member names remain joined in provenance. Emitting role files as relative strings matches the finalizer contract; the finalizer must still compute/bind output hashes and the actual closed inventory. The helper does not itself prove the complete inventory, source uniqueness across separate entries, closed-producer status, or size-policy truth. The plan explicitly assigns those to closure review and retains every failed/partial predecessor attempt and the driver boundary.

## Required closure checks and inherited limits

- Freeze/recheck helper, redactor dependency, inventory, and selected source bytes only after producers stop. Repeated reads during ID discovery and packaging are safe only under that freeze; the helper has no independent input snapshot or expected-source-hash enforcement.
- Perform the planned independent expanded-payload scan, including filenames/member names, JSON keys and decoded serialized JSON, arbitrary UTF-8 suffixes, public documents, and binary exclusion. Case-sensitive historical identity replacement, exact structured `container_id` discovery, finite path/IPv4 patterns, and permissive JSON parsing are inherited limitations. The new `/root/…` regex handles its declared ASCII reference syntax; it is not an all-path or credential detector. Uncovered private spellings are blockers at final validation.
- Use reviewed byte-identical aliases for invalid historical JSON stdout or long member names, retaining originals and explicit provenance. Do not silently reinterpret/drop them or select protected files merely because a receipt references them.
- Require complete exact inventory and roles, finalizer twice with identical bytes, actual size-policy disposition, public-link checks, zero unmatched privacy findings, and contextual review of any signature exceptions. No exception from an earlier campaign automatically transfers to a new path/content.

Verification performed: exact input/dependency hashes, full static read of the two requested files, comparison to the pinned predecessor helper, and AST syntax parsing. No helper execution, archive generation, corpus scan, growing-root analysis, synthetic build/test, model traffic, lifecycle operation, or upstream submission occurred. No source changes are requested by this preparation review.
