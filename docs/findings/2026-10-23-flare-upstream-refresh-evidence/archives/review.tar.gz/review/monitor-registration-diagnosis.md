# Current-baseline monitoring-registration diagnosis

Status: source-verified from retained receipts and the private monitoring
configuration; no live endpoint, lifecycle, credential, or Docker inspection
was performed.

## Earliest actionable cause

The candidate reached its declared HTTP start point. The retained managed-load
receipt then failed only at monitoring registration, and the retained managed
logs end with the server-start success line rather than an engine startup
failure.

The candidate recipe uses the engine identifier `flare-d5fd9824-compat`.
The current `recipe-monitoring.json` admits the candidate port and has a key
mapping, but its `engine_contracts` map contains only `flare-47581cca` for the
Flare metrics contract. It has no entry for `flare-d5fd9824-compat`.

`recipe_monitoring.publish` reads that map before it probes health, reads the
credential, or fetches `/v1/models`:

```python
contract = config["engine_contracts"].get(engine)
if contract is None:
    raise ValueError("recipe engine has no declared monitoring contract")
```

Therefore the first failing condition is the missing declared metrics contract
for the new engine identifier. It is not evidence of failed health, failed
model identity, bad credentials, or a metrics scrape failure.

## Evidence pointers

- `formal/current-baseline-driver6157110/operations/00-fixtures-load.stdout`:
  the managed command reports a running recipe and the generic registration
  failure.
- `formal/current-baseline-driver6157110/operations/failure-candidate-logs.stdout`:
  retained startup steps conclude with server start.
- `registry-upstream-compat25.toml:23-35`: candidate engine identifier and
  declared port.
- `hosts/dark-linux/operator-home/recipe-monitoring.json:2-13`: the monitored
  port is present, while the engine-contract keys do not include the candidate
  identifier. This pointer is private configuration; it is not suitable for
  public evidence.
- `anvil_serving/recipe_monitoring.py:115-124`: the map lookup occurs before
  discovery, credential read, and HTTP probes.
- `anvil_serving/models.py:3544-3549`: managed load currently suppresses the
  caught exception detail and reports only the generic withheld-metrics message.

## Smallest durable correction

Add the candidate's exact engine identifier to the private
`engine_contracts` map with the existing `flare` metrics contract, then render
or validate the private configuration before the next managed load. This is an
operator configuration correction; it does not alter the recipe image,
allocation policy, direct alias, router, or monitoring credential.

Separately, the product should retain a bounded redacted registration failure
code at the existing `models recipes load`/restore catch site. That is a
reporting improvement, not required to identify this retained failure. It
should classify the failed stage (`engine_contract_missing`, identity,
credential, health, or model identity) without emitting the exception body,
configuration paths, credentials, or request details.

## Limits

This diagnosis is based on the retained load/log receipts and source/config
shape. It does not prove the corrected mapping has been applied or that a
future load, health probe, model identity probe, monitoring generation, or
benchmark phase will pass. Metrics remain withheld for the failed candidate
incarnation, and no performance evidence was collected.
