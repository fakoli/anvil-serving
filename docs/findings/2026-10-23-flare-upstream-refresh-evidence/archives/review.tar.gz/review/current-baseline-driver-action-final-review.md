# Independent final driver-action validator review

```yaml
schema_version: operator-workflow/v1
request: Narrowly review the corrected preflight receipt validator after the real restored direct preflight exposed split tool-result observation names.
gate_state: go_with_existing_gates
targets:
  - runtime/current-baseline-tool-action-driver6157110.json
  - formal/post-driver-restoration/direct.json
tools_used:
  - read-only exact-hash verification
  - read-only validator inspection
  - read-only real receipt and recorded negative-case review
artifacts:
  findings_summary:
    critical: 0
    high: 0
    medium: 0
    low: 0
  reviewed_action_sha256: f95870d032eeca87f278cdb0619984174053ccf0181c8e59ddfb2d3d3e2a7574
  reviewed_executable_sha256: f531ab2b07c5f67d6485a13ec1ee985efa0357b051b2d82532a333a9627984f9
  unchanged_plan_sha256: 17368c4525555123f18c7c5ab583800b44e89a5b9e5ca3a4bf81b29f13ff8ba6
  real_direct_receipt_sha256: bcf37119c492b4e5b4ce3078fdc96ed784bccbe39128706d52968112489c5551
  superseded_action_sha256: ce76ee5cb2ae193263d301ff4dc5320bf6aa917214cea91f9ff6a41301097669
advisory_priors:
  - The direct restored preflight passed all seven requested groups, 27 observations, and 20 tool cases; the earlier failure was solely an incorrect evidence-validator assumption.
  - The implementing agent is GPT-6-based Codex with exact variant unavailable; this reviewer is GPT-5.6 Sol high and did not generate or grade model output.
recommendation: go for routed restoration validation and the bounded action after a boundary manifest binds the corrected exact bytes
human_gate_required: true
promoted: false
```

## Finding disposition

No material defect remains in the corrected validator.

The actual `preflight/v2` receipt declares the exact requested check list and contains seven successful result rows plus 27 successful observations: 20 `tools`, one each for `smoke`, `json`, `needle`, `streaming-tools`, and `responses`, and one each for `tool-result-initial` and `tool-result-continuation`. The new `Counter` contract matches that emitted schema exactly.

The validator now requires:

- exact `preflight/v2` schema, model, and ordered check list;
- overall `passed=true`;
- exactly one successful result row per requested check;
- `evidence_policy.errors == []`;
- every observation to be a dictionary with `passed=true`; and
- the exact observation-name multiplicities, including 20 tools and both tool-result phases.

This accepts the real closed direct receipt while rejecting missing/duplicated split tool-result observations, missing tool observations, false rows/results/overall state, wrong model/schema, duplicate checks, evidence errors, and result-count drift. The recorded 14-case offline set includes the real receipt and a smoke-only receipt; its bound real-receipt digest matches the file on disk.

## Breakage-probe disposition

| Axis | Concrete probe | Result |
|---|---|---|
| Fail closed | Missing result or observation, false overall/result/observation, evidence-policy error | **Refuted:** each case is rejected. |
| Malformed/boundary | Duplicate check, duplicate initial tool-result, missing continuation, wrong schema/model | **Refuted:** exact list and `Counter` equality reject them. |
| Resource/denominator | Fewer than 20 tool observations or an extra observation family | **Refuted:** exact multiplicities are required. |
| State drift | Direct receipt shape differs from the routed or smoke request contract | **Refuted within the supported contracts:** the requested `checks` list drives the exact expected counter, including the smoke-only case. |

## Scope and verdict

Only `check_preflight` changed from the previously accepted driver action. Driver guards, secret custody, lifecycle, cleanup, cutoff, and restoration logic remain covered by the prior reviews. The earlier frozen action and failed receipt remain historical evidence and must not be rewritten as a model or source failure.

**GO** to use this corrected validator for the remaining routed restoration check and for the already authorized bounded diagnostic action, after the boundary manifest is regenerated against the corrected action/executable hashes. No promotion or causal `.09` versus `.10` timing claim is authorized; `promoted=false` remains required.
