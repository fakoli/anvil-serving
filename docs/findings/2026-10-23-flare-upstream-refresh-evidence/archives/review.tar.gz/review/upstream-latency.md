# Upstream latency and inconsistency review

**Scope:** read-only review of upstream pull requests, issues, current source,
and the closed protected-regression evidence. This is planning evidence only; it
does not change a source tree, patch, harness, service, or qualification gate.

## Evidence bound

| Item | Status and pin | What was read |
| --- | --- | --- |
| Current refresh source | `d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4` (`origin/main`) | current source and recent history |
| [PR #43](https://github.com/NVIDIA/flare-local-inference/pull/43) | open; base `1fd1f917fcf2b0a48068e1f9e58be8db2165b383`, head `6dd92500bae6ca6d92109cb5003db886ccc4b300` | full diff, description, comments, reviews, checks |
| [PR #57](https://github.com/NVIDIA/flare-local-inference/pull/57) | open; base `a66c4e41852c33281fb457649d105baf5e91c924`, head `21a2030b2dddb4602f46cc7b72fbc299c3784999` | full diff, description, comments, reviews, checks |
| [PR #69](https://github.com/NVIDIA/flare-local-inference/pull/69) | open; base `624a7fb34ba2d4a18c7692ded11ef68ad141b74b`, head `95938ae11fc89d27279dabdc0f513c823c5fa598` | full diff and description |
| [PR #38](https://github.com/NVIDIA/flare-local-inference/pull/38) | merged; head `111aec173781d9c71307754f6c3c32a07d9db5da` | description and current metric implementation |
| Protected bracket | closed `protected-abba-2`; analysis hash `66d290b358bee59fb037013f24aedc8b304bd90d1e2b25d44a9c2bf371ac85b8` | summary and accepted final trace review |

At review time, #43 and #57 have no submitted review comments, issue comments, or
reported checks. Their validation claims are author-provided, not an accepted
upstream result. #69 is likewise open and unreviewed in the read inventory.

## What the closed protected bracket establishes

The bracket has four fresh incarnations per protected lane and complete matched
populations: 24 measured requests per arm for `small12` and 12 per arm for
`pageheavy`, with exact output-token IDs and complete work for all 36 A/B
pairs. Every measured request had one host-cache lookup. Across every measured
incarnation, sampled deltas for prefill tokens, host fetches, fetch failures,
and host stores were zero; host memory records stayed at 31 and the recorded
flight/wait gauges were zero. MTP work was also absent.

The original timing result remains broad and diagnostic-only: arm-B medians are
higher by 2.973 ms for `small12` client E2E and 2.763 ms for `pageheavy`
client-generated TTFT. The two matched-pair distributions are wide and may not
be reduced to a named component. The separately captured scheduler traces had
complete temporal coverage but no HTTP-request-to-slot/generation mapping, and
the A/B graph-shape mixtures differ. The independent review therefore holds
causal, numerical, protected-performance, tuning, and promotion claims.

This rules out treating host transfer, prefill, MTP, or a named scheduler graph
as the demonstrated cause. It does **not** rule out work between Prometheus
samples, request preparation, the CPU index lookup itself, scheduler overhead,
or another unmeasured seam.

## Submitted work and relation to the regression

### PR #43 / issue #42 — feedback work hidden by an in-flight decode pipeline

[#42](https://github.com/NVIDIA/flare-local-inference/issues/42) describes a
real scheduler defect: when ordinary decode has submissions in flight,
feedback-required final-prefill candidates are discarded before utility
selection. [#43](https://github.com/NVIDIA/flare-local-inference/pull/43)
keeps those candidates visible, then rejects the final materialized
feedback-required winner until the submission window drains. Its tests cover
mixed/split candidate construction, feedback exclusivity, stale-key recovery,
and a simulated first-output bound.

That is not a duplicate of the protected investigation. The closed measured
requests were warm GPU hits with zero measured prefill and no concurrent
pipeline evidence; the diagnostic trace has no queued sample. #43 can explain a
long final-prefill wait under concurrent ordinary decode, but cannot explain a
per-request 1.6/4.4-ms-scale warm-hit difference or the observed protected
medians without new evidence of that feedback condition. Its native performance
matrix also predates prefix-retention work and is explicitly not a
current-main claim.

**Reuse:** retain #43 as a separate concurrency/fairness candidate. Do not fold
it into the row-share A/B refresh, and do not add its policy change to either
arm of that refresh.

### PR #57 — request lifecycle metrics

[#57](https://github.com/NVIDIA/flare-local-inference/pull/57) adds aggregate
Prometheus histograms for ingress-to-first-token, E2E, queue, prefill, decode,
inference, inter-token, time-per-output-token, request sizes, preemptions, and
iteration tokens. It also records normal finish reasons and speculative offered,
draft-token, and accepted-token counters. The stated timing boundaries are
useful: queue is engine arrival to first admission; TTFT is HTTP metrics ingress
to first committed token; prefill begins at admission; decode/inference end at
the last committed token; E2E ends at finish.

If #57 is merged or otherwise selected as a pinned source input, it can replace
new aggregate lifecycle-histogram work in the refresh plan. Preserve the raw
scrape and compare histogram counts with completed normal requests as a
sanity check. It cannot replace client per-request timing, output/work matching,
or the planned causal seam: the series have no request ID, scheduler slot,
execution generation, host-index decision/span, cache-record identity, or
per-request graph attribution. Histograms also omit zero-token requests and
normal success excludes cancellation/admission rejection. They are therefore
not a request-level pairing or failure oracle.

#57 is not in current `d5fd9824`: static inspection finds the merged #38 host
metrics but no #57 `metrics_ingress_ns`, `render_requests`, or
`flare_e2e_request_latency_seconds` implementation. Its API edits also add an
ingress argument to `generate`, `generate_observed`, `generate_many`, and
`generate_many_observed`; any future cherry-pick/rebase must compile the full
runtime call surface before a measurement is considered comparable.

### PR #69 — short final message segment prefill merge

[#69](https://github.com/NVIDIA/flare-local-inference/pull/69) changes
`prefill_work()` to absorb a short final message segment that fits in the
current chunk. It is a plausible fix for a different TTFT problem: an otherwise
extra short-batch prefill graph at a final message boundary. It retains the
prompt-end checkpoint while dropping the intermediate boundary checkpoint.

It cannot explain the retained measured protected windows as recorded because
those windows have zero `flare_prefill_tokens_total` delta. It could affect a
future prime/cold phase if a frozen body has the required short final segment,
and then becomes a configuration confounder rather than an explanation of the
old warm-hit result. Keep it out of the minimal row-share patch and, if adopted
upstream, bind its source pin and treat checkpoint/publication behavior as
changed.

### Current merged #38 — prefix-cache retention and host-index metrics

[#38](https://github.com/NVIDIA/flare-local-inference/pull/38) is already in
the upstream lineage and changes eviction, shallow-host-match fallback,
store-retry, compacted-row replacement, and host lookup accounting. Current
`d5fd9824` exposes `host_cache_lookup_outcomes_total`,
`host_cache_missing_tokens`, `host_cache_estimated_transfer_ns`,
`host_cache_estimated_prefill_ns`, and `host_cache_row_refills_total`.

Those existing series should replace any proposal to recreate aggregate
host-decision counters. They do not time the CPU lookup call, label a request,
or prove a sampled lookup was on the client-critical path. The refresh should
scrape them raw and retain their meanings by source pin, then add no conclusion
unless a request-correlated measurement exists.

### Other adjacent work

- [PR #27](https://github.com/NVIDIA/flare-local-inference/pull/27) was closed
  without merge. It bounds frontend message-boundary rendering for very large,
  many-message requests. No retained protected evidence shows that scale or
  attributes its warm-hit timing to message rendering. It is an input-shape
  lead, not a replacement for the current test.
- [PR #8](https://github.com/NVIDIA/flare-local-inference/pull/8) changes
  vision feature-window leases and is outside text-only protected lanes.
- [PR #18](https://github.com/NVIDIA/flare-local-inference/pull/18) concerns
  preparation-time CUDA-to-host export integrity, not serving-request latency.
  Its old `_Cuda.download` path is source-superseded at current head by native
  export staging that uses pinned `cuMemHostAlloc` 8-MiB slots; it is neither a
  row-share dependency nor a runtime latency candidate.
- [issue #45](https://github.com/NVIDIA/flare-local-inference/issues/45) and
  [issue #47](https://github.com/NVIDIA/flare-local-inference/issues/47)
  describe distinct capacity/retention limitations. Neither gives a
  request-level explanation for this bracket.
- [PR #64](https://github.com/NVIDIA/flare-local-inference/pull/64) is open and
  reports a `cargo test --lib` initializer failure on its older base. Static
  inspection and the current-file commit identify the cited
  `image_checkpoint_hints: vec![]` initializer at `helios/src/model/prompt.rs:704`,
  last changed by `e952c8a764adb067bc0f7a2b9bea1c86d494987f`. No build was run
  here, so this is not a current-head compilation verdict; the exact reported
  source omission is already fixed and #64 should not be cherry-picked as a
  prerequisite.

## Minimal non-duplicative next measurement

Keep the authorized current-main A/B refresh minimal and separate from all
three open PRs: unmodified main at 25% versus only the reviewed row-share patch
at 75%, with the conditional patched-default-25 isolation control. Retain three
fixed-one-token repeats and protected `small12`/`pageheavy` populations.

Use #38 raw host-decision metrics immediately. If #57 lands on the selected
source pin, use its aggregate lifecycle histograms instead of adding another
histogram family. The remaining, non-duplicated diagnostic seam is an opaque
HTTP request/case identifier propagated to scheduler slot/execution generation,
alongside admission and host-index start/end/outcome spans. It must be captured
separately from timing and paired with the raw-logit/numerical package binding;
without that seam, graph mixture or aggregate histogram differences cannot
identify the latency cause.

No upstream submission, merge, configuration change, service action, or
promotion is recommended. `promoted=false` remains required.
