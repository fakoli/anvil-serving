# Independent final baseline-adapter review

```yaml
schema_version: operator-workflow/v1
request: Verify closure of the five residual baseline-adapter findings after the second and final bounded repair.
gate_state: go_for_one_live_fixture
targets:
  - harness/baseline-adapter.py
  - harness/check-baseline-adapter.py
tools_used:
  - read-only source and test inspection
  - bounded synthetic localhost transport check
  - bounded offline function probes
artifacts:
  findings_summary:
    blockers: 0
    residual_limitations: 2
  reviewed_adapter_sha256: 5b7471d476bce20c75dae5c55d2ba5026704fe674832bfeff95010bfe55e0cf8
  reviewed_check_sha256: c11d7ac2eb23c3cc1cdfc75d27d9ad58ea38bd74c82dd04092e52d44babca6cb
advisory_priors:
  - This authorizes only the already planned current-upstream-plus-compat diagnostic fixture and, after it closes successfully, its exact frozen phases.
  - The adapter always records performance_eligible=false and does not establish promotion, parity, allocator causality, or numerical qualification.
recommendation: go for the single live fixture under the existing managed identity and deadline gates; phases remain conditional on a closed fixture
human_gate_required: true
promoted: false
```

Reviewer independence is unchanged: the implementation author is GPT-6-based Codex with exact variant unavailable; this reviewer is GPT-5.6 Sol high. No model request, credential access, GPU work, lifecycle action, or source mutation was performed.

## Findings

No remaining concrete blocker was found in the five scoped repair areas.

1. **Recursive and raw credential exclusion is closed.** `contains_secret` walks dictionary keys and values plus nested lists/tuples without JSON re-encoding (`baseline-adapter.py:91-106`). Every JSON artifact uses it, SSE events are checked before retention, and raw Prometheus writes now pass through the same literal-key check (`:130-145,257-259,336-338`). Independent probes confirmed that an escaped key such as `abc"def` is rejected both inside nested JSON and in raw bytes, leaving no created raw file.
2. **Token-ID and completion accounting is closed.** A valid response now requires HTTP 200, terminal receipt, exact observed model, allowed finish reasons, a list containing only true integers, a nonnegative integer `completion_tokens`, and exact equality between completion count and retained IDs (`:290-302`). Fixed1 retains its exact one-token/TTFT requirement; other lanes require nonempty, fully reconciled IDs (`:305-312`). Independent malformed-string, boolean-count, and count-mismatch probes reject.
3. **Metric HTTP validity is closed.** `metrics_valid` requires HTTP 200, no captured error, and all native family prefixes (`:174-180`). Fixture and phase receipts preserve status/error/presence/digest, and closure uses `metrics_valid` for both sides (`:336-365,391-403`). A synthetic HTTP 500 carrying all expected strings is rejected.
4. **Final phase receipts are closed for handled transport and identity failures.** The phase owns `attempts`, `phase_error`, and its post-phase identity receipt across a `try/finally`; it writes `attempts.json` and `summary.json` after either the normal path or an identity/transport failure (`:371-427`). The localhost transport check forces a failed post-phase identity and verifies both aggregate files plus the recorded error.
5. **The hard deadline is closed.** The CLI installs a main-thread `ITIMER_REAL` deadline around the entire fixture or phase and restores the previous handler/timer afterward (`:155-171,451-474`). Blocking HTTP/SSE work is therefore interrupted even if socket inactivity timeouts would otherwise be extended by trickled bytes. A direct bounded probe confirmed `DeadlineExpired` interrupts a blocking sleep; the transport test also retains an error receipt for a delayed partial stream.

The earlier corpus/order and custody fixes remain intact: exact frozen hashes/counts/repeats, fixed1 reverse measured order, original small12 IDs, warmup unwrapping, strict loopback URL parsing, pre-network exclusive output reservation, authenticated before/after model identity, partial/error SSE retention, and successful unknown-field/zero-token preservation.

## Breakage probes and test coverage

The prior four-axis probes were reused before inspecting the revised check:

| Axis | Probe | Final result |
|---|---|---|
| Fail closed | HTTP 500 metrics containing valid-looking series; post-phase identity failure | **Refuted:** 500 is invalid and the identity failure leaves final attempt/summary receipts. |
| Malformed/boundary | JSON-escaped key, key in raw metrics, string token ID, boolean/mismatched completion count | **Refuted:** all are rejected by source and bounded probes. |
| Resource exhaustion | Trickle past a socket timeout or phase deadline | **Refuted for the supported Linux CLI:** process SIGALRM interrupts blocking work at the absolute deadline. |
| State drift | Wrong endpoint/model or mismatched frozen lane/corpus | **Refuted:** exact authenticated identity and frozen fixture/lane bindings remain required before closure. |

`python3 harness/check-baseline-adapter.py` passed. It exercises only a synthetic `127.0.0.1` server and performs no model or lifecycle call. The same file also completed under `python3 -O`; acceptance relies on the ordinary run and the independently executed explicit probes, since its assertions are intentionally ordinary Python assertions.

## Residual limitations and verdict

- The synthetic transport check cannot establish behavior of the built Flare image, signed package, live API, or real native metrics. The first real fixture must close successfully with exact source/image/package/registry/incarnation evidence before any phase.
- Filesystem/device failure during final receipt writes is outside this HTTP adapter's evidence guarantee. The reviewed normal, protocol, identity, credential, and deadline failure paths are bounded and retain their intended artifacts.

**GO for the single managed live fixture under the already authorized diagnostic plan.** Proceed to a phase only if that fixture closes with its exact lane work, model identity, credential exclusion, and metric gates. This review does not authorize promotion, a row-share policy change, public submission, or any inference claim beyond the retained diagnostic evidence.
