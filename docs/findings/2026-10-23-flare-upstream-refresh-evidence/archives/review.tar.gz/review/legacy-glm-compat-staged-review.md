# Independent staged legacy-GLM compatibility review

```yaml
schema_version: operator-workflow/v1
request: Review the exact staged legacy-GLM frontend compatibility change and its validation before a local commit.
gate_state: source_go_local_commit_only
targets:
  - OPERATOR_PATH_14a2e272ec99/flare-cache-row-share-20261023@d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4
  - helios/src/frontend/templates.rs
  - helios/tests/message_boundaries.rs
  - helios/README.md
tools_used:
  - read-only staged Git diff/status/hash inspection
  - read-only source, guidance, test, build-log, and draft inspection
  - bounded offline template hash and marker-count comparison
artifacts:
  findings_summary:
    blocker: 0
    nonblocking_editorial: 1
  staged_diff_sha256: 90660b3b86a33383366c5d259b6eab05381541381bef127a5dea0fadf789359e
  staged_design_review_sha256: 6aebb2e5e2e5cc593cf98375ffc6baace18d325ba137bf5b484a23ad0088cbd3
  build_log_sha256: f5a927e24260fa052d294da2714116f5f59dd69c7d7afed87867525b227e2e9d
advisory_priors:
  - This is an exact-byte package-compatibility shim at the shared frontend seam, not a renderer fallback or model-specific scheduler policy.
  - GPU startup, signed-package loading, whole-model behavior, PR 16, PR 35, and the historical numerical gate remain unvalidated by this change.
recommendation: go for a local commit with the exact acknowledgment below; no push, submission, deployment, or serving claim
human_gate_required: true
promoted: false
```

Reviewer independence: the implementation author is a separate GPT-6-based Codex agent; its exact variant is unavailable. This reviewer is GPT-5.6 Sol high. The evaluated GLM did not author or grade this source evidence.

## Findings

No material correctness, security, architecture, or staged-validation blocker was found.

The production change adds the current annotated GLM asset to the existing exact-byte legacy upgrader (`helios/src/frontend/templates.rs:3-18`). It neither mutates package contents nor adds a model-ID policy branch. Only input exactly equal to the current asset with its known annotations removed is upgraded; changed prose, CRLF conversion, trailing bytes, partial removal, and unrelated unannotated templates remain rejected. The embedded asset has six plain marks and no segmented marks; removing them yields the retained 10,950-byte SHA-256 `0c4099f3382d6c92700dfb99725025360966fd73032f0ecf32377c0d9e6309c5` exactly. If the recipe asset drifts, the added digest assertion forces a deliberate test update.

The behavioral regression exercises the actual frontend load/render/tokenize path for ordinary and reordered-tool histories, including Unicode, exact rendered text, token IDs, sorted nonterminal boundaries, and unchanged-prefix cuts (`helios/tests/message_boundaries.rs:307-369`). The existing MiniJinja differential includes GLM across broader histories and options (`helios/src/frontend/jinja/tests.rs:231-338`). The README accurately limits the behavior to exact deployed templates and states that other unannotated templates fail (`helios/README.md:408-424`). No package format, graph, cache, sampling, or GPU behavior changes.

### Nonblocking editorial correction

The private PR draft says, “The release build passed with the same `runtime-package,server` test features as upstream CI.” The feature flags belong to the focused Helios test commands; the separate `flare` release build command has no such feature argument. Before using the draft publicly, say: **“The focused Helios tests used the upstream-CI `runtime-package,server` feature set, and the Flare release build passed separately.”** This does not block the staged source commit.

## Breakage probes and coverage

These probes were defined from the production seam before assessing the external regression test:

| Axis | Concrete wrong-result probe | Result |
|---|---|---|
| Fail closed | An altered or unrelated unannotated template is silently upgraded | **Refuted:** full-string equality precedes upgrade; changed prose, trailing-space, and arbitrary-template tests reject it. |
| Malformed/boundary | CRLF, partial marker removal, or annotation-like/path-like text is normalized into the allowlist | **Refuted:** no normalization or parsing-based match occurs; CRLF is explicitly rejected and every byte must match the canonical stripped asset. |
| Resource exhaustion | The extra compatibility work becomes request-time or grows with external inputs | **Refuted:** startup compares against four fixed embedded assets; no request-time path or new persistent allocation is introduced. |
| State drift | A changed recipe asset or different retained template is credited as compatible | **Refuted for the reviewed bytes:** the source test pins the stripped digest and the retained inspection reports the same length/digest. A later run must still bind source, image, package, and registry identities. |

The build receipt matches its retained log. Four focused CPU tests passed: two exact-template unit tests, the independent MiniJinja differential, and the GLM message-boundary integration test. The log also shows the release Flare build passed. The first failed build used an incomplete feature set, was retained, and required no source repair. `git diff --check --cached` passes; the working tree has no unstaged diff; the staged diff contains only the three disclosed files.

## Residual limits

This source-only acceptance does not prove GPU startup, HTTP serving, signature verification, whole-package compatibility, numerical parity, output consistency, PR 16 draft-state correctness, PR 35 requested-logprob support, or the historical 128-token gate. Any later managed run must label the build as current upstream plus the local GLM compatibility patch and independently bind its source/image/package identities. The separate baseline HTTP adapter remains on HOLD under its own review.

## Design acknowledgment

I read the exact staged `docs/design-review.md` (`6aebb2e5e2e5cc593cf98375ffc6baace18d325ba137bf5b484a23ad0088cbd3`) and reviewed staged diff `90660b3b86a33383366c5d259b6eab05381541381bef127a5dea0fadf789359e` against every applicable principle. I found no unapproved design violation and the limitations above accurately bound the evidence.

Use exactly one final commit trailer:

```text
Design-Signed-Off-By: OpenAI Codex GPT-5.6 Sol high; design-review=6aeb
```

**GO for the local commit only.** No push, upstream submission, deployment, serving mutation, or promotion is authorized by this review.
