# Upstream refresh harness plan

## Scope

This plan compares current unmodified `main` at `d5fd9824` with a minimal
row-share patch at 75%, holding the 32 GiB host pool and frozen request bodies
constant. A patched-default-25 control is required only if the candidate patch
cannot be isolated from its default behavior; it tests patch isolation, not
performance improvement.

The smallest bracket is A/B/B/A for each protected lane and three A/B pairs for
fixed-one-token replay. It has 864 timing HTTP requests before any managed
warmups: fixed1 624, small12 144, pageheavy 96. This uses 14 fresh managed timing incarnations; each arm uses a fresh managed
incarnation and retains prime and measured phases separately. The plan preserves
all failures and never filters timing to matched survivors.

## Upstream compatibility findings

Current main is 218 changed files beyond `47581cc…`. Relevant source evolution
includes `Index::lookup_below(history, resident, before, usable)` replacing the
older lookup APIs, updated eviction behavior, host row-refill/lookup-outcome and
cost metrics, and scheduler/logprob configuration changes. Therefore, every
metric scrape must retain raw Prometheus text and a metric-presence receipt; the
old counter names and meanings are not assumed stable. The HTTP replay protocol
is retained as a frozen input, but actual response shape must be validated by
its existing normalization before comparison.

## Evidence before execution

The lifecycle owner must write source HEAD, minimal patch SHA, image/package and
registry SHA-256s, row/page geometry at 25/75, transfer-audit-off proof, managed
incarnation identity, cold-state proof, and direct request receipts. Output IDs,
usage, reasoning span and speculative work are equal-work gates. `small12` uses
client E2E; fixed1/pageheavy use client first-token timing. The existing analyzer
is deliberately diagnostic until a reviewer accepts any current-upstream
normalization adaptation.

No model, GPU, service, HTTP request, Docker action, route, credential, or
source edit was performed while preparing this plan.
