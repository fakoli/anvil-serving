# Independent repaired baseline-adapter rereview

```yaml
schema_version: operator-workflow/v1
request: Rereview the single repaired current-upstream HTTP baseline adapter against the original HOLD findings.
gate_state: residual_hold
targets:
  - harness/baseline-adapter.py
  - harness/check-baseline-adapter.py
  - harness/README.md
tools_used:
  - read-only source and documentation inspection
  - offline contract check execution
  - bounded synthetic function probes with no network or lifecycle activity
artifacts:
  findings_summary:
    high: 2
    medium: 1
  reviewed_adapter_sha256: 27f76d8abadbd6dea9b3c0c4e9d4dd5e2cbc9ed0221e0b09861b7f7f3f25afd8
  reviewed_check_sha256: bf04b46323793aa0af257e231a855d9400172df5f07299569c4ea8417f4d28e8
  reviewed_readme_sha256: d37d00ca5991cae1769bcb0c2293a4de8631d8ae116f371d0b45794a89d109ff
advisory_priors:
  - The repaired adapter now binds exact frozen corpora, counts, case IDs, phase order, repeats, warmup extraction, arm/model/lane, and loopback destination.
  - Successful unknown SSE fields and terminal zero-token receipts are preserved without fabricating output; lane work validity remains separate.
recommendation: hold live fixture and phase execution; the authorized repair round did not close all material evidence and secret-custody defects
human_gate_required: true
promoted: false
```

Reviewer independence is unchanged: the implementation author is GPT-6-based Codex with exact variant unavailable; this reviewer is GPT-5.6 Sol high. No model request, GPU work, lifecycle action, or source mutation was performed.

## Findings

### HIGH — Credential exclusion is still bypassable and does not cover raw metrics

**Concrete inputs and wrong result (confirmed).** `sanitize` serializes an object and then searches the serialized representation for the unescaped key (`baseline-adapter.py:85-89`). A credential containing a JSON-escaped character is transformed before the search. The offline probe `key='abc"def'`, value `{'echo': key}` was accepted, even though `write_json` would retain a JSON encoding that decodes to the exact credential. Separately, every raw Prometheus artifact is written directly with `write_bytes` and never passed through `sanitize` (`:293-298,332-337`). A literal key echoed into metrics would therefore be retained even for ordinary alphanumeric keys.

The revised offline test does not exercise credential echo in nested JSON, HTTP/SSE failures, identity responses, or raw metrics (`check-baseline-adapter.py:13-52`). This leaves the original secret-leak escalation trigger unresolved.

### HIGH — Malformed/incomplete token-ID work and non-200 metric captures can pass

**Concrete inputs and wrong result (confirmed).** `response_complete` checks terminal state, usage presence, observed model, and finish reasons, but does not validate token-ID element types or reconcile their count with `usage.completion_tokens` (`baseline-adapter.py:246-251`). `work_valid` checks only one ID for fixed1 and nonempty IDs for every other lane (`:254-261`). Synthetic closed responses with `output_token_ids=['not-an-int']` were accepted for both fixed1 and pageheavy; pageheavy also passed with `completion_tokens=99` and one retained ID. Such a receipt can be counted as complete frozen work despite missing or malformed output IDs.

`capture_metrics` retains HTTP status/error, but fixture and phase gates ignore both and test only string-prefix presence (`:177-180,293-303,332-342`). A 500 response body containing the six metric strings can satisfy the metric gate, while its non-200 status is not copied into the attempt receipt. This can falsely close a request without a valid before/after Prometheus observation.

The revised offline check covers a zero-token fixed1 rejection but not noninteger IDs, usage/ID disagreement, partial ID lists, HTTP status, or metric error state (`check-baseline-adapter.py:50-52`).

### MEDIUM — The advertised absolute deadline is not a hard stream/phase bound

**Concrete state and wrong result (plausible from the I/O path).** The CLI establishes a monotonic deadline, but `request_raw` performs one blocking `response.read` and the SSE path performs a blocking `readline` after setting a socket inactivity timeout (`baseline-adapter.py:141-155,193-207`). A peer that keeps each operation active by trickling bytes can extend a read beyond the absolute deadline; the deadline is checked only before the blocking operation. The README calls this an absolute deadline (`README.md:47`), and no owner-process hard timeout is bound in the adapter contract. Post-phase identity transport failure can also escape before `attempts.json` and `summary.json` are finalized because `capture_models` sits outside the attempt-finalization path (`baseline-adapter.py:346-358`).

This is not an argument for a new framework. A lifecycle-owner subprocess hard cutoff plus explicit receipt, or a transport loop that enforces remaining wall time and finalizes partial receipts, would be sufficient. Neither is present in the reviewed bytes or tests.

## Closed portions of the original HOLD

- Exact corpus byte/hash/count contracts, fixed1 reverse measured order, original small12 IDs, repeat bounds, and warmup wrapper extraction are now enforced (`baseline-adapter.py:29-82`). Pageheavy remains forward in both phases, matching the retained `frozen-prior/replay.py` behavior.
- URL parsing now rejects userinfo and non-loopback destinations; output is exclusively reserved before network activity and leaf writes use exclusive/no-follow creation (`:92-127,383-397`).
- Authenticated `/v1/models` is captured before and after a successful phase, the owner proof is retained, missing SSE model identity prevents closure, and partial successful SSE events plus HTTP/SSE error bodies are retained in the response artifact (`:158-174,183-251,285-312,315-358`).
- Successful unknown event fields remain in the raw event object. A terminal zero-token response is preserved but does not satisfy fixed1 work. No absent output is synthesized.
- Corpus/repeat bounds prevent the original arbitrary request-count expansion. Current metric names remain eager native series, so lazy registration is not a blocker.

## Breakage probes and test coverage

The original four-axis probes were reused before reading the repaired check:

| Axis | Probe | Rereview result |
|---|---|---|
| Fail closed | Non-200 metrics with matching text; stale/malformed work receipt | **Confirmed defect:** status/error is ignored and malformed IDs pass work validity. |
| Malformed/boundary | Userinfo URL, symlink output, JSON-escaped credential, noninteger IDs | URL/output attacks are refuted; escaped credential and noninteger ID attacks are confirmed. |
| Resource exhaustion | Oversized corpus/repeat and a trickling stream | Corpus/repeat are refuted; hard stream deadline remains plausible and untested. |
| State drift | Wrong model, lane/corpus mismatch, identity failure | Wrong model and lane/corpus are refuted; post-phase identity transport failure can prevent final aggregate receipts. |

`python3 harness/check-baseline-adapter.py` passes, but it tests only metric-prefix membership, URL parsing, four lane/order/count examples, output reservation, and one zero-token work case. It does not cover the confirmed defects or exercise the actual HTTP/SSE retention path.

## Verdict

The one repaired version materially improves the adapter, but it is still not safe or sufficient to create the live current-upstream baseline evidence. **Residual HOLD** on the fixture and all phases. This review does not request scope expansion or another author repair cycle; the parent may replace or separately repair the adapter under a new reviewed stage. The committed compatibility source review and build remain unaffected. No promotion, allocator policy change, upstream submission, or live operation is authorized.
