# Independent driver-615.71.10 action delta review

```yaml
schema_version: operator-workflow/v1
request: Narrowly review the driver-615.71.10 guard, fresh custody paths, and PID receipt added to the previously accepted baseline lifecycle action.
gate_state: go_with_existing_gates
targets:
  - runtime/current-baseline-tool-action-driver6157110.json
  - runtime/current-baseline-plan-driver6157110.md
tools_used:
  - read-only exact-hash verification
  - read-only embedded-Python diff against the previously accepted action
  - read-only review of recorded synthetic driver-guard outcomes
artifacts:
  findings_summary:
    critical: 0
    high: 0
    medium: 0
    low: 0
  reviewed_action_sha256: ce76ee5cb2ae193263d301ff4dc5320bf6aa917214cea91f9ff6a41301097669
  reviewed_executable_sha256: e853594eb5d6c321055ba6577cf7e718bbc697a504e7f941bb28de872b1a49d8
  reviewed_plan_sha256: 17368c4525555123f18c7c5ab583800b44e89a5b9e5ca3a4bf81b29f13ff8ba6
  accepted_source_action_sha256: bb72682457706b35f2e07a6ec98750b3da180012c74475c9d7cfd9032de2ef69
advisory_priors:
  - The first window failed before candidate creation during a concurrent package upgrade; it remains immutable evidence and is not replaced by this attempt.
  - Driver 615.71.10 results are not causally comparable to retained 615.71.09 timings as an upstream-code-only change.
recommendation: go after a new boundary manifest binds these exact v2 bytes and the incumbent restoration from the failed window is independently closed
human_gate_required: true
promoted: false
```

## Findings

No material defect was found in the bounded delta.

The executable diff from the accepted action is limited to:

- unique v2 action, boundary-manifest, and evidence-root paths;
- an exclusive `owner.json` receipt containing the native PID, action path, creation time, and root-only owner declaration;
- a pre-quiesce `verify_driver` guard; and
- the required `re` import.

`verify_driver` runs before incumbent reconciliation, candidate discovery, router validation, and every outage mutation. It requires exactly two rows whose UUID/version pairs equal the pinned GPU set and `615.71.10`, exactly one loaded NVRM `615.71.10` version from `/proc/driver/nvidia/version`, and exact `modinfo -F version nvidia` output. Nonzero exit, timeout, duplicate/missing/extra GPU, mixed version, malformed loaded-version output, or module mismatch raises before `quiesced` is set. Its `finally` writes the bounded failure or success receipt.

## Breakage-probe disposition

| Axis | Concrete probe | Result |
|---|---|---|
| Unreadable state/tools | `nvidia-smi` or `modinfo` exits nonzero/times out; `/proc/driver/nvidia/version` is unavailable | **Refuted:** the guard raises before quiesce and retains `driver-pre-outage.json` where the output root exists. |
| Malformed/boundary | Duplicate UUID, one missing GPU, extra/mixed GPU row, `.09` from any source, malformed or multiple loaded NVRM versions | **Refuted:** length, set equality, exact loaded-version list, and exact module string all must match. |
| Resource bounds | Driver commands hang or emit unexpected output | **Refuted for the intended probe:** each subprocess has a 15-second timeout; the proc file is the bounded kernel driver-version surface. |
| State drift | Old action/output reused or accepted `.09` evidence treated as same-driver timing | **Refuted:** action, boundary, and output paths are unique; source action and new executable hashes are recorded; the plan and metadata explicitly forbid code-only causal comparison across driver versions. |

The action records nine passing fully mocked guard cases covering the success path, old/mixed versions, duplicate/missing GPUs, nonzero status, and timeout. No live driver, GPU, request, or lifecycle command was used by the author or this review.

## Scope and remaining gates

All lifecycle, secret-custody, request, fixture-inspection, candidate-cleanup, and retained-incumbent restoration behavior is byte-identical to the previously accepted action. That acceptance remains applicable. The parent must first close the in-progress restoration from the failed window, then create a fresh approved boundary manifest binding this action, executable, plan, final adapter review, and frozen inputs. Any later byte change requires rereview.

The pre-quiesce guard proves only the driver/GPU identity at that point. It does not erase the failed window, establish a reboot-tested system, or make `.10` measurements equivalent to `.09` measurements.

## Verdict

**GO** for the already authorized bounded diagnostic attempt under the existing boundary freeze, fixture review, cutoff, and restoration gates. No promotion, upstream submission, numerical shortcut, or upstream-code-only performance claim is authorized; `promoted=false` remains required.
