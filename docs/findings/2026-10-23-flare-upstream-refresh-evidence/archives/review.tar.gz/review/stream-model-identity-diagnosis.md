# Stream model identity: bounded source diagnosis

**Disposition:** the recorded mismatch is a harness identity-role assumption, not a demonstrated upstream server regression. Do not modify the signed package or relax identity to an arbitrary alias/revision allowlist. A prospectively frozen distinction between advertised alias and canonical response model is the smallest supported correction.

Source inspected: `OPERATOR_PATH_59467bb8d1e2/flare-cache-row-share-20261023`, clean HEAD `0b21d7f4883ac6f2b099df55813e8be06777b9df` (upstream `d5fd9824593c2a70f6bdc001b39f16b4c5b3b0b4` plus the legacy GLM template compatibility change). No source edits, build, model request, or lifecycle action occurred during this diagnosis.

## Actual receipt

`formal/current-baseline-monitorfix/00-fixtures/fixture-fixed1/http/identity-before.json` and `identity-after.json` both report HTTP200 and one catalog row with:

- `id = glm53-flare-d5fd9824-compat-tp2-c4-mtp3`
- `root = dec48abd33efa73c3bb7c95b74eee10cad34f9be`

The retained `response.json` has HTTP200 and its first decoded event is `chat.completion.chunk`, ID `chatcmpl-1-2`, with `model = dec48abd33efa73c3bb7c95b74eee10cad34f9be`. The adapter records `complete=false`, `observed_model=null`, and `ValueError` because it rejects the event before completing normalization. This is a retained failed fixture; successful startup/smoke does not turn it into a passing fixture. Prompt tokens are unnecessary for this diagnosis and are not included here.

## Complete response identity path

| Source | Behavior |
|---|---|
| `flare/src/cli.rs:394` and `:511` | Flag description replaces serving alias while retaining canonical model ID. |
| `flare/src/main.rs:242–253` | Clones verified owner server configuration, replaces only `config["served_names"]` at248–249, and leaves `model_id` unchanged before `serve`. |
| `helios/src/server/config.rs:132,299–322` | Parses canonical `model_id` into `ModelConfig` and aliases separately into `ServerConfig.served_names`. |
| `helios/src/server.rs:61–66,91–107,207–241,386–400` | Server aliases go to the model-discovery router; HTTP state retains the loaded model runtime. There is no response-alias field or runtime model-ID rewrite. |
| `helios/src/server/models.rs:30–54` | First nonempty alias becomes catalog `id`; canonical `model_id` remains catalog `root`; aliases and canonical ID resolve to the same model card. |
| `helios/src/server/http.rs:330–343` | All ordinary generation protocols construct the shared `Encoder` with the loaded `ModelConfig.model_id`, not the request's model string or advertised alias. |
| `helios/src/server/protocol/encode.rs:211–213,625–662` | Chat/text-completion chunks and buffered Chat/Completions/Messages/Responses objects serialize the supplied encoder model. Responses streaming objects and Messages start objects use this same shared encoder state. |
| `helios/src/server/http.rs:467–469`; `server.rs:607–620` | Opt-in raw observed-token Chat chunks independently use that same canonical ID. Fixing only the shared Encoder caller would leave this second path inconsistent. |
| `helios/src/server/protocol/decisions/mod.rs:262` | Both System One and Decisions JSON responses also use the loaded canonical ID. |

The standalone native frontend helper `server/request.rs:40` checks the canonical model ID; HTTP generation uses the protocol decode/prepare-inference path instead. This helper is not an alias-to-response rewrite. No additional response `model_id` caller was found in the server source search. Runtime progress labels that show `model_id` are not API aliases.

## What is actually promised

`docs/cli-design.md:518–522` explicitly says `--served-model-name` changes the name advertised by `/v1/models` and accepted for requests, replaces the package aliases, and leaves the canonical ID accepted and visible as card `root`; the override does not change the package or its identity. It does **not** promise alias echo in response `model`. This is positive evidence of two identity roles, combined with explicit canonical-ID response wiring across protocols, not merely an inference from missing documentation. `docs/api.md:635,704` describes decision responses as containing the loaded model.

Therefore: catalog/request alias override is supported; response serialization consistently reports the canonical loaded ID. It would require an explicit compatibility requirement to change that public response behavior. The live mismatch alone does not establish such a defect.

## Smallest durable correction and tests

Bind three separate facts before the next request: exact managed served alias/container/image/registry/package identity; exact catalog `id` equal to that alias; exact catalog `root` equal to the **prospectively pinned signed contract model_id**. The canonical ID happens to equal the checkpoint revision here, but the contract must not assume that relationship generally or learn an arbitrary acceptable value from the failing stream. Require every model-bearing SSE event to equal that exact canonical response ID, and retain the alias/catalog-root before-and-after checks and all existing work/output/deadline gates. Preserve this failed window and freeze the corrected response-role contract before any new attempt.

The smallest behavioral regression uses this closed event/catalog fixture: alias matches while canonical root/model match the independent pin (pass); changed catalog alias, changed root, canonical ID inconsistent with the owner/package pin, changed first-event model, or a later event changing model (fail). Keep unrelated model values, missing required model fields, malformed payloads, and mixed identities rejected. No broad alias-or-root fallback is needed.

Existing native tests distinguish the identities already: `server::models::tests::discovery_uses_the_first_nonempty_alias_or_checkpoint_id` (`models.rs:241`) asserts alias card ID and unchanged root; `http_discovery_and_lookup_share_cards_and_handle_repository_ids` (`:280`) tests alias/canonical retrieval. `server/protocol/tests.rs` exercises shared encoders using an explicit model string, and `server.rs:726–732` exercises observed chunks, but these do not establish an end-to-end promise to echo `--served-model-name`. No tests were run during this read-only diagnosis.

If a maintainer instead requires response aliasing, the smallest coherent **separate server change** would choose the same first nonempty serving name once at HTTP bootstrap (canonical fallback), carry it as response identity in `HttpState`, and use it in the Encoder, observed-token chunks, and decision responses while leaving signed `ModelConfig.model_id` and catalog `root` unchanged. Add CPU tests for those paths and explicit CLI/API wording. This is an optional contract change, not a prerequisite justified by the current evidence.

## Upstream duplication check

Read the retained `source/github-inventory.json`, observed `2026-10-24T03:25:34.442Z`: 37 PRs and their descriptions. No listed pending PR addresses serving aliases or response model identity. Relevant open response/parser work is [#59](https://github.com/NVIDIA/flare-local-inference/pull/59) (`1f38c71d0dde0f7e3ac8c571b3dfcb8f05976b2b`), [#67](https://github.com/NVIDIA/flare-local-inference/pull/67) (`c6fa234c13eadc74f454eedb82ed57c241e31b19`), and [#49](https://github.com/NVIDIA/flare-local-inference/pull/49) (`960545fa58328db5328cded51c2e661b4bc84cf6`): tool syntax/selection, not model identity. [#57](https://github.com/NVIDIA/flare-local-inference/pull/57) (`21a2030b2dddb4602f46cc7b72fbc299c3784999`) adds lifecycle metrics, not response aliasing. This is an inventory-as-observed conclusion; no fresh GitHub fetch or claim about later PRs was made.
