# Independent baseline-adapter review

```yaml
schema_version: operator-workflow/v1
request: Review the current-upstream HTTP baseline adapter before any live request.
gate_state: hold
targets:
  - harness/baseline-adapter.py
  - harness/check-baseline-adapter.py
  - harness/README.md
tools_used:
  - read-only file and source inspection
  - offline URL parsing probe
artifacts:
  findings_summary:
    critical: 0
    high: 3
    medium: 0
    low: 0
  reviewed_adapter_sha256: 254f572bd9d01d7e862d0dbdfdcaa9851336f787c3881d97dad6fe0609d03879
  reviewed_check_sha256: ce53a519a4bd3b814ae1a0487d3578fa7d1eff791f5e4dd5bc571faa736567ba
advisory_priors:
  - The closed harness binds corpus hashes, phase order, absolute deadlines, endpoint identity, and partial failure receipts.
  - Current upstream renders all six required metric families even at zero, so the adapter's metric-presence check is not blocked by lazy series registration.
recommendation: hold; one bounded repair round is appropriate before HTTP execution
human_gate_required: true
promoted: false
```

Reviewer independence: the author reports only a trusted family identity, GPT-6-based Codex; the exact variant is unavailable. This reviewer is GPT-5.6 Sol. No live request or lifecycle action was used for this review.

## Findings

### HIGH — The adapter does not bind or reproduce the frozen workload contract

**Concrete state and wrong result (confirmed).** An arbitrary nonempty JSON list is accepted as a frozen lane; neither known corpus digest, expected count, request options, nor ordered per-body hashes are checked (`baseline-adapter.py:21-32`). `phase` is only recorded as metadata and does not select the closed harness's measured ordering (`:165,199-205`). The retained harness reverses the 52-case fixed-work measured phase (`frozen-prior/replay.py:37-41,63`), while this adapter sends every phase forward. The current implementation also renumbers the retained small12 cases 40..51 as 0..11 (`baseline-adapter.py:26-32`), and treats the three warmup wrappers as request bodies instead of sending each wrapper's `body` member. A fixture from another lane or corpus is accepted because closure checks only schema, arm, model, and response shape (`:133-138,196-204`). The result can be labeled as the current baseline despite using changed bodies, wrong order, or a malformed warmup. The intended pageheavy order must likewise be encoded and bound rather than left to a phase-name convention.

**Minimum repair.** Define a small immutable lane table with exact corpus SHA-256, count, body extraction, original case IDs, phase ordering, and allowed repeat counts. Bind these values into both the fixture and phase receipts; reject a fixture whose lane/corpus/body identity differs. Preserve the existing frozen request objects except for the explicitly declared served-model substitution. Keep `performance_eligible: false`.

### HIGH — Endpoint identity and failed/partial response evidence are not closed

**Concrete state and wrong result (confirmed).** The only response identity check is conditional on an SSE event carrying `model`; an event with no model is accepted, and there is no authenticated `/v1/models` check before or after the phase (`baseline-adapter.py:88-92,113-123`). Any exception discards the in-memory partial event stream and replaces it with `RuntimeError("request failed")`; the phase retains only the exception class (`:68-110,212-226`). HTTP error bodies are also lost. Thus a restart or unexpected endpoint whose events omit `model`, a closed stream with an upstream error, or a partially emitted response can leave no evidence sufficient to distinguish identity drift, protocol failure, and model behavior. Successful unknown SSE fields are preserved in `events`, and a terminal zero-token response is currently accepted and preserved; those two behaviors are appropriate for a diagnostic adapter and should remain.

The API key is not recursively checked against response events, raw metrics, or error material before retention (`:39-47,87-107,126-144`). An upstream echo could therefore put the credential in evidence.

**Minimum repair.** Capture exact authenticated `/v1/models` identity before and after the phase, together with the lifecycle owner's incarnation proof. Always write a bounded response receipt in `finally`, including partial events, terminal state, and a bounded HTTP/SSE error body; have each attempt reference its path and digest. Recursively reject the literal key in every retained object and raw text. Do not invent absent output fields and do not turn a zero-token response into a successful fixed-one-token result; lane-specific work requirements belong in the frozen lane contract.

### HIGH — Network destination, output custody, and total work are not fail-closed

**Concrete inputs/states and wrong results (confirmed/plausible).** The string-prefix URL check accepts `http://127.0.0.1:80@evil.test/...`; standard URL parsing resolves its hostname as `evil.test`, so the claimed loopback restriction is bypassable (`baseline-adapter.py:151,168-169`). `repeat`, body-file size, row count, and total phase duration are unbounded (`:21-32,166,199-233`), while `urlopen(timeout=...)` is a per-operation timeout rather than an absolute request or phase deadline. A large corpus, huge repeat, or trickling stream can exceed the intended outage window. Output paths are checked only when each file is written, after metrics or model traffic may already have occurred; `exists()` followed by `write_text()` is non-atomic and follows symlinks (`:126-144,175-194,205-227`). An occupied or swapped output can therefore fail after network activity or redirect retained evidence.

**Minimum repair.** Parse the URL and require exactly `scheme=http`, `hostname=127.0.0.1`, a valid explicit port, and no userinfo, query, or fragment. Exclusively reserve a new output directory before any network call and use exclusive/no-follow bounded writes with durable finalization. Apply exact lane count/repeat bounds plus an absolute phase deadline; every connect/read timeout must be clipped to remaining time.

## Breakage probes and test coverage

The probes were defined before reading `check-baseline-adapter.py`:

| Axis | Probe | Result |
|---|---|---|
| Fail closed | Occupied output or unreadable/mismatched frozen corpus before HTTP | **Confirmed:** corpus identity is not checked; occupied leaf files are discovered only after traffic can begin. |
| Malformed/boundary | Loopback-looking URL with userinfo; symlinked output; missing SSE model; terminal zero-token SSE | **Confirmed:** non-loopback hostname passes the prefix; symlinks are followed; missing model and zero-token terminal receipts pass. Zero-token preservation is desirable, but it cannot satisfy fixed-one-token work. |
| Resource bounds | Very large file/repeat and a trickling SSE stream | **Confirmed/plausible:** no file/count/repeat/phase bound and no absolute stream deadline. |
| State drift | Endpoint restarts or changes model while events omit `model`; fixture from a different lane/corpus | **Confirmed:** both are accepted by current validation. |

The offline check covers only metric-prefix membership, one ordinary successful response, and list slicing/counts (`check-baseline-adapter.py:11-22`). It does not cover any probe above. The metric concern itself is refuted: current `SchedulerMetrics::render` eagerly emits every lookup/store reason and all histogram families (`helios/src/server/metrics.rs:560-626`), and `host_cache_row_refills_total` is a normal scalar metric (`:863-866`).

Add focused negative tests for the exact corpus/order contract, warmup unwrapping, small12 IDs, malformed loopback URLs (including userinfo), occupied/symlink outputs, bounded repeat/file/deadline behavior, partial SSE and HTTP errors, missing/wrong endpoint identity, zero-token terminal retention, unknown SSE-field retention, and literal-key echo rejection.

## Residual risk and verdict

This adapter is not yet safe or sufficient for the current upstream-plus-compat diagnostic baseline. The issues are contained enough for one bounded repair round; a full promotion harness or new framework is unnecessary. **HOLD all adapter HTTP execution until the three findings and their focused tests are closed.** This review does not authorize GPU/lifecycle work, a row-share policy change, upstream submission, or promotion.
