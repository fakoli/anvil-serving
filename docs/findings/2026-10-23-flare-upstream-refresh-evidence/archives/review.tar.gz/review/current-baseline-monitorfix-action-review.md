# Independent monitoring-fix action delta review

```yaml
schema_version: operator-workflow/v1
request: Review only the private monitoring-map guard and unique custody paths added to the final accepted driver action.
gate_state: go_with_existing_gates
targets:
  - runtime/current-baseline-tool-action-monitorfix.json
  - runtime/plan-monitorfix.md
  - hosts/dark-linux/operator-home/recipe-monitoring.json
tools_used:
  - read-only exact-hash verification
  - read-only embedded-Python diff against the final accepted driver action
  - read-only monitoring loader/source and recorded focused-check review
artifacts:
  findings_summary:
    critical: 0
    high: 0
    medium: 0
    low: 0
  reviewed_action_sha256: 4edf6af3d24a3acb6b52ce47ee85f679812f48f6ab48438e3d31f314919132af
  reviewed_executable_sha256: 5323973b720f8f23de0d86a6a5c0dff0c6e93d2f88f27c5bdd735146eb6bab3b
  reviewed_plan_sha256: 6c941f8881bfe254c5db5a3bb91cb854faf455bc1eadb521aac18476afbe52f6
  reviewed_monitoring_config_sha256: 9248a55151e0118e290af8a5d1772244923b03e81097596fe3fdceb6ef516efc
  accepted_source_action_sha256: f95870d032eeca87f278cdb0619984174053ccf0181c8e59ddfb2d3d3e2a7574
advisory_priors:
  - The prior driver-615.71.10 attempt is closed with restored=true and retained as a no-request monitoring-registration failure.
  - The implementing agent is GPT-6-based Codex with exact variant unavailable; this reviewer is GPT-5.6 Sol high and did not generate or grade model output.
recommendation: go after a new boundary manifest binds the exact reviewed action, plan, and monitoring-config hashes
human_gate_required: true
promoted: false
```

## Findings

No material defect was found in the focused delta.

The executable diff from the final accepted driver action is limited to unique monitor-fix action/boundary/evidence-root paths, adding the selected private `recipe-monitoring.json` to the required frozen files, and calling `verify_monitoring_config()` before incumbent reconciliation or any outage mutation.

The guard temporarily selects the exact operator home, verifies that the shared loader resolves the expected absolute path, calls the production `recipe_monitoring.configuration()` parser, and requires both port `39130` and engine mapping `flare-d5fd9824-compat -> flare`. The production parser independently bounds and validates the complete schema, port list, engine-contract values, and protected key-file references. The prior process environment is restored in `finally`, and the action retains only path/hash plus the non-secret engine, port, contract, status, and error class.

The private config currently hashes to `9248a55151e0118e290af8a5d1772244923b03e81097596fe3fdceb6ef516efc`; the registry declares the exact engine and port tested by the guard.

## Breakage-probe disposition

| Axis | Concrete probe | Result |
|---|---|---|
| Fail closed | Missing, unreadable, malformed, or production-loader-rejected monitoring config | **Refuted:** configuration failure is retained and raises before `quiesced` is set. |
| Malformed/boundary | Port absent, engine absent, or engine mapped to another supported contract | **Refuted:** exact port membership and exact `flare` contract are mandatory. |
| Resource bounds | Oversized or non-regular config | **Refuted by the production loader:** `read_json` uses no-follow regular-file access and a 64 KiB limit. |
| State/config drift | Another operator home is selected or the private config changes after parent approval | **Refuted within the frozen action:** resolved path equality is required, the config is a required boundary-manifest input, and `verify_frozen()` checks it before the pre-outage guard and before every candidate incarnation. |

The action records six offline guard cases for valid, missing/wrong mapping, missing port/config, and malformed config, including environment restoration and retained receipts. No lifecycle, model, GPU, or network operation was used in this review.

## Scope and remaining gates

All request, driver, secret-custody, identity, cutoff, cleanup, restoration, and corrected preflight-validation code is byte-identical to the final accepted source action. That review remains applicable. The closed prior attempt must remain a monitoring-integration failure with zero candidate requests; it cannot be silently replaced or counted as a performance population.

The parent-owned boundary manifest must bind the exact config digest `9248a551...` as well as the reviewed action, executable, plan, final adapter review, and existing frozen inputs. Any byte change requires rereview. The first fixture/monitoring registration remains the live proof; this static GO does not establish that the observer scrape succeeds.

## Verdict

**GO** for the already authorized bounded retry under the existing boundary freeze, fixture inspection, request cutoff, and exact restoration gates. No promotion, upstream submission, numerical shortcut, or cross-driver causal claim is authorized; `promoted=false` remains required.
