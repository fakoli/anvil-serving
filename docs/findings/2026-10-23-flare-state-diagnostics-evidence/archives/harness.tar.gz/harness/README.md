# Protected-lane ABBA follow-up harness

This is a **prepared, non-executing** diagnostic harness for the retained `small12` and `pageheavy` r3 protected-lane regressions. It performs no model load, GPU action, HTTP request, Docker action, or output-directory creation. The lifecycle owner must retain managed load/readiness/source/registry/image evidence, execute phases, unload, and restore the incumbent.

`frozen-prior/` is a byte-for-byte provenance copy of the prior `replay.py`, `run-phase.py`, and three frozen body inputs. They are not executed from this directory because their paths and runtime bindings belong to the closed campaign. The adapter validates their hashes and emits commands that deliberately call the immutable prior phase wrapper.

## Local preparation check

```sh
python3 -B prepare-protected-bracket.py --check
```

This checks the ABBA order, 32 GiB cache budget, A/B shares and geometry, the v2 timing image/source patch, timing registries (with byte audit disabled), all frozen file hashes, and request accounting. It is safe offline.

## Root-owned execution preview

After choosing a **new nonexistent** output directory and a window cutoff, the lifecycle owner can print the exact HTTP-phase commands:

```sh
python3 -B prepare-protected-bracket.py --print-commands \
  --output-root OPERATOR_PATH_1ea2546ad27d/protected-abba-1 \
  --request-deadline-epoch <unix-epoch>
```

The emitted commands contain only the retained `run-phase.py` calls. They do not load or unload a model. Before each fresh `A`, `B`, `B`, `A` incarnation, retain the managed lifecycle/readiness identity evidence and ensure the selected timing registry is `registry-v2-a.toml` (25%, 52 rows, 7314 pages) or `registry-v2-b.toml` (75%, 158 rows, 2434 pages), respectively. Both use the source `47581ccac82660953a5b59cb04b2750d64edc97d`, v2 patch `b132065b27532028bf2a02e754e86553ea846281f616f22ce74e89442ff0ec76`, and image `sha256:d8fb208298fd3dd3f6b2b631148b01467a9449a9dcd1fef7dca304714bcf9411`.

For each of four incarnations per lane, the plan runs three disjoint warmups, a 12-request prime, then measured requests: two 12-request small12 iterations (24/arm) or one 12-request pageheavy iteration (12/arm). Across both lanes this is 144 measured, 96 prime, and 24 warmup requests: **264 HTTP requests**. Existing phase time bounds total 124 minutes serially (small12: 18 minutes × 4; pageheavy: 13 minutes × 4), excluding load/readiness, failures, and incumbent restoration. Those are bounds, not predicted performance.

## Trace and normalization

The supported command surface recorded by the prior harness is `anvil-serving models recipes scheduler-trace`. Capture an equal A/B trace bracket separately from the timing runs: no detailed trace during any timed phase and never only one arm. Keep trace output as diagnostic scheduler evidence; it is not a timing metric or proof of host-transfer behavior.

After all native files are closed, use the frozen `normalize.py` pattern offline against a new follow-up input layout. It must retain every attempted/missing/failed phase and trace reference. Do not overwrite the prior campaign’s normalized matrix or use its three-pair AB/BA/AB acceptance assumptions for this ABBA diagnostic. This follow-up remains `performance_eligible=false` until a reviewed normalizer establishes full denominators, matching work/output, retained failures, and source/image/registry identity.
