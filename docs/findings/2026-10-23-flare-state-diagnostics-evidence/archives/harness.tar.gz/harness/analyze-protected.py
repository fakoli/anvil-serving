#!/usr/bin/env python3
"""Offline-only protected ABBA summary. It cannot qualify a candidate."""
import argparse
import hashlib
import json
import math
import statistics
import tempfile
from pathlib import Path

LANES = {
    'small12': {'measured': ['measured','measured-2'], 'expected_measured': 24, 'metric': 'e2e'},
    'pageheavy': {'measured': ['measured'], 'expected_measured': 12, 'metric': 'client_generated_ttft'},
}
ORDER = [('1-a','A'),('2-b','B'),('3-b','B'),('4-a','A')]
PAIRS = [('1-a','2-b'),('4-a','3-b')]


def number(value):
    return type(value) in (int,float) and math.isfinite(value)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_json(path, issues):
    try:
        raw=path.read_bytes(); return json.loads(raw), {'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()}
    except (OSError,ValueError) as error:
        issues.append(f'{path}: {type(error).__name__}')
        return None, None

def summary(values):
    values=[v for v in values if number(v)]
    if not values:return {'valid_count':0,'median':None,'p95_nearest_rank':None,'spread':None}
    ordered=sorted(values)
    return {'valid_count':len(values),'median':statistics.median(values),'p95_nearest_rank':ordered[math.ceil(.95*len(ordered))-1], 'spread':{'min':ordered[0],'max':ordered[-1],'range':ordered[-1]-ordered[0]}}

def work_signature(row):
    # All fields must be present and valid; mutually missing does not match.
    required=('body_sha256','prompt_tokens','output_token_ids','reasoning_tokens','speculative_work')
    absent=[key for key in required if key not in row]
    invalid=[]
    if not isinstance(row.get('body_sha256'),str):invalid.append('body_sha256')
    if type(row.get('prompt_tokens')) is not int or row['prompt_tokens'] < 0:invalid.append('prompt_tokens')
    ids=row.get('output_token_ids')
    if not isinstance(ids,list) or not ids or not all(type(x) is int and x>=0 for x in ids):invalid.append('output_token_ids')
    # Unknown reasoning is retained, never converted to zero; it may match only if explicitly null in both rows.
    if row.get('reasoning_tokens') is not None and (type(row['reasoning_tokens']) is not int or row['reasoning_tokens']<0):invalid.append('reasoning_tokens')
    if not isinstance(row.get('speculative_work'),dict):invalid.append('speculative_work')
    return absent,invalid,tuple((key,row.get(key)) for key in required)

def load_phase(base, name, expected, issues, refs):
    http=base/name/'http'
    rows, ref=read_json(http/'attempts.json',issues)
    if ref:refs.append(ref)
    doc, ref=read_json(http/'summary.json',issues)
    if ref:refs.append(ref)
    rows=rows if isinstance(rows,list) else []
    rows=[row if isinstance(row,dict) else {'case_id':f'malformed-{i}','ok':False,'normalization_error':'non-object attempt'} for i,row in enumerate(rows)]
    declared=doc.get('expected') if isinstance(doc,dict) else None
    return rows, {'phase':name,'expected':expected,'summary_expected':declared,'attempted':len(rows),'completed':sum(r.get('ok') is True for r in rows),'failed':sum(r.get('ok') is not True for r in rows),'missing':max(0,expected-len(rows))}

def incarnation(root,lane,name,arm):
    spec=LANES[lane]; base=root/lane/name; issues=[]; refs=[]
    phase_counts=[]; measured=[]
    all_phases=[('warmup',3),('prime',12)]+[(phase,12) for phase in spec['measured']]
    for phase,expected in all_phases:
        rows,count=load_phase(base,phase,expected,issues,refs); phase_counts.append(count)
        if phase in spec['measured']:measured.extend(rows)
    metric=spec['metric']; native='native_first_token_seconds'
    return {'incarnation':name,'arm':arm,'source_directory':str(base),'source_artifacts':refs,'issues':issues,
            'phases':phase_counts,
            'measured_denominator':{'expected':spec['expected_measured'],'attempted':len(measured),'completed':sum(r.get('ok') is True for r in measured),'failed':sum(r.get('ok') is not True for r in measured),'missing':max(0,spec['expected_measured']-len(measured))},
            'measured_rows':measured,
            'metrics':{'primary':{'field':metric,**summary([r.get(metric) for r in measured])},'native_first_token_seconds':summary([r.get(native) for r in measured])}}

def pair(left,right,metric,expected):
    a={str(r.get('case_id')):r for r in left['measured_rows']}; b={str(r.get('case_id')):r for r in right['measured_rows']}
    ids=sorted(set(a)|set(b)); cases=[]; deltas=[]
    for case_id in ids:
        ar,br=a.get(case_id),b.get(case_id); reasons=[]; output_equal=False; work_equal=False
        if ar is None or br is None: reasons.append('missing_case')
        else:
            if ar.get('ok') is not True:reasons.append('A_not_successful')
            if br.get('ok') is not True:reasons.append('B_not_successful')
            aa,ai,asig=work_signature(ar); ba,bi,bsig=work_signature(br)
            reasons += ['A_missing_'+x for x in aa]+['B_missing_'+x for x in ba]+['A_invalid_'+x for x in ai]+['B_invalid_'+x for x in bi]
            output_equal=(not ai and not bi and ar.get('output_token_ids')==br.get('output_token_ids'))
            work_equal=not reasons and asig==bsig
            if not work_equal and not reasons:reasons.append('work_fields_differ')
            av,bv=ar.get(metric),br.get(metric)
            if work_equal and number(av) and number(bv) and av>0:deltas.append(100*(bv-av)/av)
            elif work_equal:reasons.append('nonfinite_primary_metric')
        cases.append({'case_id':case_id,'output_ids_equal':output_equal,'work_equal':work_equal,'mismatch_or_invalid_reasons':reasons})
    complete=(set(a)==set(b) and len(a)==expected and len(b)==expected and left['measured_denominator']['failed']==0 and right['measured_denominator']['failed']==0)
    paired=summary(deltas) if complete and len(deltas)==expected else {'valid_count':len(deltas),'median':None,'p95_nearest_rank':None,'spread':None}
    return {'A_incarnation':left['incarnation'],'B_incarnation':right['incarnation'],'expected_cases_per_arm':expected,'identical_case_id_sets':set(a)==set(b),'output_ids_equal_cases':sum(c['output_ids_equal'] for c in cases),'complete_work_equal_cases':sum(c['work_equal'] for c in cases),'cases':cases,'paired_percent_delta_B_minus_A':paired,'delta_reason':None if paired['median'] is not None else 'requires complete equal case IDs, full denominators, successful matched work, and finite primary metrics'}

def analyze(root):
    if not (root/'CLOSED').is_file(): raise ValueError('refuse analysis without explicit formal/CLOSED marker')
    result={'schema':'flare-protected-abba-analysis/v1','diagnostic_only':True,'performance_eligible':False,'recommend_candidate':False,'historical_protected_threshold_percent':3.0,'historical_gate_status':'unchanged; this ABBA diagnostic cannot erase the prior failed gate','p95_method':'nearest-rank ceil(0.95*n)','input_root':str(root),'lanes':{},'source_artifacts':[]}
    for lane,spec in LANES.items():
        runs=[incarnation(root,lane,name,arm) for name,arm in ORDER]
        for run in runs:
            result['source_artifacts'] += run.pop('source_artifacts')
        by={run['incarnation']:run for run in runs}
        pairs=[pair(by[a],by[b],spec['metric'],spec['expected_measured']) for a,b in PAIRS]
        arms={arm:summary([row.get(spec['metric']) for run in runs if run['arm']==arm for row in run['measured_rows']]) for arm in ('A','B')}
        for arm in arms:arms[arm]['field']=spec['metric']
        result['lanes'][lane]={'primary_metric':spec['metric'],'incarnations':runs,'arm_primary_summary':arms,'pairs':pairs}
    return result

def self_check():
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp); (root/'CLOSED').write_text('closed\n')
        for lane,spec in LANES.items():
            for n,arm in ORDER:
                phases=[('warmup',3),('prime',12)]+[(x,12) for x in spec['measured']]
                for phase,count in phases:
                    d=root/lane/n/phase/'http';d.mkdir(parents=True)
                    rows=[]
                    for i in range(count):
                        case=f'{i}:{2 if phase=="measured-2" else 1}' if lane=='small12' and phase.startswith('measured') else str(i)
                        rows.append({'case_id':case,'ok':True,'body_sha256':'x','prompt_tokens':1,'output_token_ids':[1],'reasoning_tokens':None,'speculative_work':{},spec['metric']:1.0,'native_first_token_seconds':.5})
                    (d/'attempts.json').write_text(json.dumps(rows));(d/'summary.json').write_text(json.dumps({'expected':count}))
        output=analyze(root)
        assert output['lanes']['small12']['pairs'][0]['complete_work_equal_cases']==24
        assert output['lanes']['pageheavy']['pairs'][1]['paired_percent_delta_B_minus_A']['median']==0
        print('PASS: closed fixture retains full denominators and paired work/metrics')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('formal',type=Path,nargs='?');p.add_argument('--self-check',action='store_true');a=p.parse_args()
    if a.self_check:
        if a.formal:p.error('--self-check takes no formal root')
        self_check();return
    if a.formal is None:p.error('formal root is required')
    print(json.dumps(analyze(a.formal),indent=2,allow_nan=False))
if __name__=='__main__':main()
