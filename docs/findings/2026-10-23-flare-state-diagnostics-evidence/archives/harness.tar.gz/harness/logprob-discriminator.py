"""Four bounded HTTP observations; existing raw top20 output, no lifecycle."""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import time
import tomllib

E = Path(__file__).resolve().parents[2] / '2026-10-22-flare-cache-fix'
spec = importlib.util.spec_from_file_location('frozen_replay', E / 'harness/replay.py')
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)
spec = importlib.util.spec_from_file_location('frozen_phase', E / 'harness/run-phase.py')
phase = importlib.util.module_from_spec(spec)
spec.loader.exec_module(phase)


def distributions(response):
    entries = [entry for event in response['events']
               for choice in event['event'].get('choices', [])
               for entry in (choice.get('logprobs') or {}).get('content', [])]
    ids = response['output_token_ids']
    if len(entries) != 8 or len(ids) != 8 or response.get('usage', {}).get('completion_tokens') != 8:
        raise ValueError('logprob/emitted-token coverage incomplete')
    for entry, token_id in zip(entries, ids):
        top = entry['top_logprobs']
        if (entry['token'] != f'token_id:{token_id}' or len(top) != 20
                or len({t['token'] for t in top}) != 20
                or not all(math.isfinite(t['logprob']) for t in [entry, *top])):
            raise ValueError('invalid raw top20 observation')
    return entries


def compare(a, b):
    left, right = distributions(a), distributions(b)
    rows = []
    for index, (x, y) in enumerate(zip(left, right)):
        ax = {t['token']: t['logprob'] for t in x['top_logprobs']}
        by = {t['token']: t['logprob'] for t in y['top_logprobs']}
        common = ax.keys() & by.keys()
        rows.append({'index': index, 'same_history': True,
                     'same_sample': x['token'] == y['token'],
                     'top20_exact': x['top_logprobs'] == y['top_logprobs'],
                     'top20_common': len(common),
                     'max_common_abs_logprob_delta': max((abs(ax[k]-by[k]) for k in common), default=None)})
        if x['token'] != y['token']:
            break  # Subsequent independently sampled histories are not comparable.
    return rows


def run(output, proof):
    output.mkdir(mode=0o700)
    original = dict(replay.bodies('restore-pilot', 'prime'))
    model = original[51]['model']
    revision = replay.proven_source_revision(proof, model)
    binding = json.loads(proof.read_text())
    registry = Path(binding['registry'])
    recipe = tomllib.loads(registry.read_text())['recipe'][0]
    previous = None
    def status(label):
        nonlocal previous
        if hashlib.sha256(registry.read_bytes()).hexdigest() != binding['registry_sha256']:
            raise ValueError('registry changed')
        env = os.environ.copy()
        env['ANVIL_SERVING_HOME'] = 'OPERATOR_PATH_601ba1a688c8/operator-home'
        args = [phase.PY, '-m', 'anvil_serving.cli', 'models', 'recipes', 'status',
                recipe['model'], '--container', phase.CONTAINER, '--registry', str(registry), '--json']
        result = subprocess.run(args, cwd=phase.WORKTREE, env=env, capture_output=True, text=True, timeout=10)
        (output / f'{label}-status.json').write_text(result.stdout)
        envelope = json.loads(result.stdout)
        if result.returncode or not envelope.get('ok'):
            raise ValueError('managed status failed')
        value = envelope['data']
        current = json.loads(value) if isinstance(value, str) else value
        previous = phase.validate(current, recipe, previous, binding['verified']['image_digest'])
        phase.select_running({'containers': [binding['verified']]}, current,
                             binding['registry_sha256'], binding['recipe_sha256'])
    key, identity = replay.prior.read_key(replay.prior.KEY)
    results = []
    for case in (51, 40):
        responses = []
        body = {**original[case], 'max_tokens': 8, 'seed': 0, 'temperature': .95,
                'top_p': .95, 'top_k': -1, 'logprobs': True,
                'top_logprobs': 20, 'return_tokens_as_token_ids': True}
        raw_body = json.dumps(body).encode()
        (output / f'{case}-body.json').write_bytes(raw_body)
        for label in ('first', 'repeat'):
            stem = f'{case}-{label}'
            status(stem+'-before')
            if replay.prior.read_key(replay.prior.KEY)[1] != identity:
                raise ValueError('credential identity changed')
            raw, before = replay.prior.idle(key)
            (output / f'{stem}-before.prom').write_text(raw)
            response = replay.request(body, key, time.monotonic()+60,
                output / f'{stem}-response.json', {model, revision}, raw_body)
            status(stem+'-after')
            if replay.prior.read_key(replay.prior.KEY)[1] != identity:
                raise ValueError('credential identity changed')
            raw, after = replay.prior.idle(key)
            (output / f'{stem}-after.prom').write_text(raw)
            delta = {k: after[k]-before[k] for k in replay.prior.COUNTERS}
            if (after['flare_uptime_seconds'] < before['flare_uptime_seconds']
                    or any(v < 0 for v in delta.values())
                    or delta['flare_requests_completed_total'] != 1
                    or any(delta[k] for k in ('flare_requests_cancelled_total',
                        'flare_host_cache_store_failed_total', 'flare_host_cache_fetch_failed_total'))):
                raise ValueError('reset, interference or failed transfer')
            distributions(response)
            responses.append(response)
            results.append({'case': case, 'phase': label, 'deltas': delta,
                            'body_sha256': hashlib.sha256(raw_body).hexdigest(),
                            'output_token_ids': response['output_token_ids']})
            replay.prior.write(output / 'results.json', results)
            prompt = response['usage']['prompt_tokens']
            prefill, gpu, host = (delta[k] for k in ('flare_prefill_tokens_total',
                'flare_cache_reused_tokens_total', 'flare_host_cache_reused_tokens_total'))
            if prefill+gpu+host != prompt or host or delta['flare_host_cache_fetched_total']:
                raise ValueError('prompt accounting or no-host-fetch gate failed')
            if (label == 'first' and prefill <= 0) or (label == 'repeat' and (prefill != 0 or gpu != prompt)):
                raise ValueError('prefill versus full-GPU-hit discriminator not observed')
        replay.prior.write(output / f'{case}-comparison.json', compare(*responses))
    replay.prior.write(output / 'summary.json', {
        'requests': len(results), 'full_logits_oracle': False,
        'historical_128_id_gate_cleared': False, 'performance_eligible': False})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--identity-proof', type=Path, required=True)
    args = parser.parse_args()
    run(args.output, args.identity_proof)
