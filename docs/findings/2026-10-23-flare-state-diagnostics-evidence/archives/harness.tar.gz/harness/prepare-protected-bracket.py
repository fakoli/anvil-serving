#!/usr/bin/env python3
"""Validate a non-executing protected-lane ABBA plan and print root-owned commands."""
import argparse
import hashlib
import json
import shlex
import sys
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PLAN_PATH = ROOT / 'protected-regression-plan.json'
PRIOR = Path('OPERATOR_PATH_45ed7a70cf41/2026-10-22-flare-cache-fix')
PYTHON = 'OPERATOR_PATH_9ba32d4067f1/python'
WORKTREE = 'OPERATOR_PATH_cc25b9dd30c4/anvil-serving'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def fail(message):
    raise ValueError(message)

def load_plan():
    plan = json.loads(PLAN_PATH.read_text())
    if plan.get('schema') != 'flare-protected-regression-followup/v1':
        fail('unexpected plan schema')
    if plan.get('status') != 'prepared_not_executed':
        fail('plan must remain prepared_not_executed')
    return plan

def validate(plan):
    bracket = plan['timing_bracket']
    if bracket['order'] != ['A','B','B','A'] or not bracket['separate_fresh_incarnations']:
        fail('ABBA fresh-incarnation contract changed')
    cfg = bracket['config']
    if cfg['host_cache_budget_bytes'] != 34359738368 or cfg['row_percent'] != {'A':25,'B':75}:
        fail('fixed 32GiB / 25-75 configuration changed')
    if cfg['rows'] != {'A':52,'B':158} or cfg['pages'] != {'A':7314,'B':2434}:
        fail('geometry changed')
    runtime = json.loads((PRIOR/'runtime-pins.json').read_text())
    if runtime['image'] != cfg['image'] or runtime['source_patch_sha256'] != cfg['source_patch_sha256']:
        fail('runtime pin differs from plan')
    for arm, expected_pct in (('a',25),('b',75)):
        registry = Path(runtime['registries'][arm])
        recipe = tomllib.loads(registry.read_text())['recipe'][0]
        flags = recipe['serve']['flags']
        row_flag = f'--prefix-cache-row-percent {expected_pct}'
        if recipe['serve']['image'] != cfg['image'] or (arm == 'b' and row_flag not in flags) or (arm == 'a' and any(flag.startswith('--prefix-cache-row-percent') for flag in flags)):
            fail(f'arm {arm} registry differs from plan')
        if '--verify-host-cache-transfers' in flags:
            fail(f'arm {arm} timing registry unexpectedly enables byte audit')
    for name, item in plan['frozen_inputs'].items():
        source = Path(item['source_path'])
        if not source.is_file() or digest(source) != item['sha256']:
            fail(f'frozen source hash mismatch: {name}')
        copy_path = item.get('copy_path')
        if copy_path:
            copied = ROOT / copy_path
            if not copied.is_file() or digest(copied) != item['sha256']:
                fail(f'frozen copy hash mismatch: {name}')
    expected = {'small12':(24,39,1080),'pageheavy':(12,27,780)}
    for lane, values in expected.items():
        spec = bracket['lanes'][lane]
        if (spec['measured_per_arm'],spec['total_per_incarnation'],spec['bounded_phase_seconds_per_incarnation']) != values:
            fail(f'{lane} denominator or time bound changed')
        if sum(x['expected_requests'] for x in spec['measured']) != values[0]:
            fail(f'{lane} measured phase counts do not match')
        if spec['warmup']['expected_requests'] != 3 or spec['prime']['expected_requests'] != 12:
            fail(f'{lane} warmup/prime mismatch')
    c = plan['combined']
    if (c['measured_requests'],c['prime_requests'],c['warmup_requests'],c['all_http_requests']) != (144,96,24,264):
        fail('combined request accounting changed')
    return {'ok':True,'plan_sha256':digest(PLAN_PATH),'prior_runtime_pins_sha256':digest(PRIOR/'runtime-pins.json'),'checks':['schema','ABBA','configuration','registry','frozen_inputs','denominators']}

def command(output_root, cutoff):
    if output_root.exists():
        fail('output root must not already exist')
    if not output_root.is_absolute():
        fail('output root must be absolute')
    if cutoff <= 0:
        fail('request cutoff epoch must be positive')
    plan = load_plan()
    lines = ['# Root owns load/readiness/unload/restoration. These commands are HTTP phases only.',
             '# Create the output root only after lifecycle/readiness evidence is retained.',
             f'# output root: {output_root}', f'# request cutoff epoch: {cutoff:g}']
    for lane in ('small12','pageheavy'):
        spec = plan['timing_bracket']['lanes'][lane]
        for index, arm in enumerate(('a','b','b','a'), start=1):
            run = output_root / lane / f'{index}-{arm}'
            phases = [spec['warmup'], spec['prime'], *spec['measured']]
            for phase in phases:
                label = 'warmup' if phase['lane'] == 'warmup' else (phase['phase'] if phase['iteration'] == 1 else f"{phase['phase']}-{phase['iteration']}")
                output = run / label
                argv = [PYTHON, str(PRIOR/'harness'/'run-phase.py'),'--arm',arm,'--lane',phase['lane'],'--phase',phase['phase'],'--iteration',str(phase['iteration']),'--output',str(output),'--seconds',str(phase['seconds']),'--request-deadline-epoch',str(cutoff)]
                lines.append('env ANVIL_SERVING_HOME=OPERATOR_PATH_601ba1a688c8/operator-home PYTHONPATH='+shlex.quote(WORKTREE)+' '+ ' '.join(shlex.quote(x) for x in argv))
    return '\n'.join(lines)+'\n'

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--check',action='store_true',help='validate plan and frozen files only')
    p.add_argument('--print-commands',action='store_true',help='print, never execute, root-owned HTTP phase commands')
    p.add_argument('--output-root',type=Path)
    p.add_argument('--request-deadline-epoch',type=float)
    args = p.parse_args()
    if args.check == args.print_commands:
        p.error('select exactly one of --check or --print-commands')
    result = validate(load_plan())
    if args.check:
        print(json.dumps(result,sort_keys=True))
    else:
        if args.output_root is None or args.request_deadline_epoch is None:
            p.error('--print-commands requires --output-root and --request-deadline-epoch')
        print(command(args.output_root,args.request_deadline_epoch),end='')
if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, json.JSONDecodeError, tomllib.TOMLDecodeError) as error:
        print(f'ERROR: {error}',file=sys.stderr)
        raise SystemExit(2)
