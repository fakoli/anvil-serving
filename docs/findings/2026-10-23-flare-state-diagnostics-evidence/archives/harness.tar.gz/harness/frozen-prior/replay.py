"""Bounded HTTP fixture using retained cache bodies and drain oracle; no lifecycle."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import time
import urllib.request

ROOT = Path(__file__).parent
PLAN_BYTES = (ROOT / 'prospective.json').read_bytes()
PLAN = json.loads(PLAN_BYTES)
PRIOR = Path(PLAN['original_bodies'][0]['path']).parent.parent
spec = importlib.util.spec_from_file_location('prior_replay', PRIOR / 'cache-replay.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)

def bodies(lane, phase):
    for reference in PLAN['original_bodies']:
        if hashlib.sha256(Path(reference['path']).read_bytes()).hexdigest() != reference['sha256']:
            raise ValueError('retained original body changed')
    original = [json.loads(Path(r['path']).read_bytes()) for r in PLAN['original_bodies']]
    if lane in ('restore-pilot','restore-pressure','warmup'):
        expected_hash = {'restore-pilot':'09cfe0dce98f48d50d8d6b4f6c7ff26ff7290777036ade2d6f1dc496fcfc442f',
                         'restore-pressure':'c5088415cf0c204aca21d12ddc7e11ab605218ce2348c7c535e78a0d81d04409',
                         'warmup':'c3a3571abc8a7b0fbefe2504ea6b2665abfc9ed3e9b6466dc8c78bf56981cf42'}[lane]
        raw = (ROOT/(lane+'-bodies.json')).read_bytes()
        if hashlib.sha256(raw).hexdigest() != expected_hash:
            raise ValueError('restore pilot/pressure corpus changed')
        frozen = json.loads(raw)
        for row in frozen:
            if hashlib.sha256(json.dumps(row['body']).encode()).hexdigest() != row['body_sha256']:
                raise ValueError('restore pilot/pressure body changed')
        rows = [(r['index'],r['body']) for r in frozen]
    elif lane == 'correctness':
        rows = list(enumerate([r['body'] for r in json.loads((ROOT/'oracle-fixtures.json').read_text())['semantic']]))
    elif lane == 'fixed-work':
        raw = Path(PLAN['fixed1_bodies']['path']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != PLAN['fixed1_bodies']['sha256']:
            raise ValueError('fixed1 body changed')
        rows = list(enumerate(json.loads(raw)))
    elif lane in ('pageheavy', 'cold','pageheavy-pilot','cold-pilot'):
        protected_lane = lane.removesuffix('-pilot')
        reference = PLAN[protected_lane]['bodies']
        raw = Path(reference['path']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != reference['sha256']:
            raise ValueError('protected body corpus changed')
        if not lane.endswith('-pilot') and PLAN[protected_lane]['status'] != 'tokenization_and_capacity_verified':
            raise ValueError('protected tokenization/capacity gate unresolved')
        rows = list(enumerate(json.loads(raw)))
    elif lane == 'small12':
        reference = PLAN['fixed1_bodies']
        raw = Path(reference['path']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != reference['sha256']:
            raise ValueError('fixed1 body changed')
        rows = list(enumerate(json.loads(raw)))[-12:]
    elif lane == 'small12-original':
        rows = list(enumerate(original))[-12:]
    elif lane in ('original-forward', 'original-reverse'):
        rows = list(enumerate(original))
    else:
        raise ValueError('lane has no frozen runnable body corpus')
    return rows[::-1] if phase == 'measured' and lane in ('fixed-work','original-reverse') else rows

def request(body, key, deadline, capture, allowed_model_ids=None, body_bytes=None):
    start = time.monotonic_ns()
    row = {'start_ns': start, 'start_epoch_ns': time.time_ns(), 'events': [],
           'output_token_ids': [], 'core_token_timestamps_ns': [], 'request_ids': [], 'finish_reasons': [],
           'message': {'content':'','tool_calls':[]},
           'client_generated_ttft': None, 'visible_ttft': None, 'reasoning_ttft': None}
    try:
        data = body_bytes if body_bytes is not None else json.dumps(body).encode()
        req = urllib.request.Request(prior.BASE + '/v1/chat/completions', data=data,
            headers={'Content-Type':'application/json','Authorization':'Bearer '+key})
        with urllib.request.urlopen(req, timeout=min(60, max(.001, deadline-time.monotonic()))) as response:
            if response.status != 200:
                raise ValueError('non-200 HTTP response')
            size = 0
            stream_socket = getattr(getattr(getattr(response,'fp',None),'raw',None),'_sock',None)
            while time.monotonic() < deadline:
                if stream_socket is not None:
                    stream_socket.settimeout(min(60,max(.001,deadline-time.monotonic())))
                raw = response.readline((1 << 20) + 1)
                arrived = time.monotonic_ns()
                if not raw:
                    break
                size += len(raw)
                if len(raw) > 1 << 20 or size > 8 << 20:
                    raise ValueError('SSE capture bound exceeded')
                if not raw.startswith(b'data:'):
                    continue
                payload = raw[5:].strip()
                if payload == b'[DONE]':
                    row['done'] = True
                    break
                event = json.loads(payload)
                prior.protect(event, key)
                row['events'].append({'client_ns':arrived,'event':event})
                if event.get('model') and event['model'] not in (allowed_model_ids or {body.get('model')}):
                    raise ValueError('SSE model identity mismatch')
                if event.get('error'):
                    raise ValueError('upstream SSE error')
                if event.get('id') and event['id'] not in row['request_ids']:
                    row['request_ids'].append(event['id'])
                if event.get('performance'):
                    row['performance'] = event['performance']
                if event.get('usage'):
                    row['usage'] = event['usage']
                for choice in event.get('choices', []):
                    ids = choice.get('token_ids') or []
                    if ids and row['client_generated_ttft'] is None:
                        row['client_generated_ttft'] = (arrived-start)/1e9
                    row['output_token_ids'].extend(ids)
                    row['core_token_timestamps_ns'].extend(choice.get('token_timestamps_ns') or [])
                    delta = choice.get('delta') or {}
                    row['message']['content'] += delta.get('content') or ''
                    for piece in delta.get('tool_calls') or []:
                        index = piece.get('index', 0)
                        if type(index) is not int or not 0 <= index < 16:
                            raise ValueError('tool index outside bound')
                        calls = row['message']['tool_calls']
                        while len(calls) <= index:
                            calls.append({'id':'','type':'function','function':{'name':'','arguments':''}})
                        call = calls[index]
                        for field in ('id','type'):
                            if piece.get(field): call[field] = piece[field]
                        for field in ('name','arguments'):
                            call['function'][field] += (piece.get('function') or {}).get(field) or ''
                    for field, name in [('content','visible_ttft'),('reasoning_content','reasoning_ttft')]:
                        if delta.get(field) and row[name] is None:
                            row[name] = (arrived-start)/1e9
                    if choice.get('finish_reason'):
                        row['finish_reasons'].append(choice['finish_reason'])
            else:
                raise TimeoutError('request deadline')
        row['e2e'] = (time.monotonic_ns()-start)/1e9
        row['native_first_token_seconds'] = native_first_token(row)
        if not row.get('done') or not row.get('usage') or not row['finish_reasons'] or set(row['finish_reasons']) - ({'stop','length','tool_calls'} if body.get('tools') else {'stop','length'}):
            raise ValueError('terminal/usage/finish contract failed')
        if body.get('max_tokens') == 1 and (len(row['output_token_ids']) != 1
                or row['usage'].get('completion_tokens') != 1 or row['client_generated_ttft'] is None):
            raise ValueError('one-generated-token pilot contract failed')
    except Exception as error:
        row['error'] = str(error) if key not in str(error) else 'protected error omitted'
        raise
    finally:
        prior.protect(row, key)
        prior.write(capture, row)
    return row

def native_first_token(row):
    # Same native ORIGIN: observation::monotonic_ns at HTTP ingress and Incoming::observe_token.
    stamps = row.get('core_token_timestamps_ns') or []
    perf = row.get('performance') or {}
    ingress, enqueue = perf.get('ingress_ns'), perf.get('enqueue_ns')
    if (not stamps or len(stamps) != len(row.get('output_token_ids') or [])
            or not all(type(t) is int for t in [ingress,enqueue,*stamps])
            or not 0 <= ingress <= enqueue <= stamps[0] or stamps != sorted(stamps)):
        return None
    return (stamps[0]-ingress)/1e9

def speculative_delta(before, after):
    prefixes = ('flare_speculative_rounds_total', 'flare_speculative_emitted_tokens_total',
                'flare_speculative_offered_drafts_total', 'flare_speculative_accepted_drafts_total')
    def parse(raw):
        values = {}
        for line in raw.splitlines():
            if line.startswith(prefixes):
                key, value = line.rsplit(' ', 1)
                values[key] = int(value)
        return values
    a, b = parse(before), parse(after)
    if (not a or a.keys() != b.keys() or any(b[k] < a[k] for k in a)
            or any(not any(k.split('{',1)[0] == prefix for k in a) for prefix in prefixes)):
        return None
    support = [{k[len(prefix):] for k in a if k.split('{',1)[0] == prefix} for prefix in prefixes]
    if any(labels != support[0] for labels in support[1:]):
        return None
    delta = {k:b[k]-a[k] for k in a}
    delta['proposed'] = sum(v for k,v in delta.items() if k.startswith('flare_speculative_offered_drafts_total'))
    delta['accepted'] = sum(v for k,v in delta.items() if k.startswith('flare_speculative_accepted_drafts_total'))
    return delta

def proven_source_revision(path, served_alias):
    proof = json.loads(Path(path).read_text())
    verified = proof.get('verified') or {}
    if (proof.get('error') or verified.get('running') is not True
            or verified.get('served_identity') != served_alias
            or verified.get('registry_digest') != proof.get('registry_sha256')
            or verified.get('recipe_digest') != proof.get('recipe_sha256')
            or not verified.get('container_id') or not verified.get('revision')
            or hashlib.sha256(Path(proof['registry']).read_bytes()).hexdigest() != proof.get('registry_sha256')):
        raise ValueError('managed source-revision identity proof invalid')
    return verified['revision']

def run(output, lane, phase, seconds, iteration=1, identity_proof=None):
    rows = bodies(lane, phase)
    output.mkdir(mode=0o700)
    key, identity = prior.read_key(prior.KEY)
    model = rows[0][1]['model']
    identity_request = urllib.request.Request(prior.BASE + '/v1/models', headers={'Authorization':'Bearer '+key})
    with urllib.request.urlopen(identity_request, timeout=5) as response:
        endpoint = json.loads(response.read(1048576))
    prior.protect(endpoint,key)
    prior.write(output/'identity.json',endpoint)
    if [r['id'] for r in endpoint['data']] != [model]:
        raise ValueError('endpoint identity mismatch')
    allowed_models = {model}
    if identity_proof is not None:
        allowed_models.add(proven_source_revision(identity_proof,model))
    attempts = []
    deadline = time.monotonic()+seconds
    prior.write(output/'plan.json', {'lane':lane,'phase':phase,'iteration':iteration,'expected':len(rows),'seconds':seconds,
        'allowed_sse_model_ids':sorted(allowed_models),'identity_proof':str(identity_proof) if identity_proof else None,
        'prospective_sha256':hashlib.sha256(PLAN_BYTES).hexdigest(),'prior_harness_sha256':hashlib.sha256((PRIOR/'cache-replay.py').read_bytes()).hexdigest()})
    for case_id, body in rows:
        attempt = {'case_id':f'{case_id}:{iteration}' if lane in ('small12','small12-original') and phase=='measured' else str(case_id),'iteration':iteration,'phase':phase,'ok':False,
                   'body_sha256':hashlib.sha256(json.dumps(body).encode()).hexdigest()}
        attempts.append(attempt)
        try:
            if deadline-time.monotonic() < 75:
                raise TimeoutError('phase completion reserve reached')
            if prior.read_key(prior.KEY)[1] != identity:
                raise RuntimeError('credential identity changed')
            before_raw, before = prior.idle(key)
            (output/f'{case_id:03}-before.prom').write_text(before_raw)
            result = request(body,key,min(deadline,time.monotonic()+60),output/f'{case_id:03}-response.json',allowed_models)
            prior.protect(result,key)
            prior.write(output/f'{case_id:03}-response.json',result)
            if prior.read_key(prior.KEY)[1] != identity:
                raise RuntimeError('credential identity changed')
            after_raw, after = prior.idle(key)
            (output/f'{case_id:03}-after.prom').write_text(after_raw)
            deltas = {k:after[k]-before[k] for k in prior.COUNTERS}
            if after['flare_uptime_seconds'] < before['flare_uptime_seconds'] or any(v<0 for v in deltas.values()) or deltas['flare_requests_completed_total'] != 1 or any(deltas[k] != 0 for k in ('flare_requests_cancelled_total','flare_host_cache_store_failed_total','flare_host_cache_fetch_failed_total')):
                raise RuntimeError('reset/interference/cache failure')
            if lane == 'correctness':
                from oracles import check
                oracle = json.loads((ROOT/'oracle-fixtures.json').read_text())['semantic'][case_id]
                if not check(oracle['kind'], result['message'], oracle['expected']):
                    raise ValueError('independent correctness oracle failed')
            prompt = result['usage']['prompt_tokens']
            if sum(deltas[k] for k in ('flare_prefill_tokens_total','flare_cache_reused_tokens_total','flare_host_cache_reused_tokens_total')) != prompt:
                raise RuntimeError('prompt accounting mismatch')
            speculative = speculative_delta(before_raw, after_raw)
            reasoning = result['usage'].get('completion_tokens_details', {}).get('reasoning_tokens')
            attempt.update(ok=True,prompt_tokens=prompt,reasoning_tokens=reasoning,speculative_work=speculative,deltas=deltas,**{k:v for k,v in result.items() if k!='events'})
        except Exception as error:
            attempt['error'] = str(error) if key not in str(error) else 'protected error omitted'
            break
        finally:
            prior.write(output/'attempts.json',attempts)
    prior.write(output/'summary.json',{'expected':len(rows),'attempted':len(attempts),
        'completed':sum(a['ok'] for a in attempts),'missing':len(rows)-len(attempts),
        'performance_eligible':False,'semantic_quality':'not_evaluated'})
    return all(a['ok'] for a in attempts) and len(attempts)==len(rows)

if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--lane',choices=['original-forward','original-reverse','small12','small12-original','fixed-work','pageheavy','cold','correctness','pageheavy-pilot','cold-pilot','restore-pilot','restore-pressure','decode-c1','decode-c4','warmup'],required=True)
    p.add_argument('--phase',choices=['prime','measured'],required=True)
    p.add_argument('--seconds',type=int,default=1500)
    p.add_argument('--iteration',type=int,choices=[1,2],default=1)
    p.add_argument('--identity-proof',type=Path)
    a=p.parse_args()
    if not 75 <= a.seconds <= 1800: p.error('seconds must be 75..1800')
    if a.lane in ('decode-c1','decode-c4'):
        from decode import run_decode
        ok=run_decode(a.output,a.lane,a.phase,a.seconds,a.identity_proof)
    else:
        ok=run(a.output,a.lane,a.phase,a.seconds,a.iteration,a.identity_proof)
    raise SystemExit(0 if ok else 1)
