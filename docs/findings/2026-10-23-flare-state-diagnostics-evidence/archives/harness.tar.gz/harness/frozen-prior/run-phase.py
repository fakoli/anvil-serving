"""Bounded measurement fixture: managed status samples around HTTP replay. No lifecycle."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import signal
import shlex
import re
import sys
import time
import tomllib

ROOT = Path(__file__).parent
E = ROOT.parent
WORKTREE = Path('OPERATOR_PATH_cc25b9dd30c4/anvil-serving')
PY = 'OPERATOR_PATH_9ba32d4067f1/python'
IMAGE = 'sha256:b30cadf95cc779cd59bf73c132cb71ace6040e0a5282449c65b5b03b8f12d145'
CONTAINER = 'glm53-flare-cache-fix'
IDENTITY = ('container_id','image_id','started_at','restart_count','model','revision')

def anchor():
    return {'utc':datetime.now(timezone.utc).isoformat(),'epoch_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns()}

def validate(status, recipe, previous=None, expected_image=IMAGE):
    memory = status.get('host_memory') or {}
    events = memory.get('events') or {}
    if (status.get('running') is not True or status.get('restart_count') != 0
            or status.get('container') != CONTAINER or not status.get('container_id')
            or not status.get('started_at') or status.get('image_id') != expected_image
            or status.get('model') != recipe['model']
            or status.get('revision') != recipe['download']['revision']
            or status.get('containment_error') or memory.get('oom_killed') is not False
            or not all(type(events.get(k)) is int and events[k] == 0 for k in ('oom','oom_kill','oom_group_kill'))
            or not all(type(memory.get(k)) is int and memory[k] >= 0 for k in ('current_bytes','peak_bytes','effective_limit_bytes'))
            or memory.get('effective_limit_bytes') != recipe['serve']['memory_limit_mib'] * 1024**2
            or memory['current_bytes'] > memory['effective_limit_bytes']):
        raise RuntimeError('managed identity/containment gate failed')
    if previous and any(status.get(k) != previous.get(k) for k in IDENTITY):
        raise RuntimeError('candidate incarnation changed')
    return status

def select_running(inventory, status, registry_digest, recipe_digest):
    selected = [r for r in inventory.get('containers',[]) if r.get('container_id') == status['container_id']]
    if len(selected) != 1:
        raise RuntimeError('exact status container missing/ambiguous in managed running inventory')
    row = selected[0]
    if (row.get('registry_digest') != registry_digest or row.get('recipe_digest') != recipe_digest
            or row.get('image_digest') != status['image_id'] or row.get('container') != CONTAINER
            or row.get('running') is not True or row.get('started_at') != status['started_at']
            or row.get('model') != status['model'] or row.get('revision') != status['revision']):
        raise RuntimeError('running inventory arm/recipe/identity mismatch')
    return row

def terminate(child):
    if child is not None and child.poll() is None:
        child.terminate()
        try:
            child.wait(timeout=3)
        except subprocess.TimeoutExpired:
            child.kill(); child.wait(timeout=3)

def runtime_config(evidence_root,arm,audit=False):
    path=evidence_root/'runtime-pins.json'
    raw=path.read_bytes() if path.exists() else None
    if raw is None:
        if audit:raise ValueError('audit requires frozen runtime-pins.json')
        return {'image':IMAGE,'registry':evidence_root/f'registry-{arm}.toml',
                'path':path,'bytes':None,'source_patch_sha256':None,'audit':False}
    pins=json.loads(raw)
    if (not isinstance(pins.get('image'),str) or not re.fullmatch(r'sha256:[0-9a-f]{64}',pins['image'])
            or not isinstance(pins.get('source_patch_sha256'),str)
            or not re.fullmatch(r'[0-9a-f]{64}',pins['source_patch_sha256'])):
        raise ValueError('invalid frozen runtime image/source identity')
    for key in ('registries','audit_registries'):
        if not isinstance(pins.get(key),dict) or set(pins[key])!={'a','b'}:
            raise ValueError('frozen runtime requires both arm registry paths')
        if not all(isinstance(value,str) and Path(value).is_absolute() for value in pins[key].values()):
            raise ValueError('runtime registry paths must be absolute')
    return {'image':pins['image'],'registry':Path(pins['audit_registries' if audit else 'registries'][arm]),
            'path':path,'bytes':raw,'source_patch_sha256':pins['source_patch_sha256'],'audit':audit}

def verify_audit_mode(recipe,audit):
    tokens=[token for part in [*recipe['serve'].get('entrypoint',[]),*recipe['serve'].get('flags',[])]
            for token in shlex.split(part)]
    flag='--verify-host-cache-transfers'
    if any(token.startswith(flag+'=') for token in tokens) or tokens.count(flag)!=int(audit):
        raise ValueError('audit flag differs from frozen timing/audit mode')


def main(args):
    runtime=runtime_config(E,args.arm,getattr(args,'audit',False))
    registry=runtime['registry']
    raw = registry.read_bytes()
    recipe = tomllib.loads(raw.decode())['recipe'][0]
    sys.path.insert(0,str(WORKTREE))
    from anvil_serving.serve_recipes import recipe_digest
    expected_recipe_digest = recipe_digest(recipe)
    verify_audit_mode(recipe,runtime['audit'])
    if recipe['serve']['image'] != runtime['image'] or recipe['expected_container'] != CONTAINER:
        raise ValueError('unfrozen registry image/container')
    seconds = min(args.seconds, int(args.request_deadline_epoch - time.time()))
    if not 75 <= seconds <= 1800:
        raise ValueError('phase cannot fit request cutoff and completion reserve')
    args.output.mkdir(mode=0o700)
    env = os.environ.copy()
    env['ANVIL_SERVING_HOME'] = 'OPERATOR_PATH_601ba1a688c8/operator-home'
    env['PYTHONPATH'] = str(WORKTREE)
    status_argv = [PY,'-m','anvil_serving.cli','models','recipes','status',recipe['model'],
        '--container',CONTAINER,'--registry',str(registry),'--json']
    child_argv = [PY,str(ROOT/'replay.py'),'--lane',args.lane,'--phase',args.phase,
        '--iteration',str(args.iteration),'--seconds',str(seconds),'--output',str(args.output/'http'),
        '--identity-proof',str(args.output/'running-proof.json')]
    plan = {'registry':str(registry),'registry_sha256':hashlib.sha256(raw).hexdigest(),
        'runtime_pins':{'path':str(runtime['path']),'bytes_utf8':runtime['bytes'].decode() if runtime['bytes'] is not None else None,
                        'sha256':hashlib.sha256(runtime['bytes']).hexdigest() if runtime['bytes'] is not None else None,
                        'source_patch_sha256':runtime['source_patch_sha256']},
        'expected_image':runtime['image'],'audit':runtime['audit'],
        'arm':args.arm,'status_argv':status_argv,'child_argv':child_argv,
        'request_deadline_epoch':args.request_deadline_epoch,'sample_period_seconds':5,**anchor()}
    (args.output/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    child = None; previous = None; samples = 0; failure = None
    def running_proof():
        argv = [PY,'-m','anvil_serving.cli','models','recipes','running',recipe['model'],
                '--container',CONTAINER,'--json']
        row = {'started':anchor(),'argv':argv,'registry':str(registry),
               'registry_sha256':plan['registry_sha256'],'recipe_sha256':expected_recipe_digest}
        try:
            result = subprocess.run(argv,cwd=WORKTREE,env=env,capture_output=True,text=True,timeout=4)
            row['stdout'] = result.stdout[:2*1024**2]
            envelope = json.loads(row['stdout'])
            if result.returncode or not envelope.get('ok'):
                raise RuntimeError('managed running inventory failed')
            data = envelope['data']
            data = json.loads(data) if isinstance(data,str) else data
            row['inventory'] = data
            proof = select_running(data,previous,plan['registry_sha256'],expected_recipe_digest)
            row['verified'] = proof
            return proof
        except BaseException as error:
            row['error'] = type(error).__name__+': '+str(error)
            raise
        finally:
            row['ended'] = anchor()
            (args.output/'running-proof.json').write_text(json.dumps(row,indent=2)+'\n')
    def sample():
        nonlocal previous, samples
        row = {'index':samples,'started':anchor()}
        try:
            result = subprocess.run(status_argv,cwd=WORKTREE,env=env,capture_output=True,text=True,timeout=4)
            if len(result.stdout) > 2*1024**2:
                raise ValueError('status capture limit')
            row['returncode'] = result.returncode
            row['stdout'] = result.stdout
            row['envelope'] = json.loads(result.stdout)
            if result.returncode or not row['envelope'].get('ok'):
                raise RuntimeError('managed status command failed')
            data = row['envelope']['data']
            status = json.loads(data) if isinstance(data,str) else data
            row['status'] = status
            for line in Path('/proc/meminfo').read_text().splitlines():
                if line.startswith('MemAvailable:'):
                    row['host_mem_available_bytes'] = int(line.split()[1])*1024
            if 'host_mem_available_bytes' not in row:
                raise RuntimeError('host MemAvailable missing')
            if registry.read_bytes() != raw:
                raise RuntimeError('frozen registry changed')
            current_runtime=runtime['path'].read_bytes() if runtime['path'].exists() else None
            if current_runtime!=runtime['bytes']:
                raise RuntimeError('frozen runtime config changed')
            previous = validate(status,recipe,previous,runtime['image'])
        except BaseException as error:
            row['error'] = type(error).__name__+': '+str(error)
            raise
        finally:
            row['ended'] = anchor()
            with (args.output/'status.jsonl').open('a') as stream:
                stream.write(json.dumps(row)+'\n'); stream.flush()
            samples += 1
    previous_handlers = {number:signal.getsignal(number) for number in (signal.SIGINT,signal.SIGTERM)}
    launching = False
    pending_signal = None
    def interrupted(number, _frame):
        nonlocal pending_signal
        if launching:
            pending_signal = number
            return
        raise KeyboardInterrupt(f'signal {number}')
    for number in previous_handlers:
        signal.signal(number,interrupted)
    try:
        initial_sample_start = time.monotonic()
        sample()
        running_proof()
        hard_stop = min(time.monotonic()+seconds, time.monotonic()+args.request_deadline_epoch-time.time())
        with (args.output/'http.log').open('x') as log:
            launching = True
            try:
                child = subprocess.Popen(child_argv,cwd=WORKTREE,env=env,stdout=log,stderr=subprocess.STDOUT)
            finally:
                launching = False
            if pending_signal is not None:
                raise KeyboardInterrupt(f'signal {pending_signal}')
            next_sample = initial_sample_start+5
            while child.poll() is None:
                if time.monotonic() >= hard_stop or time.time() >= args.request_deadline_epoch:
                    raise TimeoutError('parent request cutoff reached')
                if time.monotonic() >= next_sample:
                    sample(); next_sample += 5
                time.sleep(.1)
            sample()
            if child.returncode:
                raise RuntimeError('HTTP replay failed; see retained http evidence')
    except BaseException as error:
        failure = type(error).__name__+': '+str(error)
    finally:
        for number in previous_handlers:
            signal.signal(number,signal.SIG_IGN)
        try:
            terminate(child)
        except Exception as error:
            failure = (failure or '') + ' child cleanup failed: ' + str(error)
        finally:
            for number, handler in previous_handlers.items():
                signal.signal(number,handler)
        summary = {'ok':failure is None,'error':failure,'status_samples':samples,'audit':runtime['audit'],
            'performance_eligible':False,
            'child_returncode':child.returncode if child else None,**anchor()}
        (args.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary))
    return int(failure is not None)

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--arm',choices=['a','b'],required=True)
    parser.add_argument('--audit',action='store_true',help='select only the frozen audit registry; never a timing arm')
    parser.add_argument('--lane',required=True)
    parser.add_argument('--phase',choices=['prime','measured'],required=True)
    parser.add_argument('--iteration',type=int,choices=[1,2],default=1)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--seconds',type=int,default=1500)
    parser.add_argument('--request-deadline-epoch',type=float,required=True)
    raise SystemExit(main(parser.parse_args()))
