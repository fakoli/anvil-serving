"""Offline discriminator checks; never contacts a model."""
import copy
import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location('probe', Path(__file__).with_name('logprob-discriminator.py'))
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


def response(ids):
    entries = [{'token': f'token_id:{i}', 'logprob': -1., 'top_logprobs': [
        {'token': f'token_id:{k}', 'logprob': -float(k+1)} for k in range(20)]} for i in ids]
    return {'output_token_ids': ids, 'usage': {'completion_tokens': len(ids)},
            'events': [{'event': {'choices': [{'logprobs': {'content': entries}}]}}]}


a = response(list(range(8)))
b = response([0, 1, 19, 3, 4, 5, 6, 7])
assert len(probe.compare(a, b)) == 3  # Do not compare different sampled histories.
assert all(r['top20_exact'] for r in probe.compare(a, a))
for fault in ('short', 'usage', 'missing', 'nan', 'duplicate'):
    bad = copy.deepcopy(a)
    entries = bad['events'][0]['event']['choices'][0]['logprobs']['content']
    if fault == 'short':
        bad = response([0])
    elif fault == 'usage':
        bad['usage']['completion_tokens'] = 7
    elif fault == 'missing':
        entries.pop()
    elif fault == 'nan':
        entries[0]['top_logprobs'][0]['logprob'] = float('nan')
    else:
        entries[0]['top_logprobs'][1]['token'] = entries[0]['top_logprobs'][0]['token']
    try:
        probe.distributions(bad)
    except ValueError:
        continue
    raise AssertionError(fault)
print('7 offline logprob checks passed; zero live requests')
