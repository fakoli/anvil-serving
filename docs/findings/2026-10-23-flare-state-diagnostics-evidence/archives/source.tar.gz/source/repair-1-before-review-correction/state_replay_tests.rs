//! Opt-in retained-package state oracle; never used by serving or ordinary tests.
//!
//! FLARE_STATE_TEST_CONFIG names a JSON TestConfig. This test does not prepare or
//! modify a package. The caller owns GPU exclusivity and an outer process timeout.
use super::*;
use crate::{
    execution::{GraphKind, RankExecutor, RankPeers, SamplingMode},
    model::{Admission, Inputs, ModelConfig, PromptData, catalog, pack_inputs},
    scheduler::{RequestHandle, RequestPhase, RequestScheduler, RequestSpec, ScheduledPlan},
};
use sha2::{Digest, Sha256};
use std::{
    io::Read,
    path::PathBuf,
    time::{Duration, Instant},
};

const CHUNK: usize = 16 << 20;

#[derive(serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct TestConfig {
    package: PathBuf,
    publisher_profile: PathBuf,
    accepted_signer: String,
    accepted_namespace: String,
    model_id: String,
    devices: [i32; 2],
    max_concurrency: usize,
    mtp_draft_tokens: usize,
    adaptive_verification: bool,
    tokens_file: PathBuf,
    endpoint: usize,
}

fn json_file<T: serde::de::DeserializeOwned>(path: &std::path::Path, limit: u64) -> T {
    let mut bytes = Vec::new();
    std::fs::File::open(path)
        .unwrap()
        .take(limit + 1)
        .read_to_end(&mut bytes)
        .unwrap();
    assert!(bytes.len() as u64 <= limit, "test input exceeds bound");
    serde_json::from_slice(&bytes).unwrap()
}

#[derive(Clone)]
struct Span {
    name: String,
    address: u64,
    bytes: usize,
}

fn unit(owner: &NativeResources, plane: &crate::offload::Plane, index: u64, capacity: u64) -> Span {
    assert!(index < capacity);
    let address = plane
        .address
        .checked_add(index.checked_mul(plane.unit_bytes).unwrap())
        .unwrap();
    let bytes = usize::try_from(plane.unit_bytes).unwrap();
    let allocation = owner.allocations.get(&plane.name).unwrap();
    assert!(matches!(allocation.memory, Memory::Device));
    assert!(address >= allocation.address);
    assert!(
        address.checked_add(bytes as u64).unwrap()
            <= allocation
                .address
                .checked_add(allocation.nbytes as u64)
                .unwrap()
    );
    Span {
        name: format!("{}[{index}]", plane.name),
        address,
        bytes,
    }
}

fn with_rank_context<T>(owner: &NativeResources, operation: impl FnOnce() -> T) -> T {
    let mut previous = std::ptr::null_mut();
    // SAFETY: these are retained CUDA contexts on this calling thread. Direct
    // rank inspection must not change the thread-bound rank-zero executor's
    // current context, including when a read or poison assertion unwinds.
    unsafe {
        owner
            .driver
            .check("cuCtxGetCurrent", (owner.driver.context_get)(&mut previous))
            .unwrap();
    }
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        unsafe {
            owner
                .driver
                .check("cuCtxSetCurrent", (owner.driver.context_set)(owner.context))
                .unwrap();
        }
        operation()
    }));
    unsafe {
        owner
            .driver
            .check("cuCtxSetCurrent", (owner.driver.context_set)(previous))
            .unwrap();
    }
    match result {
        Ok(value) => value,
        Err(payload) => std::panic::resume_unwind(payload),
    }
}

fn read(owner: &NativeResources, span: &Span, offset: usize, output: &mut [u8]) {
    assert!(offset.checked_add(output.len()).unwrap() <= span.bytes);
    // SAFETY: unit checked owned device allocation containment. All ranks have
    // completed their only frame; owner remains alive throughout this read.
    with_rank_context(owner, || unsafe {
        owner
            .driver
            .check(
                "cuMemcpyDtoH_v2",
                (owner.driver.download)(
                    output.as_mut_ptr().cast(),
                    span.address + offset as u64,
                    output.len(),
                ),
            )
            .unwrap();
    });
}

fn digest(owner: &NativeResources, span: &Span, scratch: &mut [u8]) -> String {
    let mut hash = Sha256::new();
    for offset in (0..span.bytes).step_by(scratch.len()) {
        let n = scratch.len().min(span.bytes - offset);
        read(owner, span, offset, &mut scratch[..n]);
        hash.update(&scratch[..n]);
    }
    format!("{:x}", hash.finalize())
}

fn poison(owner: &NativeResources, span: &Span, scratch: &mut [u8]) {
    // SAFETY: span was checked against the rank's device allocation; scheduler
    // owns this destination exclusively and no frame has yet been submitted.
    with_rank_context(owner, || unsafe {
        owner
            .driver
            .check(
                "cuMemsetD8_v2",
                (owner.driver.zero)(span.address, 0xa5, span.bytes),
            )
            .unwrap();
        owner
            .driver
            .check("cuCtxSynchronize", (owner.driver.context_sync)())
            .unwrap();
    });
    for offset in (0..span.bytes).step_by(scratch.len()) {
        let n = scratch.len().min(span.bytes - offset);
        read(owner, span, offset, &mut scratch[..n]);
        assert!(
            scratch[..n].iter().all(|b| *b == 0xa5),
            "poison failed: {}",
            span.name
        );
    }
}

fn admit(
    scheduler: &mut RequestScheduler,
    config: &ModelConfig,
    tokens: &[u32],
    endpoint: usize,
    admissions: &mut [Option<Admission>],
) -> RequestHandle {
    let handle = scheduler
        .admit(RequestSpec {
            prompt: tokens.to_vec(),
            message_boundaries: vec![endpoint],
            conditioning: vec![],
            max_new_tokens: 1,
            grammar_constrained: false,
            host_stops: false,
            growable_output: false,
        })
        .unwrap();
    let admission = Admission {
        handle,
        sampling: config.sampling_defaults.clone(),
        max_new_tokens: 1,
        prompt: tokens.to_vec(),
        data: PromptData::default(),
        grammar_mask: None,
        ignore_eos: false,
    };
    admission.validate(config).unwrap();
    admissions[handle.slot as usize] = Some(admission);
    handle
}

// commit happens separately so poisoned destinations have their real reserved pages.
fn execute(
    executor: &mut RankExecutor,
    scheduler: &mut RequestScheduler,
    inputs: &mut Inputs,
    config: &ModelConfig,
    plan: &ScheduledPlan,
    admissions: &[Option<Admission>],
) {
    assert_eq!(
        crate::cuda::current_context().unwrap().0,
        executor.manifest().context,
        "direct state inspection changed the executor thread's CUDA context"
    );
    let fence = executor.next_fence().unwrap();
    pack_inputs(inputs, config, scheduler, plan, admissions).unwrap();
    let graph = catalog::select_shape(
        config,
        executor.manifest(),
        plan.kind,
        plan.batch_capacity,
        plan.token_capacity,
        plan.prefill_capacity(),
        plan.packed_token_capacity,
        SamplingMode::General,
    )
    .unwrap();
    assert_eq!(
        executor.submit(graph, &inputs.uploads(), false).unwrap(),
        Some(fence)
    );
    let deadline = Instant::now() + Duration::from_secs(120);
    let completion = loop {
        if let Some(completion) = executor.poll().unwrap() {
            break completion;
        }
        assert!(
            Instant::now() < deadline,
            "state replay fence deadline exceeded"
        );
        std::thread::sleep(Duration::from_millis(1));
    };
    assert_eq!(completion.fence, fence);
    assert_eq!(executor.outstanding(), 0);
    for lane in &plan.lanes {
        let record = &completion.records[lane.request.slot as usize];
        assert_eq!(record.status, 1, "native operation failed: {record:?}");
        assert_eq!(record.generated_tokens, 0, "prefix oracle must not sample");
    }
    assert!(
        scheduler
            .complete(fence, &completion.records, completion.timing)
            .unwrap()
            .is_empty()
    );
    println!(
        "{}",
        serde_json::json!({"operation": format!("{:?}", plan.kind),
        "fence": fence.0, "graph": executor.manifest().graphs[graph].name})
    );
}

#[test]
#[ignore = "requires FLARE_STATE_TEST_CONFIG, authorized retained TP2 package and exclusive assigned GPUs"]
fn retained_tp2_snapshot_restore_snapshot_exact() {
    let test: TestConfig = json_file(
        &PathBuf::from(
            std::env::var_os("FLARE_STATE_TEST_CONFIG")
                .expect("FLARE_STATE_TEST_CONFIG is required"),
        ),
        65536,
    );
    // Match Flare's public profile-list format, including an already accepted
    // local-development signer. Never use test_support's fixture key or infer
    // acceptance from an unverified package claim.
    let publishers: Vec<Publisher> = json_file(&test.publisher_profile, 65536);
    for publisher in &publishers {
        publisher.validate().unwrap();
    }
    assert!(test.devices[0] >= 0 && test.devices[1] >= 0 && test.devices[0] != test.devices[1]);
    let tokens: Vec<u32> = json_file(&test.tokens_file, 1 << 20);
    assert!((2..=16384).contains(&tokens.len()));
    assert!(test.endpoint > 0 && test.endpoint < tokens.len());
    // Only the prefix and one following token are needed; never execute the latter.
    let tokens = &tokens[..test.endpoint + 1];
    let verified = VerifiedPackage::open(&test.package, &publishers, None).unwrap();
    assert_eq!(verified.publisher().fingerprint(), test.accepted_signer);
    assert_eq!(verified.publisher().namespace, test.accepted_namespace);
    assert_eq!(verified.index.ranks.len(), 2);
    assert!(verified.index.cluster.is_none());
    let contract = verified.index.contract.as_ref().unwrap();
    assert_eq!(contract.model_id, test.model_id);
    let model_contract = contract.model_contract.as_ref().unwrap();
    let options = LoadOptions {
        max_concurrency: Some(test.max_concurrency),
        mtp_draft_tokens: Some(test.mtp_draft_tokens),
        adaptive_verification: Some(test.adaptive_verification),
        memory_limit: Some(MemoryLimit::Reserve(2 << 30)),
        ..Default::default()
    };
    // Ask the same selector used by NativeModel which captured graphs survive;
    // computing rows from the unselected catalog would test a different layout.
    let mut selected_packages = verified
        .index
        .ranks
        .iter()
        .cloned()
        .map(protobuf::decode)
        .collect::<Result<Vec<_>>>()
        .unwrap();
    let mut selected_config = protobuf::serving_contract(
        contract.clone(),
        selected_packages[0].execution.as_ref().unwrap().max_active,
    )
    .unwrap();
    let active = options
        .select(&mut selected_packages, &mut selected_config)
        .unwrap() as u64;
    let width = model_contract
        .graphs
        .iter()
        .filter(|g| {
            selected_packages[0]
                .execution
                .as_ref()
                .unwrap()
                .graphs
                .iter()
                .any(|selected| selected.name == g.graph)
        })
        .map(|g| g.state_rows_per_request)
        .max()
        .unwrap();
    drop(selected_packages);
    assert!((2..=64).contains(&active) && (1..=8).contains(&width));
    let wanted_rows = 1 + active * width + 4;
    // 1,024 logical pages is ample for this <=16K-token C1 prefix plus four
    // snapshot aliases in this retained model. Loader validates physical fit.
    let wanted_pages = 1024;
    let authorized = verified.authorize(&test.accepted_namespace, true).unwrap();
    let mut agree = |(rows, pages)| -> Result<_> {
        if rows < wanted_rows || pages < wanted_pages {
            return Err("insufficient diagnostic cache capacity".into());
        }
        Ok((wanted_rows, wanted_pages))
    };
    // SAFETY: normal signature, authorization and stored-data checks precede
    // loading; no graph binding or package bytes are changed by this test.
    let owner = unsafe {
        NativeModel::load_agreeing(
            authorized,
            &test.devices,
            &options,
            &StartupProgress::silent(),
            &mut agree,
        )
        .unwrap()
    };
    let mut manifests = owner.manifests().unwrap();
    let config = crate::server::Bootstrap::load(&owner.server_config().to_string(), &manifests[0])
        .unwrap()
        .model;
    assert_eq!(config.model_id, test.model_id);
    let geometry: Vec<_> = manifests.iter().map(|m| m.cache.clone().unwrap()).collect();
    for g in &geometry {
        g.validate().unwrap();
        assert_eq!(g.page_tokens as usize, config.contract.cache.page_tokens);
        assert_eq!(g.row_capacity, wanted_rows);
        assert_eq!(g.page_capacity, wanted_pages);
        assert!(g.row.unit_bytes <= 256 << 20);
    }
    let first = manifests.remove(0);
    let mut scheduler = RequestScheduler::new(
        config.identity,
        config.limits,
        crate::model::scheduler_capabilities(&config),
    )
    .unwrap();
    scheduler.graph_durations(&first.graphs).unwrap();
    scheduler
        .share_snapshot_pages(&geometry[0].snapshot_pages)
        .unwrap();
    scheduler
        .enable_speculation(&config.speculative_widths)
        .unwrap();
    scheduler
        .proposal_source(config.speculative_proposal_source)
        .unwrap();
    scheduler
        .fixed_speculative_width(config.speculative_fixed_width)
        .unwrap();
    scheduler
        .prefill_graphs(
            &first
                .graphs
                .iter()
                .filter(|g| g.kind == GraphKind::Prefill)
                .map(|g| g.token_capacity)
                .collect::<Vec<_>>(),
        )
        .unwrap();
    let mut inputs = Inputs::new(&config, &first).unwrap();
    // SAFETY: owner remains retained through close, including every panic path.
    let mut executor =
        unsafe { RankExecutor::new(first, Some(RankPeers::Threads(manifests))).unwrap() };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let mut scratch = vec![0; CHUNK];
        let mut actual = vec![0; CHUNK];
        let mut admissions: Vec<_> = (0..config.limits.request_capacity())
            .map(|_| None)
            .collect();
        let source = admit(
            &mut scheduler,
            &config,
            tokens,
            test.endpoint,
            &mut admissions,
        );
        for _ in 0..260 {
            let phase = scheduler.request(source).unwrap().phase;
            let kind = match phase {
                RequestPhase::Initialize => GraphKind::Init,
                RequestPhase::Prefill => GraphKind::Prefill,
                RequestPhase::Snapshot => GraphKind::Snapshot,
                _ => panic!("unexpected source phase {phase:?}"),
            };
            let plan = scheduler.phase_plan(kind, Some(source));
            assert!(
                plan.lanes
                    .iter()
                    .all(|l| l.start_position + l.tokens as u64 <= test.endpoint as u64)
            );
            scheduler
                .commit(&plan, executor.next_fence().unwrap())
                .unwrap();
            execute(
                &mut executor,
                &mut scheduler,
                &mut inputs,
                &config,
                &plan,
                &admissions,
            );
            if kind == GraphKind::Snapshot {
                break;
            }
        }
        let original = scheduler.request(source).unwrap();
        assert_eq!(original.consumed_tokens, test.endpoint as u64);
        let source_row = scheduler
            .snapshot_slot(
                original
                    .prefix_snapshot()
                    .expect("published boundary required"),
            )
            .0;
        let source_live = original.state_slot.0;
        let source_pages: Vec<_> = original.pages().map(|p| p.0).collect();
        let guards: Vec<_> = owner
            .ranks
            .iter()
            .zip(&geometry)
            .map(|(rank, g)| {
                let mut spans = vec![
                    unit(rank, &g.row, source_row as u64, g.row_capacity),
                    unit(rank, &g.row, 0, g.row_capacity),
                ];
                for row in source_live..source_live + scheduler.execution_rows() as u32 {
                    spans.push(unit(rank, &g.row, row as u64, g.row_capacity));
                }
                for page in &source_pages {
                    for plane in &g.planes {
                        spans.push(unit(rank, plane, *page as u64, g.page_capacity));
                    }
                }
                spans
                    .into_iter()
                    .map(|s| {
                        let hash = digest(rank, &s, &mut scratch);
                        (s, hash)
                    })
                    .collect::<Vec<_>>()
            })
            .collect();
        let target = admit(
            &mut scheduler,
            &config,
            tokens,
            test.endpoint,
            &mut admissions,
        );
        assert_eq!(
            scheduler.request(target).unwrap().phase,
            RequestPhase::Restore
        );
        assert_eq!(
            scheduler.request(target).unwrap().consumed_tokens,
            test.endpoint as u64
        );
        assert_ne!(scheduler.request(target).unwrap().state_slot.0, source_live);
        let restore = scheduler.phase_plan(GraphKind::Restore, Some(target));
        scheduler
            .commit(&restore, executor.next_fence().unwrap())
            .unwrap();
        let target_live = scheduler.request(target).unwrap().state_slot.0;
        let target_pages: Vec<_> = scheduler
            .request(target)
            .unwrap()
            .pages()
            .map(|p| p.0)
            .collect();
        let complete = test.endpoint / config.contract.cache.page_tokens;
        // Complete target pages intentionally share immutable source pages by
        // logical position. Partial and draft pages are privately allocated.
        assert_eq!(&source_pages[..complete], &target_pages[..complete]);
        assert!(
            target_pages[complete..]
                .iter()
                .all(|p| !source_pages.contains(p))
        );
        for (rank, g) in owner.ranks.iter().zip(&geometry) {
            poison(
                rank,
                &unit(rank, &g.row, target_live as u64, g.row_capacity),
                &mut scratch,
            );
            for page in &target_pages[complete..] {
                for plane in &g.planes {
                    poison(
                        rank,
                        &unit(rank, plane, *page as u64, g.page_capacity),
                        &mut scratch,
                    );
                }
            }
        }
        execute(
            &mut executor,
            &mut scheduler,
            &mut inputs,
            &config,
            &restore,
            &admissions,
        );
        let snapshot = scheduler.state_replay_snapshot(target).unwrap();
        let target_row = scheduler
            .snapshot_slot(scheduler.request(target).unwrap().snapshot_destination())
            .0;
        assert_ne!(source_row, target_row);
        scheduler
            .commit(&snapshot, executor.next_fence().unwrap())
            .unwrap();
        for (rank, g) in owner.ranks.iter().zip(&geometry) {
            poison(
                rank,
                &unit(rank, &g.row, target_row as u64, g.row_capacity),
                &mut scratch,
            );
        }
        execute(
            &mut executor,
            &mut scheduler,
            &mut inputs,
            &config,
            &snapshot,
            &admissions,
        );
        for (index, (rank, g)) in owner.ranks.iter().zip(&geometry).enumerate() {
            let a = unit(rank, &g.row, source_row as u64, g.row_capacity);
            let b = unit(rank, &g.row, target_row as u64, g.row_capacity);
            for offset in (0..a.bytes).step_by(CHUNK) {
                let n = CHUNK.min(a.bytes - offset);
                read(rank, &a, offset, &mut scratch[..n]);
                read(rank, &b, offset, &mut actual[..n]);
                if let Some(delta) = scratch[..n]
                    .iter()
                    .zip(&actual[..n])
                    .position(|(a, b)| a != b)
                {
                    panic!(
                        "canonical snapshot mismatch: rank={index} byte={} expected={} actual={}",
                        offset + delta,
                        scratch[delta],
                        actual[delta]
                    );
                }
            }
            for (span, before) in &guards[index] {
                assert_eq!(
                    &digest(rank, span, &mut scratch),
                    before,
                    "source/sentinel changed: rank={index} {}",
                    span.name
                );
            }
            println!(
                "{}",
                serde_json::json!({"rank": index, "endpoint": test.endpoint,
                "page_tokens": g.page_tokens, "source_row": source_row, "target_row": target_row,
                "source_live_row": source_live, "target_live_row": target_live,
                "source_pages": source_pages, "target_pages": target_pages,
                "exact_snapshot_bytes": a.bytes, "snapshot_sha256": digest(rank, &a, &mut scratch),
                "guarded_spans": guards[index].len(), "source_guards_unchanged": true,
                "poison_verified": true, "canonical_snapshot_equal": true})
            );
        }
    }));
    let context_before_close = crate::cuda::current_context();
    let executor_context = executor.manifest().context;
    let shutdown = executor.close();
    if !shutdown.drained {
        // Never free CUDA owners after unconfirmed drain, even during unwinding.
        std::mem::forget(executor);
        std::mem::forget(owner);
        panic!("unconfirmed TP2 drain: {:?}", shutdown.error);
    }
    scheduler.release_after_shutdown(&shutdown).unwrap();
    assert_eq!(context_before_close.unwrap().0, executor_context);
    assert_eq!(scheduler.stats().active_requests, 0);
    assert!(shutdown.error.is_none(), "{:?}", shutdown.error);
    if let Err(payload) = result {
        std::panic::resume_unwind(payload);
    }
    println!(
        "{}",
        serde_json::json!({"drained": true, "active_requests": 0,
        "sampling_exercised": false, "host_offload_exercised": false})
    );
}
