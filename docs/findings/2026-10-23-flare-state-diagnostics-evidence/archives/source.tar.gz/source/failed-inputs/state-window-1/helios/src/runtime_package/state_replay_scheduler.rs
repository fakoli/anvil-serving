//! Test-only reservation for an immediate canonical re-snapshot after Restore.
use super::*;

impl RequestScheduler {
    pub(crate) fn state_replay_snapshot(&mut self, handle: RequestHandle) -> Result<ScheduledPlan> {
        let request = self.request(handle)?;
        if !self.submissions.is_empty()
            || request.pending != 0
            || request.last_use > self.completed
            || request.phase != RequestPhase::Prefill
            || request.consumed_tokens == 0
            || request.consumed_tokens != request.prefix_tokens
            || request.generated_tokens != 0
            || request.prefix_snapshot.is_none()
            || request.boundary_capture.is_some()
            || request.terminal_snapshot.is_some()
        {
            return Err(
                "state replay requires a quiescent restored prefix before further prefill".into(),
            );
        }
        // Use the allocator, including exclusion of KV pages aliasing this row.
        // Cancellation releases this unpublished terminal row through normal retirement.
        let snapshot = self
            .retain_snapshot()?
            .ok_or("no diagnostic snapshot capacity")?;
        let request = self.request_mut(handle)?;
        request.terminal_snapshot = Some(snapshot);
        request.phase = RequestPhase::Snapshot;
        Ok(self.phase_plan(GraphKind::Snapshot, Some(handle)))
    }
}
