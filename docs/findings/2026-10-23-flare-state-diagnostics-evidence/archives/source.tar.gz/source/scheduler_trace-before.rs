//! Bounded headless access to the same opt-in telemetry as the terminal dashboard.

use std::{
    collections::VecDeque,
    sync::Arc,
    time::{Duration, SystemTime, UNIX_EPOCH},
};

use axum::{
    Json,
    extract::DefaultBodyLimit,
    http::{HeaderMap, StatusCode},
    response::IntoResponse,
    routing::{MethodRouter, post},
};
use serde::Deserialize;
use serde_json::{Value, json};

use super::{
    constant_time_eq, error,
    metrics::{
        Metrics,
        scheduler::{SchedulerMetrics, TRACE_CAPACITY},
    },
    observation::monotonic_ns,
};

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Options {
    duration_ms: u64,
}

pub(super) fn route<S: Clone + Send + Sync + 'static>(
    metrics: Arc<Metrics>,
    key: Option<String>,
) -> MethodRouter<S> {
    let key = Arc::new(key);
    post(move |headers: HeaderMap, Json(options): Json<Options>| {
        let metrics = metrics.clone();
        let key = key.clone();
        async move {
            let Some(key) = key.as_ref() else {
                return error(
                    StatusCode::FORBIDDEN,
                    "scheduler tracing requires a configured serving API key",
                );
            };
            if !headers
                .get("authorization")
                .and_then(|h| h.as_bytes().strip_prefix(b"Bearer "))
                .is_some_and(|value| constant_time_eq(value, key.as_bytes()))
            {
                return error(StatusCode::UNAUTHORIZED, "missing or invalid API key");
            }
            match collect(&metrics.scheduler_trace, options).await {
                Ok(value) => Json(value).into_response(),
                Err((status, message)) => error(status, message),
            }
        }
    })
    .layer(DefaultBodyLimit::max(1024))
}

fn clock_anchor() -> Value {
    let before_ns = monotonic_ns();
    let unix_ns = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .ok()
        .and_then(|d| u64::try_from(d.as_nanos()).ok());
    json!({"before_ns": before_ns, "unix_ns": unix_ns, "after_ns": monotonic_ns()})
}

async fn collect(
    metrics: &SchedulerMetrics,
    options: Options,
) -> Result<Value, (StatusCode, &'static str)> {
    if !(1..=30_000).contains(&options.duration_ms) {
        return Err((StatusCode::BAD_REQUEST, "duration_ms must be in 1..=30000"));
    }
    let capture = metrics.start().ok_or((
        StatusCode::CONFLICT,
        "scheduler trace is in use by another capture or the terminal dashboard",
    ))?;
    let started_ns = monotonic_ns();
    let start_anchor = clock_anchor();
    tokio::time::sleep(Duration::from_millis(options.duration_ms)).await;
    let mut samples = VecDeque::with_capacity(TRACE_CAPACITY);
    let epoch = capture.epoch;
    let (ended_ns, dropped) = capture.finish(&mut samples).ok_or((
        StatusCode::INTERNAL_SERVER_ERROR,
        "scheduler trace ownership was lost",
    ))?;
    let end_anchor = clock_anchor();
    let retained = samples.len();
    samples.retain(|s| (started_ns..=ended_ns).contains(&s.at_ns));
    let excluded = retained - samples.len();
    let graph_ids: std::collections::BTreeSet<_> = samples.iter().map(|s| s.graph).collect();
    let graphs: Vec<_> = metrics
        .catalog
        .get()
        .into_iter()
        .flatten()
        .enumerate()
        .filter(|(index, _)| graph_ids.contains(index))
        .map(|(index, g)| {
            json!({
                "index": index, "name": g.name.chars().take(256).collect::<String>(),
                "name_truncated": g.name.chars().count() > 256, "kind": format!("{:?}", g.kind),
                "batch_capacity": g.batch, "token_capacity": g.tokens,
                "prefill_capacity": g.prefill, "packed_token_capacity": g.packed,
            })
        })
        .collect();
    let samples: Vec<_> = samples.iter().map(|s| {
        let requests: Vec<_> = s.generations.iter().enumerate().filter(|(_, generation)| **generation != 0)
            .map(|(slot, generation)| json!({"slot": slot, "generation": generation})).collect();
        json!({
            "observed_ns": s.at_ns, "fence": s.fence.0, "graph": s.graph,
            "rank_gpu_ns": s.rank_gpu_ns.iter().enumerate().filter_map(|(rank, ns)|
                ns.map(|ns| json!({"rank": rank, "gpu_ns": ns}))).collect::<Vec<_>>(),
            "max_rank_gpu_ns": s.gpu_ns,
            "wall_ns": s.wall_ns, "queued": s.queued, "requests": requests,
            "selection": {
                "selected_at_ns": s.selection.selected_at_ns, "commit_ns": s.selection.commit_ns,
                "retained_ns": s.selection.retained_ns, "observed_at_ns": s.selection.observed_at_ns,
                "freshness": format!("{:?}", s.selection.freshness), "origin": format!("{:?}", s.selection.origin),
                "refresh_episode": s.selection.refresh_episode, "credit_ns": s.selection.credit_ns,
            },
            "credit_after_ns": s.credit_after_ns,
        })
    }).collect();
    Ok(json!({
        "schema": "flare.scheduler-trace/v1", "epoch": epoch,
        "clock": "process_monotonic_ns", "started_ns": started_ns, "ended_ns": ended_ns,
        "clock_anchors": [start_anchor, end_anchor], "excluded_boundary_samples": excluded,
        "requested_duration_ms": options.duration_ms, "capacity": TRACE_CAPACITY,
        "dropped_updates": dropped, "graphs": graphs, "samples": samples,
    }))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        cache::Fence,
        execution::{ExecutionTiming, GraphKind},
        scheduler::{RequestHandle, ScheduledLane, ScheduledStep, SubmittedTiming},
    };

    #[tokio::test]
    async fn http_requires_authentication_and_bounds_the_capture_request() {
        use std::io::{Read, Write};
        for key in [None, Some("test-only-key".to_owned())] {
            let metrics = Arc::new(Metrics::default());
            let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let address = listener.local_addr().unwrap();
            let app = axum::Router::new()
                .route(
                    "/debug/scheduler-trace",
                    route(metrics.clone(), key.clone()),
                )
                .route_layer(axum::middleware::from_fn_with_state(
                    Arc::new(key.clone()),
                    super::super::authorize,
                ))
                .layer(DefaultBodyLimit::max(32 * 1024 * 1024));
            let server = tokio::spawn(async move {
                axum::serve(listener, app).await.unwrap();
            });
            let cases = if key.is_none() {
                vec![(
                    "Bearer test-only-key",
                    r#"{"duration_ms":1}"#.to_owned(),
                    403,
                )]
            } else {
                vec![
                    ("", r#"{"duration_ms":1}"#.to_owned(), 401),
                    ("Bearer wrong", r#"{"duration_ms":1}"#.to_owned(), 401),
                    ("Bearer wrong", " ".repeat(1025), 401),
                    (
                        "Bearer test-only-key",
                        r#"{"duration_ms":1}"#.to_owned(),
                        409,
                    ),
                    (
                        "Bearer test-only-key",
                        r#"{"duration_ms":1}"#.to_owned(),
                        200,
                    ),
                    (
                        "Bearer test-only-key",
                        r#"{"duration_ms":0}"#.to_owned(),
                        400,
                    ),
                    (
                        "Bearer test-only-key",
                        r#"{"duration_ms":30001}"#.to_owned(),
                        400,
                    ),
                    (
                        "Bearer test-only-key",
                        r#"{"duration_ms":1,"extra":1}"#.to_owned(),
                        422,
                    ),
                    ("Bearer test-only-key", "{".to_owned(), 400),
                    ("Bearer test-only-key", " ".repeat(1025), 413),
                ]
            };
            for (auth, body, expected) in cases {
                let lease = (expected == 409).then(|| metrics.scheduler_trace.start().unwrap());
                let response = tokio::task::spawn_blocking(move || {
                    let mut stream = std::net::TcpStream::connect_timeout(&address, Duration::from_secs(5)).unwrap();
                    stream.set_read_timeout(Some(Duration::from_secs(5))).unwrap();
                    stream.set_write_timeout(Some(Duration::from_secs(5))).unwrap();
                    write!(stream, "POST /debug/scheduler-trace HTTP/1.1\r\nHost: 127.0.0.1\r\nAuthorization: {auth}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len()).unwrap();
                    let mut response = String::new();
                    stream.take(2 * 1024 * 1024).read_to_string(&mut response).unwrap();
                    response
                }).await.unwrap();
                assert!(
                    response.starts_with(&format!("HTTP/1.1 {expected} ")),
                    "{response}"
                );
                drop(lease);
                assert!(metrics.scheduler_trace.start().is_some());
            }
            server.abort();
            let _ = server.await;
        }
    }

    #[tokio::test]
    async fn bounded_capture_preserves_rank_timing_and_releases_ownership() {
        let metrics = SchedulerMetrics::default();
        assert!(collect(&metrics, Options { duration_ms: 0 }).await.is_err());
        assert!(
            collect(
                &metrics,
                Options {
                    duration_ms: 30_001
                }
            )
            .await
            .is_err()
        );
        for body in [
            "{}",
            r#"{"duration_ms":-1}"#,
            r#"{"duration_ms":true}"#,
            r#"{"duration_ms":1,"extra":0}"#,
        ] {
            assert!(serde_json::from_str::<Options>(body).is_err());
        }
        let capture = collect(&metrics, Options { duration_ms: 1 });
        let writer = async {
            // collect is polled first by join, so its exclusive reader is active here.
            assert_eq!(
                collect(&metrics, Options { duration_ms: 1 })
                    .await
                    .unwrap_err()
                    .0,
                StatusCode::CONFLICT
            );
            let step = ScheduledStep {
                packed_token_capacity: 0,
                kind: GraphKind::Decode,
                batch_capacity: 1,
                token_capacity: 1,
                mixed: None,
                requires_feedback: false,
                lanes: vec![ScheduledLane {
                    request: RequestHandle {
                        slot: 7,
                        generation: 11,
                    },
                    start_position: 20,
                    tokens: 1,
                }],
            };
            let mut timing = ExecutionTiming {
                wall_ns: 50,
                ..Default::default()
            };
            timing.gpu_ns[0] = Some(10);
            timing.gpu_ns[1] = Some(20);
            for fence in 0..TRACE_CAPACITY + 3 {
                metrics.completed(
                    monotonic_ns(),
                    Fence(fence as u64),
                    0,
                    &step,
                    timing,
                    SubmittedTiming::default(),
                    0.0,
                );
            }
        };
        let (result, ()) = tokio::join!(biased; capture, writer);
        let value = result.unwrap();
        assert_eq!(value["samples"].as_array().unwrap().len(), TRACE_CAPACITY);
        assert_eq!(value["dropped_updates"], 3);
        let sample = &value["samples"][0];
        assert_eq!(sample["fence"], 3);
        assert_eq!(
            sample["rank_gpu_ns"],
            json!([{"rank":0,"gpu_ns":10},{"rank":1,"gpu_ns":20}])
        );
        assert_eq!(sample["max_rank_gpu_ns"], 20);
        assert_eq!(sample["wall_ns"], 50);
        assert_eq!(sample["requests"], json!([{"slot":7,"generation":11}]));
        let again = collect(&metrics, Options { duration_ms: 1 }).await.unwrap();
        assert!(again["samples"].as_array().unwrap().is_empty());
        assert_eq!(again["dropped_updates"], 0);

        let mut abandoned = Box::pin(collect(
            &metrics,
            Options {
                duration_ms: 30_000,
            },
        ));
        assert!(futures_util::poll!(&mut abandoned).is_pending());
        assert!(metrics.start().is_none());
        drop(abandoned);
        let lease = metrics.start().unwrap();
        let mut samples = VecDeque::with_capacity(TRACE_CAPACITY);
        assert!(lease.finish(&mut samples).is_some());
        let current = metrics.start().unwrap();
        assert!(metrics.start().is_none());
        drop(current);
        assert!(metrics.start().is_some());
    }

    #[tokio::test]
    async fn graph_catalog_uses_only_returned_completions_and_bounds_names() {
        use super::super::metrics::scheduler::GraphLabel;
        let metrics = SchedulerMetrics::default();
        metrics
            .catalog
            .set(
                vec![0, 1]
                    .into_iter()
                    .map(|index| GraphLabel {
                        name: if index == 0 {
                            "g".repeat(300)
                        } else {
                            "outside_window".into()
                        },
                        kind: GraphKind::Decode,
                        batch: 1,
                        tokens: 1,
                        prefill: 0,
                        packed: 0,
                    })
                    .collect(),
            )
            .ok()
            .unwrap();
        // Ensure zero predates this capture even when it is the first test run.
        monotonic_ns();
        tokio::time::sleep(Duration::from_millis(1)).await;
        let capture = collect(&metrics, Options { duration_ms: 1 });
        let writer = async {
            let step = ScheduledStep {
                packed_token_capacity: 0,
                kind: GraphKind::Decode,
                batch_capacity: 1,
                token_capacity: 1,
                mixed: None,
                requires_feedback: false,
                lanes: vec![],
            };
            for (at_ns, graph) in [(0, 1), (monotonic_ns(), 0)] {
                metrics.completed(
                    at_ns,
                    Fence(1),
                    graph,
                    &step,
                    ExecutionTiming::default(),
                    SubmittedTiming::default(),
                    0.0,
                );
            }
        };
        let (result, ()) = tokio::join!(biased; capture, writer);
        let value = result.unwrap();
        assert_eq!(value["excluded_boundary_samples"], 1);
        assert_eq!(value["samples"].as_array().unwrap().len(), 1);
        assert_eq!(value["graphs"].as_array().unwrap().len(), 1);
        assert_eq!(value["graphs"][0]["index"], 0);
        assert_eq!(value["graphs"][0]["name"].as_str().unwrap().len(), 256);
        assert_eq!(value["graphs"][0]["name_truncated"], true);
    }
}
