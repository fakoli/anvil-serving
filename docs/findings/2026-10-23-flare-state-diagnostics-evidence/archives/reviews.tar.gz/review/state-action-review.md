# Independent state-action review

```json
{
  "schema_version": "operator-workflow/v1",
  "request": "Adversarial read-only review of the bounded native state oracle plus separate HTTP top-20 diagnostic action before execution.",
  "gate_state": "go",
  "targets": [
    "OPERATOR_PATH_93f9c8deff2b/state-tool-action.json",
    "OPERATOR_PATH_7178802bba9e/state-input-bindings.json"
  ],
  "tools_used": ["read-only file inspection", "sha256-bound source review", "static breakage probes"],
  "artifacts": {
    "reviewed_action_file_sha256": "fbbfea0e584b4826a2556a96016ef79a3f976f577b653ea80ecb3a26a2f42351",
    "reviewed_embedded_action_sha256": "3a57b04f9a8b78b8038b66936570ff88d1e7132ddbd926f064bea6f6867f414d",
    "reviewed_binding_sha256": "386b1207c42866225ec4bc90febc753e5b923b07bbae3165bea80c9760bdc8cd",
    "findings_summary": "No blocking ownership, deadline, oracle, or recovery defect in these exact bytes. The action may run once under the existing human-authorized diagnostic window. It remains diagnostic-only and cannot clear the historical exact-128 gate."
  },
  "advisory_priors": [
    "The implementing/orchestrating model is GPT-6 Astra; this independent reviewer is GPT-5.6 Sol high. The evaluated model is the retained GLM Flare package, not the reviewer.",
    "The native state implementation separately passed source review and compile-only validation; this review does not re-grade that implementation.",
    "The protected HTTP timing action is a separate transaction and does not establish this action's result."
  ],
  "recommendation": "go",
  "human_gate_required": false,
  "promoted": false
}
```

## Findings

No blocking finding.

The action binds 17 inputs before the outage and again after the native phase and after the HTTP phase. The three configs select the reviewed signed package and public verification profile, devices 0/1, concurrency 4, MTP width 2, adaptive verification disabled, and endpoints 512, 513, and 7708. The native command uses argv arrays, a 600-second GNU `timeout`, TERM followed by KILL after 10 seconds, a 630-second parent ceiling, stop-on-first-failure, and an all-GPU compute-process emptiness check before and after every normally returned endpoint. The final endpoint's empty-GPU gate precedes candidate load.

The declared HTTP count is consistent with the frozen fixtures: `warmup-bodies.json` contains three requests and `logprob-discriminator.py` sends four requests. The latter remains a top-20 sampled-distribution diagnostic; it is neither a full-logit oracle nor a repair of the historical exact-128 identity failure.

The recovery path preserves the accepted repair-2 properties: quiesce and stop intent are recorded before dispatch, candidate cleanup catches `BaseException`, retained incumbent identity is reconciled against exact container and image IDs, stopped restoration is previewed before apply, and monitor sync, direct preflight, readmit, routed preflight, and final status follow. `restored: true` is only an action summary; closure still requires the retained final receipts to show the exact incumbent running with no containment/OOM error, router admission restored, direct/routed gates passing, and no candidate GPU owner.

## Breakage probes

- **Unreadable/drifted input or tool — refuted for the planned path.** Missing files or a wrong digest fail before quiesce; later drift fails before the next phase. A failed managed mutation enters the recovery finalizer because intent flags are set before dispatch.
- **Malformed/boundary input and path metacharacters — refuted for these pinned bytes.** Commands use argv arrays, the Rust config uses `deny_unknown_fields`, endpoint configs are exact and bounded, and the native test independently validates package signature, namespace, model identity, token bounds, and selected graph geometry.
- **Resource exhaustion — bounded with one residual.** Native execution has a 600+10 second inner termination policy, a 630-second parent ceiling, reduced cache geometry, a 32 MiB readback buffer, and a 2 GiB GPU reserve. Host RSS is not cgroup-capped, so this is a trusted pinned-binary diagnostic rather than a general safe runner. The reviewed loader/package lineage and reduced geometry make that residual acceptable for this one run; any unexpected memory pressure must terminate the action and invalidate the endpoint.
- **State/process drift — refuted on ordinary completion; fail-closed on abnormal timeout.** Each returned endpoint must leave the global NVIDIA compute inventory empty. If the outer timeout fires before that receipt, the action skips the HTTP load and enters recovery; the stopped-only restore preview prevents overlapping an unknown GPU owner. Such a path is a failed diagnostic and failed restoration until an independent empty-GPU receipt and all exact restoration gates pass.

## Residual limits

The digest checks use `sha256sum` rather than held no-follow descriptors, so they do not prove absence of a transient modify-and-revert attack during a run. The paths are fixed, root/protected local inputs and the action rechecks after each phase; this is acceptable for the trusted local pilot, not a reusable hostile-input contract. The native result parser does not independently compare each JSON row's endpoint to the loop endpoint, but the three reviewed config bytes are separately hash-bound and contain the correct endpoint values. Any later action/config byte change requires a new review.

## Incident correction and replacement-action review

The original GO above is revoked. The completed protected action demonstrated that `models recipes status` returns a useful exact stopped-container payload with exit status 1 because effective cgroup values are unavailable after exit. I previously accepted `old(..., check=True)` without exercising that deliberate stopped-container return path; the exception occurred before the exact identity branch. That was a material review miss.

Replacement action `state-tool-action-r2.json` was reviewed at file SHA256 `6d2d0d54687bd9e0b76e77d49ae2a6c6e759ca43f2c22f21d86efa482ce6b3ef` and embedded-Python SHA256 `a14db36ae7dec0284a8f01f04b1fb5f1e3c0a488eb4d316c7db004ca37f184ac`. It correctly changes reconciliation to `check=False`, keeps exact container/image, restart-count, OOM, clean-exit, configured-memory, and running containment checks, and preserves the supported restore preview/apply.

One narrow fail-closed correction remains before execution. The stopped branch currently ignores the dynamic memory fields and the reason for `containment_error`. A malformed payload with `running=false`, `state=exited`, exact configured limits, but non-null or contradictory effective cgroup values would be accepted. Require the observed stopped form exactly: `current_bytes`, `peak_bytes`, `events`, `effective_limit_bytes`, and `effective_swap_limit_bytes` are all null, and the envelope is the expected non-success caused by stopped/unavailable effective containment. Equivalently, require the exact expected stopped `containment_error` derived from frozen RAM/swap limits plus those null fields. The running branch must continue to require `ok=true`, `state=running`, and no containment error. Every other envelope/state remains a hard failure.

Until that correction is reviewed, the replacement recommendation is **HOLD**, `human_gate_required=false`, `promoted=false`.

### Repair closure

`state-tool-action-r3.json` closes the hold. Reviewed file SHA256: `a73f33dbc7c9a333111e7daae0dac02a4988d9f3d289063e2b175257291c4b19`; embedded-Python SHA256: `b54d205898dc0d68877bd222d190ef7ffd9992eb1584332b74f4337942ef186b`.

The stopped branch now requires the exact status schema, container/model/revision and retained ID/image; restart count zero; no OOM; clean exit; frozen configured RAM/swap; all five unavailable stopped-cgroup fields null; the exact derived unavailable-containment message; and the expected non-success envelope. It then uses the unchanged supported restore preview/apply. The already-running branch separately requires a successful envelope, running state, no containment error, and exact effective RAM/swap, in addition to the same identity/restart/OOM gates. Unknown or contradictory states fail closed.

**GO** for one execution of these exact r3 bytes, only after the current manual restoration has independently passed exact final identity/containment, monitoring, direct, readmit, routed, GPU-ownership, and protected-state checks. `human_gate_required=false`, `promoted=false`. Any byte change requires renewed review.

### Repair-2 rerun binding

The final replacement is `state-tool-action-r5.json`, file SHA256 `50efbd298d5b49bcd851976f4e12b1940a5296946a969709327fce045d7d0af9`, embedded-Python SHA256 `beb2b7a6ebc979acaffe8ac5bc6aaf718bd18cd750af0e2d4269b795e91169a0`. Relative to the already reviewed window-2 action, its only code change selects `state-input-bindings-r3.json`, SHA256 `788750ac9e8e72b0201389835cf538187c1d75f5b7a08081aa279334f61bee0c`. That binding changes exactly two inputs: the repair-2 test source SHA256 `c969a8e5cfcfe65466bf761f640343432e22478234eb495f6148e62070b606bf` and compile-only binary SHA256 `ec352f7d1ff4de97098d8c211a1c1f1331730cb1c6ff1671dc30e2934d50fb37`.

The repair-2 source independently passed the scoped context/drain review recorded in `state-implementation-review.md`; compile-only success does not claim a GPU pass. **Final recommendation: GO** for one execution of these exact r5/bindings-r3 bytes after the prior window's restoration closure is complete. No further harness repair, automatic retry, promotion, or historical-gate reinterpretation is authorized. `human_gate_required=false`, `promoted=false`.
