# Independent oracle-gate review

```yaml
schema_version: operator-workflow/v1
request: Define the minimum independent state and numerical oracles for the retained signed GLM TP2 package without adding a graph-operation family or weakening the historical 128-token gate.
gate_state: hold_for_implementation_review
targets:
  - retained GLM TP2 package d5aec1543dc32413175462d17d374e54d27def24129f878045358c4db128c357
  - Flare source 47581ccac82660953a5b59cb04b2750d64edc97d
tools_used:
  - read-only source and evidence inspection
  - git status and diff inspection
  - sha256 source binding
artifacts:
  findings_summary:
    - The existing package contract exposes persistent state views and existing Snapshot, Restore, Resume, Prefill, and Decode graph kinds, but no semantic logits/readback output.
    - Exact state-copy testing is possible as a bounded native diagnostic against declared state and cache views; full-logit numerical testing needs an explicit bounded readback contract and a newly signed diagnostic package.
    - Copy fidelity, restored-graph equivalence, and uncached numerical equivalence are separate gates. None may clear or rewrite the failed historical 128-token sampled-ID gate.
  reviewed_evidence:
    - ../../2026-10-22-flare-cache-fix/review/sampling-discriminator.md
    - ../../2026-10-22-flare-cache-fix/review/numerical-policy-addendum.md
    - ../analysis/protected-baseline.json
advisory_priors:
  - Identical inputs and RNG state can still produce different logits when selected MoE kernels use arrival-ordered atomic reductions.
  - Current retained package inspection used --unverified and therefore describes metadata but does not independently authenticate it.
recommendation: hold
human_gate_required: false
promoted: false
```

## Findings

### F1 — High: the existing package does not expose a valid logits oracle

The signed `ModelContract` declares vocabulary, cache regions, graph inputs, state access, and graph kind, but it has no output/readback declaration (`helios/proto/runtime_package.proto:128-167,256-301`). The lower execution ABI lists named buffers and graph input bindings (`runtime_package.proto:639-672`), yet GLM bootstrap registers request inputs, completion buffers, `state_pool`, and cache regions—not `DecoderScratch.logits` (`ignition/recipes/glm53/bootstrap.py:337-342,557-569`). The logits do exist during generation and Resume (`ignition/recipes/glm53/stack.py:22-30,134-160`; `resume.py:11-38`), but they remain graph scratch.

`NativeResources::download(name)` copies an entire allocation only after all replay has drained (`helios/src/runtime_package/mod.rs:843-870`). `execution_manifest()` validates registered buffer references but does not turn scratch names into semantic outputs (`runtime_package/serving.rs:7-39`). A memory-map inspection can reveal raw allocation/buffer names, offsets, dtype, and shape (`runtime_package/describe.rs:312-393`); it cannot prove which graph produced a span, the validity fence, row identity, or whether later graph reuse overwrote it. The retained `sampling-package-inspect.json` did not request that memory map and records `signatures_verified=false`.

**Wrong result to prevent:** guessing an allocation named `logits`, downloading a multi-GiB scratch owner after unrelated replay, and treating those bytes as the failing request's pre-sampling logits. This is a confirmed contract gap and a plausible memory-exhaustion/stale-data failure.

**Minimum correction:** add one opt-in, allowlisted readback descriptor to a newly signed diagnostic package: producer graph, buffer reference, dtype/shape, maximum rows, rank semantics, validity fence, and maximum bytes. Keep the graph kind `RESUME`, `PREFILL`, or `DECODE`; no new `GraphOperation` is needed. For vocabulary 154,880, one BF16 row is 309,760 bytes, so a one-row full-vocabulary capture fits below a 1 MiB per-rank bound. The native endpoint must copy only that declared span. A new diagnostic package is not byte-identical to the retained package and cannot by itself prove that the retained package's logits match.

### F2 — Medium: exact state copying, restored execution, and recomputation must remain three gates

The manifest does expose the seams needed for state testing. `StateView` and `StateAccess` carry buffer/offset/stride/size and access kind, while `GraphOperation` already includes `RESTORE`, `SNAPSHOT`, `PREFILL`, `DECODE`, and `RESUME` (`runtime_package.proto:256-301`). GLM continuation rows include FP32 recurrent state, BF16 convolution state, indexed-attention tails and partial pages, optional draft state, `last_hidden`, and `consumed_tokens`; full page pools remain separate (`ignition/recipes/glm53/pool.py:15-42,45-96,156-168`). Resume projects saved `last_hidden` without consuming a token (`ignition/components/resume.py:9-16,42-68`; `ignition/direct/scheduler.py:487-500`).

The minimum gates are:

1. **Exact state-copy oracle — bitwise.** After a completed Snapshot fence with replay drained, bind package identity, rank, graph, request slot, generation, fence, consumed-token count, logical page order, and all declared state/cache views. On both ranks compare the live source with the immutable snapshot, then Restore into a distinct prefilled/poisoned live destination and compare the restored live state with the snapshot. Compare every continuation-row byte, every referenced partial/draft record, and every referenced full-page byte. Physical page IDs may differ; logical token order and payload bytes must not. Any missing view, overlapping/out-of-range view, changed generation, page reuse, active replay, or rank disagreement is a hard failure. Hashes may summarize retained bytes but cannot replace byte-by-byte comparison.
2. **Restored-state graph oracle — numerical.** Only after gate 1 passes, start from one immutable snapshot and run the same existing `RESUME` graph serially at C1 on (a) a control live state and (b) a separately restored live state. Freeze graph variant, package/image/source identity, rank placement, request metadata, sampling state, histogram, grammar, and seed. Compare the declared pre-sampling full-vocabulary logits before the sampler, then the sampled record, then re-Snapshot and compare canonical state. A matching token alone is insufficient. Bitwise state remains mandatory; logit acceptance uses a predeclared deterministic or measured-repeatability rule.
3. **Uncached numerical oracle — independent reference.** Teacher-force the identical frozen token history through a fresh uncached execution and the restored execution. Retain a full-vocabulary logit row for every observed step, relative L2 using the independent reference norm, top-ten overlap, and FP32 `KL(reference || actual)`. Run the same prepared graph and initial state through the independent Python replay required by upstream guidance; a second invocation of the same Rust path is repeatability evidence, not an independent oracle. Predeclare arithmetic-derived component bounds before reading results.

A transfer mismatch stops before numerical interpretation. Exact transfer with a logit mismatch localizes the problem above the copy seam. Equal pre-sampling logits with unequal sampled IDs localizes it to sampling/RNG/filtering or completion transport. None of these outcomes changes the historical sampled-output result.

### F3 — Medium: first-difference localization must be staged and bounded

Use the already retained discriminator cases rather than searching for a passing seed: one no-host/full-GPU divergence (case 40 or case 0) and one restored case (case 51). Preserve their original request bytes, explicit sampling settings, and 128-token expected-ID gate. For protected-regression diagnosis, reuse one frozen `small12` and one `pageheavy` request only as localization probes; a small diagnostic sample cannot clear the full protected populations or establish performance parity.

Stop at the first failing seam:

1. Snapshot/Restore byte comparison across both ranks and referenced pages.
2. `RESUME` from equal `last_hidden`; compare pre-sampling logits. A difference here narrows the seam to saved hidden readback, LM head/all-gather, or readback integrity.
3. Teacher-forced fresh-versus-restored logits token by token; record the first differing token.
4. Only for that token, add bounded observations at existing layer boundaries and bisect the 45-layer stack. Once the first differing layer is found, compare that operator on identical operands against the independent Transformers or b12x reference. Do not instrument every layer for every request.

This follows the upstream rule that state transfers and metadata are exact while recomputed floating point uses calibrated component bounds (`docs/core-design.md:727-756,960-964,1577-1599`). The possible atomic-MoE mechanism remains a hypothesis until the first differing component is observed.

## Breakage probes for the implementation review

These probes were defined before any implementation or implementation tests existed.

| Axis | Concrete input or state | Wrong result | Status |
|---|---|---|---|
| Fail closed | Package signature/profile, graph contract, rank, or declared readback descriptor cannot be read or authenticated | Fall back to a guessed allocation/name or retain partial evidence as a pass | Plausible; must reject before GPU replay |
| Malformed/boundary | Duplicate/overlapping views; offset+length overflow; zero/oversized row count; rank >=2; stale slot generation; unknown graph; CRLF or path/command metacharacters in artifact selector | Out-of-bounds copy, wrong request attribution, or path escape | Plausible; require typed allowlists and checked arithmetic |
| Resource bound | Whole-allocation download from a rank with about 92 GB device allocations, more than one logit row, unbounded layers/tokens, or stalled drain | Host OOM, long outage, or stale capture | Confirmed API hazard; cap each logit readback below 1 MiB/rank and each state unit to signed contract sizes with a total campaign budget and timeout |
| State drift | Replay continues, row/page is recycled, package incarnation/restart changes, rank fences disagree, config reloads, or worktree bytes change between plan and capture | Internally consistent evidence for different states/builds | Plausible; bind package/index/image/source hashes, StartedAt/restart count, rank/fence/slot/generation, and before/after identities |

Tests must cover every refusal above, plus a poisoned-destination positive case on both ranks. The implementation may have at most two targeted repair attempts per stage. Retain each failed attempt; after two repairs, hold that stage instead of weakening the oracle or changing the frozen 128-token workload.

## Recommendation and residual risk

**HOLD** any full-logit or uncached-numerical claim for the existing signed package: its manifest has no semantic logits/readback output. A source-only implementation may proceed to independent review if it (1) uses only existing graph kinds, (2) adds a bounded, authenticated descriptor rather than exposing arbitrary device memory, (3) produces a newly signed diagnostic-package identity, and (4) keeps the retained-package conclusion limited to exact declared-state copy checks.

The existing 128-token gate remains failed. `promoted=false` remains mandatory. Any future live model swap or outage still needs the established managed lifecycle and restoration gate; this design review grants no lifecycle or promotion authority.

## Reviewer independence and bindings

Implementer: GPT-6 Astra. Independent reviewer: GPT-5.6 Sol high. Evaluated model: GLM-5.3-Flash under Flare; it did not grade itself. Source HEAD was `47581ccac82660953a5b59cb04b2750d64edc97d`, but the worktree contained retained local changes; the conclusions above bind the cited files and hashes rather than treating the dirty tree as upstream-clean.

- `runtime_package.proto`: `d36e2f03b78be5697ecd399e130993612c2074748dbd2bb55ea5d1fb7421014d`
- `runtime_package/mod.rs`: `7a17c6fa0c88e54c98d2dc10199c3ef86cb32f6c336dc12348285fa8803017c5`
- `runtime_package/serving.rs`: `5058bc439228e76588714ad3a304cba026dc4578059f3384b7884f227fd57e78`
- `glm53/resume.py`: `667b546bd200ce761d4fe47421bf4618b822beea69c627ee1895fc19c3f7e8df`
- `glm53/pool.py`: `6230b8ff80c077d92d490467e0bfaf270b9926ffcd2e381f4ec82d42d7028259`
- `glm53/stack.py`: `eaf14ff03e1f144cf474811a613ff4c27866e84fa904b55b9015346a728531cd`
- `docs/core-design.md`: `602152f11f8a15092237b3a24dea84925a5c5e5e925c64323f2db25cabd1866e`
- prior discriminator: `a4157e179860fdd4d1880890a896969f0281056f0baae3d38e02ed795733d463`
- numerical addendum: `0b6ae427a39d8f57ec419e671ae1a3e19ffe207e47154ef2babbe8741c8fa58d`

