# Independent trace-action review

```json
{
  "schema_version": "operator-workflow/v1",
  "request": "Adversarial read-only review of the separate scheduler-trace diagnostic action before execution.",
  "gate_state": "go",
  "targets": [
    "OPERATOR_PATH_b9012babe8e8/trace-tool-action.json"
  ],
  "tools_used": ["read-only file inspection", "static breakage probes", "source/action hash comparison"],
  "artifacts": {
    "reviewed_action_file_sha256": "cb41fc9ac5bb5fcea4b46db1c4a5c477dfcf9c43a252491f7221d509694615e7",
    "reviewed_embedded_action_sha256": "c3b92061ff1e34162aa3d8d309c29e79e8649b9f88c2b91859f80056b07192f9",
    "recovery_source_sha256": "a73f33dbc7c9a333111e7daae0dac02a4988d9f3d289063e2b175257291c4b19",
    "findings_summary": "No blocking defect in the current aligned action. The trace is a bounded, separately qualified diagnostic; incomplete window coverage fails the arm and is not retried or converted into performance evidence."
  },
  "advisory_priors": [
    "The implementing/orchestrating model is GPT-6 Astra; this independent reviewer is GPT-5.6 Sol high. The evaluated GLM/Flare runtime does not grade itself.",
    "The earlier draft with file SHA256 fe1c29d591166aa70f91e1928a8ff8d6286725303d92d2be0492f2eeefb0504b is preserved and is not cleared.",
    "Execution remains conditional on independent completion of the current incumbent restoration and protected-state checks."
  ],
  "recommendation": "go",
  "human_gate_required": false,
  "promoted": false
}
```

## Findings

No blocking finding in the exact current bytes.

The action runs four fresh managed incarnations: small12 A/B and pageheavy A/B. Its request count reconciles to 132: each incarnation has three warmups and 12 prime requests; small12 adds 24 measured requests per arm and pageheavy adds 12. The 30-second authenticated trace is started only for measured phases. A two-second live-process observation is deliberately not called a ready handshake. Post-run coverage must show a complete, zero-drop trace, both ranks for every sample, exact trace/request incarnation and recipe identity, the complete measured denominator, compatible clock-anchor intersection, every full client interval conservatively inside the trace window, and native ingress/token timestamps inside the native window. Failure of any condition invalidates that arm. No HTTP request-to-slot mapping, performance eligibility, automatic retry, or subset selection is claimed.

Trace child custody is bounded: normal completion is joined; timeout sends TERM and then KILL to the owned CLI child; cleanup stops the trace before candidate unload; server-side lease cancellation is therefore not used as a model-lifecycle substitute. Per-incarnation admission reserves load, discovery/readiness, phase, trace, range, unload, and restoration time. The action may stop after an incomplete prefix of the four incarnations if the remaining budget is insufficient; that is retained as failed/incomplete diagnostic evidence.

Recovery now uses the byte-aligned state-r3 reconciliation contract. It accepts only either the exact known stopped/unavailable-cgroup envelope before supported restore preview/apply or the exact already-running, effectively contained incumbent. It then requires monitor sync, direct preflight, readmission, routed preflight, and final status. As with the state action, `restored=true` alone is not closure evidence.

## Breakage probes

- **Unreadable state/tool:** frozen workload/source/registry hashes are checked before mutation and before every incarnation; trace command or output absence fails coverage. Refuted for the planned path.
- **Malformed/boundary input:** trace config is fixed to the reviewed model/container/registry, protected key reference, and 30,000 ms; the managed trace command performs the authenticated schema/identity checks. Client/native clock bounds, denominators, ranks, drops, and request identities are revalidated. Refuted.
- **Resource exhaustion:** the trace response is bounded by the product command, duration is 30 seconds, the owned child has a 60-second join bound, each phase has a hard parent timeout, and the whole action has 75/90-minute cutoffs. Refuted for these pinned inputs.
- **State drift:** each request wrapper proves the exact running incarnation and recipe, trace identity is joined to that proof, candidate cleanup precedes the next load, and exact incumbent recovery is independently checked. Refuted on ordinary completion; ambiguous mutations enter the same fail-closed finalizer.

## Residual limits

Full measured-population fit inside 30 seconds is intentionally unproved. A late capture start or long request sequence will fail coverage rather than yield partial evidence. The trace-template file is not separately hash-bound, but only its protected key-file reference is copied before mutation and the managed trace command revalidates key custody and runtime identity; this is acceptable for the one trusted local action, not a reusable hostile-input contract. Any action byte change requires renewed review.
