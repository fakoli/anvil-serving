# Independent final scheduler-trace causal review

```yaml
schema_version: operator-workflow/v1
request: Review the four closed paired scheduler traces, their normalization, closure, and causal limits together with the previously accepted state and protected-regression evidence.
gate_state: diagnostic_accepted_qualification_held
targets:
  - formal/trace-paired-1 small12 A/B and pageheavy A/B
  - analysis/trace-paired-1 normalized outputs
  - retained GLM TP2 package d5aec1543dc32413175462d17d374e54d27def24129f878045358c4db128c357
tools_used:
  - read-only evidence and source inspection
  - independent SHA-256 and raw JSON recomputation
  - adversarial completeness, boundary, resource, and drift probes
artifacts:
  findings_summary:
    - All four 30-second captures are complete for 72/72 measured HTTP requests and 144 scheduler samples, with zero drops or boundary exclusions and both TP2 ranks in every sample.
    - The 36 measured A/B request pairs have exact body identity, prompt counts, output-token IDs, messages, request deltas, and speculative-work deltas; this supports a matched observational population only.
    - A/B graph-shape mixtures differ, and no HTTP request to native slot or generation mapping exists. The rank-duration spread is not synchronization wait and wall minus max-rank GPU duration is not pure CPU time.
    - No specific production bottleneck, causal arm effect, numerical repair, performance qualification, or promotion is proven.
  trace_summary: ../analysis/trace-paired-1/trace-paired-1-summary.json
  trace_closeout: ../formal/trace-paired-1/closeout.json
  operational_closure: ../formal/trace-paired-1/root-closure-verification.json
  prior_integrated_review: state-results-review.md
advisory_priors:
  - Arm A is the retained 25-percent row split with 52 rows and 7314 pages; arm B is the 75-percent row split with 158 rows and 2434 pages. The fixed total cache budget does not make their observed graph mixtures interchangeable.
  - The trace captures are separate from the protected timing bracket and cannot be spliced into its per-request latency comparisons.
recommendation: accept_trace_as_bounded_diagnostic_hold_causal_bottleneck_numerical_performance_and_promotion
human_gate_required: true
promoted: false
```

## Findings

### F1 — High: the trace does not prove a production bottleneck or causal A/B effect

The normalized record correctly labels all four groups diagnostic-only and performance-ineligible, and explicitly rejects HTTP-to-slot mapping, request-attributed timing, synchronization-wait interpretation, pure-CPU subtraction, and use of graph capacities as executed-token counts (`analysis/trace-paired-1/trace-paired-1-summary.json:276-294`; `trace-paired-1-summary.md:33-38`). Those limits are necessary.

The raw graph population is not invariant across arms. `small12` A/B have respectively Restore shape counts `4:8, 2:13, 1:3` and `4:2, 2:16, 1:6`; pageheavy A/B have Restore counts `4:3, 1:9` and `1:12`. Resume mixtures also differ in small12. Although all 36 A/B measured request pairs have exact request bodies, prompt counts, one-token outputs, messages, aggregate request deltas, and speculative-work deltas, there is no retained mapping from any HTTP request to a particular scheduler sample. The trace therefore cannot say that the row split changed a given request's Restore/Resume duration or selected graph.

**Concrete wrong result:** identify Restore handling, rank imbalance, CPU coordination, the row/page split, or any named graph as the cause of the protected regression. **Classification: confirmed attribution blocker.** The allowed observation is only that these complete matched HTTP populations overlapped the retained aggregate scheduler populations. No specific production bottleneck is proven.

### F2 — Medium: the observed scheduler timing is internally complete and arithmetically sound

The four captures contain 48, 48, 24, and 24 samples. Every raw sample references a catalogued graph, has ranks exactly `[0, 1]`, has nonnegative per-rank CUDA-event durations, has `max_rank_gpu_ns` equal to the larger rank duration, and satisfies selection before commit before observation. No sample is queued. The four normalized raw-capture hashes match their source bytes, and the reported p50/p95 values agree with independent recomputation. Coverage is 24/24 for each small12 arm and 12/12 for each pageheavy arm, with zero excluded boundary samples (`trace-paired-1-summary.md:11-17`; `trace-paired-1-summary.json:3-273`).

The population-level medians are close: max-rank GPU p50 is 0.457/0.422 ms for small12 A/B and 0.424/0.427 ms for pageheavy A/B; wall p50 is 0.623/0.611 ms and 0.623/0.618 ms (`trace-paired-1-summary.md:26-31`). Restore samples show a larger descriptive wall-minus-max-GPU remainder than Resume samples, but that remainder includes scheduling, coordination, staging, and measurement boundaries. It is not a CPU-cost or blocking-time measurement. Rank duration differences are concurrent-rank observations, not synchronization wait.

**Concrete wrong result:** subtract max-rank GPU duration from wall duration and label the result CPU overhead, or interpret rank-duration spread as TP synchronization delay. **Classification: refuted by the analysis contract and retained wording.** The current report keeps these values descriptive.

### F3 — Medium: capture/request coverage is valid, but it is temporal rather than per-request attribution

The campaign made 132 HTTP requests across the four incarnations: 12 warmups, 48 primes, and 72 measured requests. Tracing covered only the measured phases, as prospectively required (`review/trace-action-review.md:33-35`). All measured client intervals are conservatively contained in the relevant clock-anchor envelope, and native ingress/token timestamps are inside the same process-local trace window. The four coverage receipts explicitly say `http_request_to_slot_mapping: not_inferred`; root closure binds their exact hashes (`formal/trace-paired-1/root-closure-verification.json:4-15`).

This establishes full temporal overlap and denominator preservation. It does not establish that there are exactly two scheduler samples per HTTP request in a semantic sense, even though the aggregate count is 144 for 72 requests and only Restore/Resume graphs appear. It also does not attach a particular graph, slot, generation, fence, or rank duration to a particular request.

**Concrete wrong result:** pair scheduler samples to HTTP cases by order, count, slot reuse, or proximity and compute request-level A/B deltas. **Classification: confirmed disallowed inference.** A future per-request attribution claim would require an explicit runtime correlation identifier rather than post-hoc ordering.

### F4 — Medium: trace evidence does not alter the prior numerical and performance holds

The prior independent review accepted exact canonical Snapshot to Restore to re-Snapshot byte equality only for the signed package, both ranks, three tested endpoints, and reduced diagnostic geometry. It kept full-logit equivalence, independent uncached/reference comparison, host-store fidelity, and the historical 128-token exact-ID gate open (`review/state-results-review.md:42-62`). It also retained the broad, mixed protected ABBA-2 timing distributions and the unchanged three-percent gate (`state-results-review.md:64-68`).

Nothing in these traces supplies the missing numerical oracle. The traces contain existing scheduler metadata and CUDA-event durations, not logits, sampled-ID equivalence, host-transfer attribution, or a matched incumbent comparison. They do not convert the partial case-51 top-20 difference into a state-copy or kernel defect. The integrated conclusion remains: exact canonical state-copy behavior was observed in the bounded native test; numerical and protected-performance qualification remain failed or open.

### F5 — Low: operational closure is complete for this trace window

The final closeout records no experiment or restoration error, four completed generations, deadline compliance, `performance_eligible=false`, and `promoted=false`. The independent root receipt records exit code zero, exact incumbent restoration, four trace groups, 72 measured requests, and only the two expected VLLM GPU processes (`formal/trace-paired-1/root-closure-verification.json:1-25`). The separately retained final status, direct and routed preflights, monitor generation, router readiness/admission/idle state, restart count zero, effective limits, and no-OOM state close the operational window. They do not qualify the candidate.

## Breakage probes

These probes were defined before consulting retained test claims.

| Axis | Concrete input/state and wrong result | Result |
|---|---|---|
| Unreadable or incomplete state | Missing capture, rank, graph, coverage receipt, or final restoration is silently normalized as complete | **Refuted for this run:** four raw captures, four normalized outputs, both ranks in every sample, four coverage receipts, closeout, and root closure are present and hash-consistent |
| Malformed/boundary input | Duplicate sample identity, unknown graph, negative/nonfinite duration, bad max-rank value, inverted selection/commit/observation order, or sample outside trace bounds is accepted | **Refuted for the retained bytes:** independent raw inspection found none; zero boundary exclusions are recorded. Residual risk is that the reused normalizer relies on the already validated product trace schema rather than reimplementing every consumer check |
| Resource exhaustion/missing bound | The 1,024-record ring overflows or the 30-second collection silently drops work while still yielding a causal result | **Refuted for this run:** the largest capture has 48 samples, every capture reports `dropped_updates=0`, and the result remains diagnostic-only |
| Cross-process/config drift | A/B data are combined across an unbound process, recipe, image, source, or restarted container | **Refuted for identity:** each arm binds a fresh distinct container/StartedAt, exact recipe arm, pinned image/revision, restart zero, and null containment error. **Confirmed design limitation:** fresh incarnations and intentionally different row/page geometry prohibit within-process causal attribution |
| Cross-seam mapping | HTTP requests are assigned to slots/generations by ordering or equal counts | **Confirmed disallowed inference:** all four receipts say `not_inferred`; no such mapping appears in the normalized output |

## Recommendation and residual risk

**ACCEPT the four scheduler traces and their normalization as bounded diagnostic evidence. HOLD every causal bottleneck claim, numerical qualification, protected-performance qualification, tuning selection, and promotion.** The strongest supported trace conclusion is that complete, exact-output/equal-work measured HTTP populations overlapped complete two-rank Restore/Resume scheduler populations under both cache geometries, with no drops. The captures show where existing scheduler time was observed; they do not prove why A/B protected timings varied or identify a production bottleneck.

Implementer/evidence generator: GPT-6 Astra. Independent reviewer: GPT-5.6 Sol high. Evaluated model: GLM-5.3-Flash under Flare. The evaluated model did not grade itself. `promoted=false` remains mandatory.

### Bound artifact hashes

- normalized summary JSON/Markdown: `842d113ec911c531b71dd9f3d98f726a5ae3a063671b286833844d6a8588a572` / `3d5ec22dbc1264699495429b12a2e5990484f41b02f8d0d84f9a7609b0a39888`
- normalized small12 A/B: `91f99dd63ed474eaeaefba1c4b4ba0a68362771a15cd08317677dd41cd872624` / `1bda3f3d01bad20beecc4869c1df7e281a7b2182de4ebe3b255c22548a753863`
- normalized pageheavy A/B: `3abf9d262ec35f4c61a3c549578b964b4f3700331cee5589ca3deba92d6c5d45` / `1e1acbaf31239a932cd838301952c4ac20aeaf5c7e514dc92247f8fd393fc34a`
- raw scheduler traces, small12 A/B: `564c409c8d0df8bbb337c45d3aa6b04d0e6d3094e0fd55b8bb60be6c69871ed0` / `c46e40bc421e353e9b56e52213b30cf709fc8020b08aca8f35706e260768fe8f`
- raw scheduler traces, pageheavy A/B: `934bb26586dd286605113ad5955da6b18ea6038b16aa1e7deab80de8cb5ddeaf` / `088730c5b1e38ed873e02638ba68f665e007d1c76ff0acaeecbbbedd14026f91`
- trace coverage, small12 A/B: `9effdfde93d37ddd3a0446d5a7edf64dc2c513d78e7b82a553d902a60b74ebd8` / `b33802a9f70003e475f35bc057e6e78913a93277bf5975aeba584cea798cc688`
- trace coverage, pageheavy A/B: `e2e4bafb7e2c3248d2230961a1c3228f6760df822c76810fb9c427cd6ae6118b` / `1ef86d4b706e1987f2aabd67825b4464211b06df4196551079be24876753fe52`
- measured attempts, small12 A measured/measured-2: `a94c749ad386247c010d2d5d811fdf8aea69e347383a006ef3a52c4a88a8a141` / `1b9a753ea57e18184e5a2a503c2ddd46ca4f0aaf1ae8661a84e7df18d9c9c40a`
- measured attempts, small12 B measured/measured-2: `fecc7aa58568c275e3e236f64e15ef888253ae64cd23b5097272504eeebabcd2` / `7a7520692429a37ba582257495241fa8c6855c21a77c0afec2b4e8291e9ab2d4`
- measured attempts, pageheavy A/B: `6b3ea5d267f517a2dfd1f670eb9d1c9500f8c42dd7e4eeac9e0340ee386cd807` / `a32eda34a5cf9b95daca69b45bf77fa9ee5baf169d1da5506b379843265f41e7`
- closeout/root closure: `97a828bdd37a2d6a1ce7da7283aae5b235b4d4b6b299a34acf086ca72c96ec71` / `466d51eb32f776e66d92033451f7e9e5c329119ce83e8615ce070bf404add6dd`
- retained analyzer: `705850323742f76da327ed5ea04c0bbf8f0c948c928e65aff863196521891c4f`
- prior integrated state/protected review: `33cfff4383f5fc0b07e9657100f7c04e75afe83e522fcb41af6811644288d0e6`
