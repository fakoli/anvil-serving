# Followup publication publisher privacy review

Verdict: **GO for offline preparation; final publication privacy gate remains pending.** This is a static review of publisher behavior and selection policy, not a scan of a completed inventory or bundle. The active native window was untouched.

The followup publisher differs from the previously reviewed cache-fix publisher in exactly two lines: its descriptive docstring and required inventory schema. Redaction and packaging behavior are otherwise identical. It imports the same prior `scrub` implementation, clears its mutable container-ID set, discovers exact `container_id` values recursively from every selected JSON/JSONL source (including archive-only sources), then reruns path preflight before writing. The supplied synthetic check covers archive-only IDs, JSONL IDs, manifest/provenance scrubbing, malformed JSONL, empty IDs, symlink escapes, output collisions, and deterministic archives. I inspected that check; I did not execute it in this read-only task.

Source/output containment, regular-file selection, UTF-8 requirement, JSON/JSONL parsing, scrubbed member names, deterministic tar/gzip encoding, and original/public hash provenance remain present. Role accounting requires an explicit missing/not-applicable explanation. The inventory policy retains interrupted and partial attempts and excludes active producers; it does not authorize dropping failures or copying the prior corpus wholesale.

Remaining privacy limits are inherited and require the final expanded-payload gate:

- `scrub` uses case-sensitive host replacements. Uppercase identity spellings escaped the prior campaign and were caught by its independent identity scan. Container discovery recognizes the exact structured key `container_id`; serialized identities inside text or differently named fields can remain. The prior campaign's serialized failed-status identity illustrates this limitation.
- This scrubber is a finite pseudonymizer, not a credential detector. It handles selected private IPv4 ranges, UUID-shaped identities, and selected path forms; it does not establish that arbitrary credentials, IPv6, other host/account names, or all path spellings are absent. Credential-bearing inputs must be excluded and every UTF-8 expanded payload scanned independently, regardless of suffix.
- The imported redactor is selected by retained filesystem path rather than an enforced digest. The digest below binds what was reviewed; verify it again before final packaging. Do not infer unchanged redaction behavior from the wrapper hash alone.
- Final inventory completeness, duplicate-source selection, closed-producer status, public links, exact provenance, all ten final roles, and payload privacy are not yet verified. No bundle existed for this review. Publisher-generated JSON parsing is permissive about duplicate keys/nonfinite values; the strict final payload validation must remain separate.

No new redaction regression was found in the followup wrapper. No publisher or source changes are requested by this preparation review. After all producers and reports close, review the complete explicit inventory and validate the actual expanded bundle plus changed public docs, retaining findings and exact hash bindings. Prior signature exceptions must not be assumed to apply to new paths or content.

## Reviewed inputs

- `2026-10-23-flare-state-diagnostics/publication/publish-evidence.py`: SHA256 `0509b762cd1ac9e76422539160ecf498441b02399b56209d5be993d3739f65fb`
- `2026-10-23-flare-state-diagnostics/publication/check-publish-evidence.py`: SHA256 `4a1496f95673fd935acffe982637a01d1121ff110f27a0963a44c798f6cd48ae`
- `2026-10-23-flare-state-diagnostics/publication/inventory-selection-policy.md`: SHA256 `b1cce94f2cf0f43bdfd51621003b6d8995485fabc19d48d282a334632a11b439`
- `2026-10-22-flare-cache-fix/publication/publish-evidence.py`: SHA256 `dd12456d5835a943b2523df23c6772f9553ea3b2bb2c1acbd7b3d1a71c6b0186`
- `2026-10-21-flare-inference-diagnostics/wave-v1/publish-evidence.py`: SHA256 `42954231b75dda79e806c7abb4be8cf19af1cc5e3c69102c5aa9f9b7e4c307c1`
