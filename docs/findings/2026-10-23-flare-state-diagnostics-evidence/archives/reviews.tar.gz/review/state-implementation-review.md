# Independent native state-oracle implementation review

```json
{
  "schema_version": "operator-workflow/v1",
  "request": "Review the test-only signed-package Snapshot A to Restore to Snapshot B oracle before root-owned TP2 execution",
  "gate_state": "not_required",
  "targets": {
    "source": "OPERATOR_PATH_d81b073e3d22/flare-local-inference",
    "test": "runtime_package::state_replay_tests::retained_tp2_snapshot_restore_snapshot_exact",
    "implementing_model": "GPT-6 Astra",
    "reviewing_model": "GPT-5.6 Sol",
    "evaluated_model": "signed GLM TP2 Flare package"
  },
  "tools_used": [
    {
      "name": "read-only source/diff inspection",
      "source_class": "filesystem",
      "ok": true,
      "dry_run": true,
      "confirmed": false,
      "target": "test-only Rust modules and existing GLM state-transfer source",
      "error": null
    },
    {
      "name": "retained compile-log review",
      "source_class": "evidence",
      "ok": true,
      "dry_run": true,
      "confirmed": false,
      "target": "validation/state-oracle-compile-{1,2,3}.log",
      "error": null
    }
  ],
  "artifacts": [
    {
      "kind": "findings_summary",
      "blocking_findings": 0,
      "recommendation_scope": "source-only GO; hardware execution remains root-owned and diagnostic-only",
      "historical_128_id_gate_cleared": false
    }
  ],
  "advisory_priors": [
    "The protected numerical gate remains failed and this state roundtrip is only one discriminator.",
    "The reduced four-snapshot/1024-page geometry is diagnostic and does not represent the serving cache configuration."
  ],
  "recommendation": "needs_more_data",
  "human_gate_required": false,
  "promoted": false
}
```

## Findings

No blocking correctness or safety defect was found in the native test implementation.

The test compares the right objects: immutable Snapshot A is restored into a distinct live allocation and immediately re-snapshotted into distinct Snapshot B. It never treats the packed live row as byte-equivalent to a snapshot. For the intended `max_concurrency=4`, `mtp_draft_tokens=2`, `adaptive_verification=false` selection, the existing GLM maintenance graph copies the complete row and materializes model-owned partial main/draft page records into the snapshot row. Therefore the full signed row-unit A/B comparison is source-derived; it does not add an arbitrary padding exclusion. Complete pages are deliberately shared by logical position, while the target's partial/draft private pages are distinct, poisoned, restored, and incorporated into B ([state_replay_tests.rs:416](OPERATOR_PATH_5b40ee92115a/state_replay_tests.rs:416), [state_transfer.py:138](OPERATOR_PATH_aa521f190bf2/state_transfer.py:138), [maintenance.py:30](OPERATOR_PATH_f151d4fe4206/maintenance.py:30)).

Ownership is credible and falsifiable: the destination live row and private pages are reserved by the scheduler before poisoning; Snapshot B uses the existing snapshot allocator; source snapshot, null row, original live execution rows, and original page planes are hashed before the second request and rechecked afterward. First mismatch reports rank and byte offset. The helper is compiled only for tests and introduces no production API or new graph operation ([state_replay_scheduler.rs:1](OPERATOR_PATH_b16e67d2b0f6/state_replay_scheduler.rs:1), [scheduler.rs:2539](OPERATOR_PATH_175c5e210da0/scheduler.rs:2539)).

Panic handling is also bounded correctly inside the GPU portion: both success and caught-panic paths close the TP2 executor, require a confirmed drain before scheduler retirement, and deliberately leak CUDA owners rather than free live resources after an unconfirmed drain ([state_replay_tests.rs:374](OPERATOR_PATH_3b139ff7ab47/state_replay_tests.rs:374), [state_replay_tests.rs:576](OPERATOR_PATH_127309851bc8/state_replay_tests.rs:576)). Three retained compile-only invocations passed. They prove buildability, not GPU behavior.

## Breakage probes and coverage

- **Unreadable or unauthenticated package/profile:** refuted. Bounded reads fail the test, publisher entries are validated, signer fingerprint and namespace are checked explicitly, and normal package authorization/stored-data verification precedes loading.
- **Malformed config, device aliasing, oversized tokens, invalid endpoint, catalog drift:** refuted by `deny_unknown_fields`, device/range checks, the signed package contract, and applying the same `LoadOptions::select` catalog filter before sizing.
- **Undefined row padding or omitted partial page state:** refuted for the frozen 4/2/false configuration by the captured transfer implementation described above. Running a different MTP selection is outside this clearance.
- **Destination alias or source mutation:** refuted by distinct row/page checks, poison readback, and post-operation SHA256 guards.
- **Resource exhaustion or hung GPU:** partially bounded. Readback uses two reused 16 MiB buffers, each row is capped at 256 MiB, cache geometry is reduced, and each polled fence has a 120-second deadline. Blocking CUDA calls and final drain still require the root-owned outer process deadline and restoration transaction.
- **Config/profile/token drift between review and execution:** plausible outside the Rust test. The run plan must hash-bind the test binary, package/index identity, exact 4/2/false JSON, public profile, token file, and source files immediately before execution, retain the same values afterward, and use the documented root-only profile path without copying private key material.

## Claim boundary

A pass establishes exact packed continuation-state roundtrip for the exercised endpoint on both ranks of this signed package. It does not establish uncached numerical correctness, sampler/RNG equivalence, logits equality, host-store/DMA behavior, cache-policy performance, serving-cache capacity, or repair the historical exact-128 token-ID failure. A mismatch localizes the defect to the captured state maintenance path or its packing inputs, but does not by itself identify which field or kernel caused it.

**Recommendation:** source-only GO for one root-owned, outer-time-bounded hardware execution after the exact inputs above are hash-bound and GPUs are exclusively assigned. `promoted=false`; no default, package, or production API change follows.

## Repair 1 review after window-1 failure

Window 1 exposed `cuMemcpyDtoHAsync` invalid-value failure because direct rank inspection left rank 1 current on the caller thread before the rank-0 executor submitted. Repair patch SHA256 `c57bf5212ee1742642e4691f1f04bbaefea68dedbf3374d450fca204189872de` and source SHA256 `62d305a28f09506cdeea2bb50cc2f744602be9d66202a163df14755f8b5b81f0` were reviewed. Compile-only validation passed in 8.95 seconds and produced binary SHA256 `370b9175bd5a52c11d623f23690e467483969f5dfe599e929e863f1ff2b03902`; no GPU test ran.

The new scoped context helper correctly captures the caller's current CUDA context, switches to the inspected rank, and restores the saved context on both normal return and unwind. Every direct device read is routed through it; digests inherit that coverage; poison wraps memset/synchronize and its subsequent verification reads use the same helper. The pre-submit assertion is correctly placed before input packing and graph submission. The packed A/B oracle, poison ownership, source guards, graph selection, and drain policy are otherwise unchanged.

One blocking placement defect remains. After the final A/B comparison and guard digests, the code saves `context_before_close`, calls `executor.close()`, and asserts the saved value only after successful drain. If the final direct inspection leaked rank 1, close would run under the wrong context before the guard fired. Move or execute that equality assertion immediately before `executor.close()`; the close result may then be handled exactly as before. This is the sole requested repair.

**Repair-1 recommendation: HOLD.** `state-tool-action-r4.json` has an otherwise clean action-only delta and `state-input-bindings-r2.json` correctly binds the current repair source/binary, but both become obsolete when the source assertion moves and therefore are not execution-cleared. No broader architecture change or new oracle is requested. `promoted=false`.

### Repair 2 closure

Repair 2 closes the hold without changing the oracle. Reviewed patch SHA256: `7b9be21cf9a709b84bf5c01e65e01f0e4b73da22e3f268a2fd78db404468583a`; source SHA256: `c969a8e5cfcfe65466bf761f640343432e22478234eb495f6148e62070b606bf`. Compile-only validation passed in 7.36 seconds and produced binary SHA256 `ec352f7d1ff4de97098d8c211a1c1f1331730cb1c6ff1671dc30e2934d50fb37`; no GPU test ran.

The code now detects a missing or wrong caller context before close. On mismatch it attempts to restore the known rank-zero executor context. A failed restore forgets both executor and native owner before panicking, so unwinding cannot free GPU resources with an unconfirmed context. A successful restore proceeds through the existing close/drain contract; unconfirmed drain still forgets both owners. Only after a confirmed drain and scheduler release does the captured mismatch fail the test. Normal and panic paths therefore preserve the original explicit ownership policy.

All direct read/digest/poison callers remain covered by the scoped context helper, the rank-zero pre-submit assertion remains before packing/submission, and the exact Snapshot A/Restore/Snapshot B byte comparison and guards are unchanged.

**Repair-2 recommendation: source GO** for one new, hash-bound rerun. The obsolete r2 bindings/r4 action are not cleared; execution requires a new binding/action that names the repair-2 source and binary hashes and otherwise remains byte-equivalent to the already accepted state-r3 lifecycle. `human_gate_required=false`, `promoted=false`.
