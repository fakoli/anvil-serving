# Independent protected HTTP-harness review

```json
{
  "schema_version": "operator-workflow/v1",
  "request": "Independently review the protected ABBA HTTP adapter and the held top-20 discriminator before any serving change",
  "gate_state": "not_required",
  "targets": {
    "protected_timing": "harness/protected-regression-plan.json",
    "initial_root_action": "runtime/protected-tool-action.json",
    "repair_1_root_action": "runtime/protected-tool-action-r2.json",
    "repair_2_root_action": "runtime/protected-tool-action-r3.json",
    "discriminator": "harness/logprob-discriminator.py",
    "evaluated_model": "signed GLM TP2 Flare package",
    "implementing_model": "GPT-6 Astra",
    "reviewing_model": "GPT-5.6 Sol"
  },
  "tools_used": [
    {
      "name": "read-only source and evidence inspection",
      "source_class": "filesystem",
      "ok": true,
      "dry_run": true,
      "confirmed": false,
      "target": "2026-10-23-flare-state-diagnostics/harness",
      "error": null
    },
    {
      "name": "prepare-protected-bracket.py --check and --print-commands",
      "source_class": "offline CLI",
      "ok": true,
      "dry_run": true,
      "confirmed": false,
      "target": "protected-regression-plan.json",
      "error": null
    }
  ],
  "artifacts": [
    {
      "kind": "findings_summary",
      "protected_adapter": "GO",
      "initial_root_action": "superseded after its 45/60-minute restoration-reserve guards were not enforced",
      "repair_1_root_action": "HOLD because ambiguous quiesce/stop outcomes can bypass readmission/restoration",
      "repair_2_root_action": "GO for the bounded protected timing action",
      "top20_discriminator": "GO as a separate four-request top-20 discriminator; not a full-logit or historical-gate oracle",
      "promotion_evidence": false
    }
  ],
  "advisory_priors": [
    "The prior cache result is diagnostic-only and the historical exact-128 output gate remains failed.",
    "The declared 124-minute sum is a set of phase ceilings, while the root-owned 45-minute request cutoff intentionally truncates this bounded diagnostic."
  ],
  "recommendation": "needs_more_data",
  "human_gate_required": false,
  "promoted": false
}
```

## Findings

### Repair 2 disposition — accepted for bounded execution

Repair 2 (`runtime/protected-tool-action-r3.json`, script sha256 `d477c78faf682a7ccb5085ffba0fdd6401042032c25d6efe4ecb143aae2ea67d`) closes the two remaining recovery defects:

- quiesce and stop are marked attempted before dispatch, so ambiguous client outcomes enter reconciliation;
- reconciliation reads the exact retained recipe identity, checks the expected full container and image IDs, skips restore only when that exact container is already running, and otherwise uses the bound managed restore;
- candidate cleanup catches `BaseException`, so cleanup interruption cannot bypass the restoration block;
- all candidate operations remain clipped to the 75-minute request cutoff, restoration is clipped to the 90-minute wall deadline, and conservative incarnation admission preserves the 15-minute reserve.

**Breakage-probe outcomes:** ambiguous successful quiesce/stop is **refuted** by attempt-before-dispatch flags and final reconciliation; cleanup interruption bypass is **refuted** by the `BaseException` boundary; a different retained identity is **refuted** by full ID/image comparison; unreadable reconciliation state is **fail-closed** as a retained restoration error rather than a restored claim.

One closeout limitation remains: `restored=true` does not itself assert the final status payload's containment error, restart count, or OOM fields. This does not block the bounded diagnostic because the final status artifact is retained and direct/routed/monitoring checks remain mandatory, but campaign closure must independently require final `running=true`, exact ID/image, `containment_error=null`, `restart_count=0`, and no OOM event before accepting restoration.

### High — repair 1 can skip restoration after an ambiguous successful mutation

**Concrete probe:** let `router quiesce` or the incumbent `serves down --keep-container` succeed on the managed side, then make the client time out, receive malformed output, lose transport, or receive `KeyboardInterrupt` before the call returns. In `runtime/protected-tool-action-r2.json`, `quiesced=True` and `stopped=True` are assigned only after those calls return. The `finally` block conditions readmission on `quiesced` and exact restoration on `stopped`, so the wrong result is a quiesced router or stopped incumbent with the corresponding recovery path skipped.

**Classification:** confirmed from repair 1 source (`artifact sha256:61c61cc6ec7c2b246e24f11589b4c99f6a512597ffac40bc7b94ce077f2c1e38`; enclosing JSON sha256 `de08c76d0af5057d2487a3c41b87439ed76534fa51bb39115e4aa31b477bce8e`). Syntax validation does not cover ambiguous mutation completion.

**Required correction before execution:** set `quiesce_attempted` and `stop_attempted` before issuing each mutation. In `finally`, reconcile observed state and conservatively attempt exact restore/readmission after an ambiguous outcome rather than interpreting a missing return as no mutation. Candidate cleanup must also be nested so a `BaseException` there cannot bypass restoration; it currently catches only `Exception` before entering the restoration `try`.

### Resolved in repair 1 — initial root action could consume the 15-minute restoration reserve

**Concrete probe:** let a fresh incarnation begin with 76 seconds remaining before the 45-minute request cutoff. In `runtime/protected-tool-action.json` the `remaining()` guard requires only 75 seconds, after which load may run for its 420-second timeout and discovery/readiness may continue. The action can therefore cross the request cutoff before it reaches another `remaining()` check. Likewise, monitoring range collection and the per-incarnation unload can continue after a phase ends near the cutoff. Although `deadline = start + 60*60` is assigned, it is never read. The wrong result is candidate setup/teardown consuming the intended 15-minute restoration reserve, with no enforced 60-minute wall bound.

**Classification:** confirmed in the initial captured action (`sha256:be903fe5bd54d35e860f787ed8f6a7badb07c747b922318397c0610b81e51db9`). Repair 1 corrects this defect with a 75-minute request cutoff, 90-minute wall deadline, absolute operation timeouts, and conservative per-incarnation admission budgets.

**Resolution assessment:** the repair is conservative and closes the original deadline defect. It does not clear the new ambiguous-mutation blocker above.

### Resolved — top-20 script previously accepted fewer than the declared eight tokens

**Concrete probe:** return one to seven well-formed token/logprob rows, with matching emitted token IDs and 20 finite unique alternatives per row. `distributions()` accepts the response because it permits `1 <= len(ids) <= 8`; it also does not bind `usage.completion_tokens` or the terminal finish reason to an exact eight-token observation ([logprob-discriminator.py:16](../harness/logprob-discriminator.py#L16), [logprob-discriminator.py:58](../harness/logprob-discriminator.py#L58)). The resulting wrong outcome is a labelled eight-token discriminator artifact built from a shortened completion.

**Classification:** confirmed. The retained offline tests cover positive, cutoff, missing, nonfinite, and duplicate fields, but not an early terminal completion with one to seven otherwise valid rows.

**Resolution:** the current script requires exactly eight emitted IDs, eight logprob rows, and `usage.completion_tokens == 8`; the offline check rejects shortened and usage-mismatched responses. This does not change the historical exact-128 gate or create a full-logit oracle.

### Resolved — top-20 script previously did not prove same-incarnation/cache-state labels

**Concrete probe:** restart the serve or change cache state between `first` and `repeat` while preserving the API-key file identity. Per-request uptime may increase normally after a restart, so the local `after >= before` check passes; there is no cross-request `StartedAt`/container/restart-count binding and no cache/prompt-accounting assertion ([logprob-discriminator.py:49](../harness/logprob-discriminator.py#L49), [logprob-discriminator.py:63](../harness/logprob-discriminator.py#L63)). The wrong result is a `first`/`repeat` comparison whose histories came from different process incarnations or whose claimed cache condition was not observed.

**Classification:** confirmed as an oracle gap; no restart was observed because the script has not run. The frozen phase wrapper has the needed managed identity checks, but this standalone script does not use them.

**Resolution:** before and after every request the current script validates exact managed container/image/`StartedAt`/restart/model/revision/containment identity against the frozen proof and registry/recipe digests. It reconciles prompt tokens with prefill plus GPU/host reuse, requires positive first-request prefill, requires a full GPU-cache repeat, and rejects any host fetch. It remains separate from the protected timing bracket and retains raw failure artifacts.

## Protected timing decision

No blocking defect was found in the protected **adapter**. It fails closed on plan/schema drift, A/B geometry, timing registry/image/patch identity, frozen input hashes, phase denominators, an existing or relative output root, and malformed cutoff inputs ([prepare-protected-bracket.py:23](../harness/prepare-protected-bracket.py#L23), [prepare-protected-bracket.py:31](../harness/prepare-protected-bracket.py#L31), [prepare-protected-bracket.py:75](../harness/prepare-protected-bracket.py#L75)). Its generated commands are shell-quoted and call only the previously frozen HTTP phase wrapper; they do not perform lifecycle work ([prepare-protected-bracket.py:83](../harness/prepare-protected-bracket.py#L83)). The exact registries run the already exported package and do not enable compilation or transfer verification during timing. Repair 1's cutoff budgeting is accepted; its recovery state machine remains blocked by the ambiguous-mutation defect above.

The source-level breakage probes were:

- unreadable or mutated plan, runtime pins, registries, and frozen files: **refuted** by fail-closed validation;
- relative/existing output paths, invalid cutoff, and command/path metacharacters: **refuted** by path checks plus argument quoting;
- unbounded phase execution: **refuted** by per-phase/child bounds and the common absolute cutoff;
- drift across phases or fresh incarnations: **plausible only outside this adapter** and contained by the root-owned lifecycle contract, which must retain one exact managed identity/readiness record for every A/B/B/A incarnation;
- trace overhead contaminating timing: **refuted by design**, because trace collection is explicitly separate ([protected-regression-plan.json:109](../harness/protected-regression-plan.json#L109)).

After the repair 1 recovery-state defect is corrected, the protected timing bracket is cleared subject to these already-stated controls:

1. Use an absolute request cutoff no later than 45 minutes after the outage begins; do not start another phase once the frozen wrapper reports insufficient remaining time.
2. Load a fresh managed incarnation for each A/B/B/A position and retain its exact registry, image, container, `StartedAt`, restart count, readiness, and containment evidence.
3. Preserve every partial, missing, and failed phase. Do not produce a performance or policy conclusion until a separately reviewed normalizer proves complete matched denominators and work/output eligibility.
4. Keep detailed tracing disabled during timing. Run the root-owned managed unload, exact retained restoration, monitoring, direct preflight, readmission, and routed preflight finalizer regardless of bracket completion.

## Residual risk

The adapter deliberately cannot enforce lifecycle freshness between its generated commands or guarantee that the root finalizer runs. That risk is bounded by the parent transaction rather than by this file. The 124-minute sum of individual phase ceilings is incompatible with completing every phase inside the 45-minute request window; truncation is expected and must be represented as missing/incomplete evidence, never silently removed from a denominator. No promotion, default change, historical output-gate repair, or performance eligibility follows from this clearance.

**Recommendation:** GO for repair 2's bounded protected timing action and, separately, the corrected four-request top-20 discriminator. Preserve attempt 1 and repair 1 as superseded evidence. The discriminator is not a full-logit oracle, performance run, or repair of the historical exact-128 gate. `promoted=false` remains mandatory.
