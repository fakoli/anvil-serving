# Independent state and protected-ABBA result review

```yaml
schema_version: operator-workflow/v1
request: Review the closed repaired native state window, bounded top-20 discriminator, and protected ABBA-2 analysis without changing the historical numerical gate.
gate_state: diagnostic_accepted_qualification_held
targets:
  - retained GLM TP2 package d5aec1543dc32413175462d17d374e54d27def24129f878045358c4db128c357
  - Flare source 47581ccac82660953a5b59cb04b2750d64edc97d plus the hash-bound local diagnostic test
tools_used:
  - read-only source and evidence inspection
  - offline JSON and Prometheus-delta recomputation
  - SHA-256 binding checks
artifacts:
  findings_summary:
    - The repaired native test supports exact canonical Snapshot to Restore to re-Snapshot byte equality on both TP2 ranks at endpoints 512, 513, and 7708, within its reduced diagnostic cache geometry.
    - The four HTTP observations preserve identical eight-token continuations, but case 51 has different top-20 observations at indices 3 through 7 and a different speculative batch-shape counter distribution between first and repeat; this is not a pure cache-state or kernel attribution.
    - Protected ABBA-2 is complete descriptive evidence with matched output and work populations, but its wide signed timing deltas and unchanged historical three-percent gate prohibit a qualified performance recommendation.
    - The full-logit, independent numerical, host-restore, and historical 128-token sampled-ID gates remain open or failed.
  state_window:
    - ../state/window-2/512-summary.json
    - ../state/window-2/513-summary.json
    - ../state/window-2/7708-summary.json
    - ../state/window-2/closeout.json
  numerical_observations:
    - ../state/window-2/logprob-serving/observations/results.json
    - ../state/window-2/logprob-serving/observations/40-comparison.json
    - ../state/window-2/logprob-serving/observations/51-comparison.json
  protected_analysis:
    - ../analysis/protected-abba-2.json
    - ../analysis/protected-abba-2.md
advisory_priors:
  - Arrival-ordered reductions can make equal starting state insufficient for bitwise numerical equality; applicability to the observed path is not established here.
  - Top-20 normalized logprobs are a discriminator, not a full-vocabulary raw-logit oracle.
recommendation: accept_diagnostic_only_hold_numerical_and_performance_qualification
human_gate_required: true
promoted: false
```

## Findings

### F1 — High: the required numerical gate remains failed

The successful native run proves a copy seam, not numerical equivalence. It performs Prefill, Snapshot, Restore, and re-Snapshot with sampling disabled and host offload absent (`state/window-2/512-summary.json:5-22,71-74`; the 513 and 7708 summaries record the same final limitations). It never compares a restored `RESUME` result with an uncached execution, never exposes full-vocabulary pre-sampling logits, and never uses an independent Python/reference replay. The HTTP observation summary correctly records `full_logits_oracle=false`, `historical_128_id_gate_cleared=false`, and `performance_eligible=false` (`state/window-2/logprob-serving/observations/summary.json:2-5`).

**Concrete wrong result:** calling the state-copy pass a correctness repair or using the four eight-token requests to clear the retained 128-token exact-ID failure. **Classification: refuted by the retained evidence.** The historical numerical and sampled-ID gates remain failed; no tuning selection, qualification, or promotion follows.

### F2 — Medium: case 51's top-20 difference is real, but its cause is not isolated

Both case 51 arms used the same request body and emitted the same eight token IDs. The first arm was predominantly prefetched (`7699` prefill plus `9` GPU-reused tokens), while the repeat used `7708` GPU-reused tokens; neither fetched host state (`observations/results.json:3-30,33-60`). Top-20 observations are identical at indices 0-2, then differ at indices 3-7. The largest retained difference is `0.500295639` at index 5, but it is the maximum only over the 20 common top-20 entries at that step; indices 3 and 7 have only 18 and 19 common entries (`51-comparison.json:27-64`). It is not a bound over the full distribution or over non-common candidates. Case 40's top-20 observations are exact at all eight steps (`40-comparison.json:2-64`).

The raw Prometheus windows add a material confounder. Each request has the same aggregate speculative work: 3 rounds, 5 offered drafts, 4 accepted drafts, and 7 emitted tokens. Case 51's first arm spreads those counters across batch labels 1, 2, and 4 (`51-first-before.prom:19-35,135-151,193-209,251-267`; `51-first-after.prom` at the same lines), whereas its repeat adds all of that work to batch 1 (`51-repeat-before.prom` and `51-repeat-after.prom` at those lines). Both case 40 arms add their work only to batch 1. These are process counter deltas for the bounded request windows; they do not identify a precise kernel or prove whether scheduler probes or request execution produced every shape.

**Concrete wrong result:** attributing case 51's indices 3-7 to Snapshot/Restore, prefix caching, MTP acceptance, or a specific kernel. **Classification: confirmed attribution blocker.** The allowed claim is narrower: under the observed first-versus-full-GPU-reuse executions, the same sampled continuation coexisted with a partial top-20 difference and a different speculative shape-counter distribution.

### F3 — Medium: the exact-state claim must stay at canonical packed snapshot scope

The repaired test authenticates and authorizes the retained package, selects the requested 4-concurrency/2-draft/fixed-width catalog, and deliberately loads a reduced geometry of 1,024 logical pages plus the selected row requirement (`state_replay_tests.rs:283-367`). It poisons a distinct target live row and private partial/draft pages, restores into that target, poisons a distinct destination snapshot row, and byte-compares the complete canonical source and destination snapshot rows in bounded chunks (`state_replay_tests.rs:482-583`). Source/sentinel guards are then rehashed, and shutdown must drain before owners are released (`state_replay_tests.rs:585-640`).

The three successful endpoints produced six rank rows. Each rank compared exactly 81,464,576 canonical snapshot bytes; endpoints 512, 513, and 7708 retained respectively 51, 75, and 411 guarded spans per rank, with poison, source-guard, and canonical equality checks true (`512-summary.json:25-75`; `513-summary.json:25-79`; `7708-summary.json:65-175`). The 17 bound inputs were byte-identical before native work, after native work, and after the HTTP observations. The first window's CUDA-context fixture failure and both targeted repairs remain retained; the successful result validates the repaired fixture once and is not an independent repeatability population.

**Allowed claim:** exact canonical Snapshot to Restore to re-Snapshot byte equality for these three endpoints, both TP2 ranks, this signed package/catalog, and reduced diagnostic geometry, with guarded source spans and confirmed drain. **Disallowed claims:** equality of undefined live-row padding, direct live-versus-snapshot equality, host-store fidelity, sampling/RNG equivalence, full serving-cache coverage, every graph variant, or numerical recomputation correctness.

### F4 — Medium: protected ABBA-2 is useful descriptive evidence, not a passed performance gate

The analysis retains all 264 requests, including 144 measured requests. Every one of the four pair/lane comparisons has identical case sets, equal output IDs, and complete equal-work rows (`analysis/protected-abba-2.md:15-35`). The protected requests each emitted one token and their retained speculative-work deltas are zero, so the case-51 eight-token MTP-shape confounder does not apply to those measured populations.

The signed per-case B-minus-A distributions remain broad: small12 pair medians are +17.356% and +9.704%, while pageheavy medians are -6.128% and +7.245%, with ranges of 48.129 to 165.600 percentage points (`analysis/protected-abba-2.md:70-81`). The result supports completeness and observed timing distributions only. It does not clear the historical 3% protected threshold, explain the variance, or establish candidate parity. The original wrapper closeout remains false because restoration reconciliation failed; the additive manual recovery closed the operational state without rewriting that record (`analysis/protected-abba-2.md:10-13`).

### F5 — Low: operational closure is sufficient for this result review

The repaired state window records no experiment or restoration error, one serving generation, deadline compliance, `performance_eligible=false`, and `promoted=false` (`state/window-2/closeout.json:2-12`). Final status has the exact retained incumbent ID/image, running state, restart count zero, null containment error, and zero OOM events (`runtime/diagnostic2-state-incumbent-final.json:1`). Direct and routed preflights each passed all retained observations, and the router is ready, admitting, and idle (`runtime/diagnostic2-state-router-final.json:1`). This closes the state window operationally; it does not review or pre-approve the still-active trace campaign.

## Breakage probes

These attacks were fixed before considering prior harness tests:

| Axis | Concrete input/state and wrong result | Status |
|---|---|---|
| Unreadable state | Missing rank summary, unreadable package/profile, or incomplete drain is silently accepted as exact TP2 equality | **Refuted for this run:** six rank rows, authenticated load path, return code zero, and drain are present; residual risk is reliance on the repaired test's own summary generation |
| Malformed/boundary | A 512-boundary, 513 partial-page endpoint, stale page map, poisoned destination, or changed source span passes without exercising the affected bytes | **Refuted within the reduced geometry:** all three endpoints passed poison and guard checks; no claim extends to host offload or full serving capacity |
| Resource exhaustion | Whole allocations are retained in host memory or a stuck replay prevents safe teardown | **Refuted for the observed run:** comparison is chunked, all three endpoints drained, and restoration reported no OOM; total compared bytes are larger than the working chunk and must not be described as a 32 MiB total oracle |
| State drift | Source, binary, config, package, or serving incarnation changes between endpoints/HTTP observations while evidence is combined | **Refuted for the bound window:** all 17 hashes match before/after and one serving generation is recorded; a later trace window is outside this review |
| Cross-seam attribution | Equal eight-token IDs plus changed top-20 values are labeled a cache-state defect while graph-shape work also changed | **Confirmed:** case 51's speculative batch-label distribution differs, so the cause remains unresolved |

## Recommendation and residual risk

**ACCEPT the exact-state result and ABBA/top-20 records as bounded diagnostic evidence. HOLD numerical qualification, performance qualification, tuning selection, and promotion.** The next numerical gate still requires a prospectively bounded restored-versus-control full-logit observation and an independent uncached/reference comparison; the historical 128-token exact-ID gate cannot be rewritten. Any later trace result must be reviewed separately and may localize time, not retroactively supply numerical correctness.

Implementer/evidence generator: GPT-6 Astra. Independent reviewer: GPT-5.6 Sol high. Evaluated model: GLM-5.3-Flash under Flare. The evaluated model did not grade itself. `promoted=false` remains mandatory.

### Bound artifact hashes

- `512-summary.json`: `5b8409eef72aacf7777aed440afbbf9763638147710d7eb8f00c3b4690ee761b`
- `513-summary.json`: `b1a61e243381e98c2682220701a90b49e8d930048eea7632de6e749db2e129a1`
- `7708-summary.json`: `48f50c9017acdc3c9dea2a0f2fd654b715ab2718a6cb4342a50e81fa1cf801e0`
- state closeout: `6e7cb96db638413ba099a75bb961b1a0e5cc381069d97d242acf4d8a148cfedb`
- top-20 summary/results: `eae805b7e04c055333c817efd33dba3097893a19c66a15c394353d3160ccff3f` / `dfcba3fc1c9051ae0261dc2b9cbcb9e676974da00d350b567b8f0ed5a6611f99`
- case 40/51 comparisons: `16544dca543036cc2d6faf2f4021196cb8a1101c7571341b6ba4a2c55118823f` / `bd1dc3ae1f3bccfd5a1ba71fc6dff2b7b15cdbac75f3bd9a1eba98841e16a7fc`
- protected ABBA-2 JSON/Markdown: `66d290b358bee59fb037013f24aedc8b304bd90d1e2b25d44a9c2bf371ac85b8` / `50b8bfdb772c7ddb923d268f901546722f300578e11ab293238375f965a269d7`
