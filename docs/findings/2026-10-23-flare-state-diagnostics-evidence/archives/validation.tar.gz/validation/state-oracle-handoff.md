# Retained TP2 state oracle — implementation handoff

Implemented one ignored native test:
`runtime_package::state_replay_tests::retained_tp2_snapshot_restore_snapshot_exact`.

Source ownership is limited to new `helios/src/runtime_package/state_replay_tests.rs`, new `state_replay_scheduler.rs`, and test-only registration in `runtime_package/mod.rs` and `scheduler.rs`. Prior dirty changes were preserved. The scheduler child module calls its existing `retain_snapshot` allocator, requires quiescent restored state, and returns the normal Snapshot plan. It adds no production API or graph family.

Three compile-only invocations passed (16.03s,9.72s,12.93s); logs `state-oracle-compile-{1,2,3}.log` retain all attempts. There were no failed builds. The intervening corrections matched the real public profile-list schema/accepted local-development signer and the campaign's selected graph catalog. Existing unrelated CUDA dead-code warnings remain. Final binary lists exactly one matching test. `rustfmt` and `git diff --check` passed. **No GPU test, model request, lifecycle, package preparation or Docker operation was performed by this author.** Independent static review and root-owned hardware execution remain required.

## Inputs and execution

Host binary: `OPERATOR_PATH_d6852559f772/flare_helios-2c1079bd13063c63`.

The only test environment input is `FLARE_STATE_TEST_CONFIG`, a path to a bounded JSON object with these fields:

```json
{
  "package": "OPERATOR_PATH_d3f476aaccf9/model.safetensors",
  "publisher_profile": "PATH_TO_EXISTING_PUBLIC_PROFILE_LIST",
  "accepted_signer": "EXISTING_ACCEPTED_SHA256_OF_PUBLIC_KEY",
  "accepted_namespace": "EXISTING_ACCEPTED_NAMESPACE",
  "model_id": "dec48abd33efa73c3bb7c95b74eee10cad34f9be",
  "devices": [0, 1],
  "max_concurrency": 4,
  "mtp_draft_tokens": 2,
  "adaptive_verification": false,
  "tokens_file": "PATH_TO_FROZEN_TOKEN_ID_ARRAY_JSON",
  "endpoint": 513
}
```

The profile is the standard `Vec<Publisher>` verification-only JSON used by `flare/src/trust.rs::publishers`. The existing managed recipe mounts `flare-glm53-47581cca-private:/root/.config/flare` and uses `/root/.config/flare/development-publisher.json`; root must resolve/check the host volume mount (expected `OPERATOR_PATH_60be5fcf7085/development-publisher.json`). Only that public profile, accepted namespace/fingerprint, package primary/companion blobs and its bundled frontend assets are required. **No signing private key, API credential, trust-store mutation or network identity lookup is needed.** Retain the already accepted signer; do not derive trust from the package's unverified claim. `VerifiedPackage::open` verifies signatures, explicit signer/namespace checks bind acceptance, and `authorize(...,true)` verifies stored data before native loading.

Token file: plain JSON array of valid unsigned vocabulary IDs, length2..16384; endpoint must be positive and strictly less than array length. The test truncates to endpoint+1 IDs, sets a message boundary at endpoint, and never executes the trailing token. For an original prompt of lengthP, append its already retained first continuation token (or preserve an existing longer frozen input) so endpointP is legal. Do not tokenize anew with a different tokenizer. Boundary512 and513 require at least514IDs. Verify actual signed page_tokens in output; the test never assumes256or512.

The concrete fixture is now `validation/case51-state-token-ids.json`, SHA256`e764b1f2d4a3559adfdbbe3a1bd4584a402214f05cac8f4d4261d716146a077a`. It preserves the7,708 native prompt IDs in prior `pilot-a-restore-reference/http/051-response.json` and appends its first retained output ID785; total7,709. Use endpoint7708 for the full prompt. The provenance sidecar records the original response hash and field paths. All emitted model IDs match the revision above. The earlier7,699 figure is host-reused tokens, not the total prompt. No tokenizer was rerun. Root independently confirmed these counts.

Root resolved the existing public profile to namespace`local-development` and accepted signer`9a875a5abc035d2a751789249c6b5635af2181434b43acf182cf453342293b59`. Keep those exact values in the private test config; no private signing material was read by this implementation task.

After root obtains exclusive assigned GPUs and a separately bounded restoration window, the direct test command is:

```sh
FLARE_STATE_TEST_CONFIG=/absolute/path/state-test.json OPERATOR_PATH_d6852559f772/flare_helios-2c1079bd13063c63 --exact runtime_package::state_replay_tests::retained_tp2_snapshot_restore_snapshot_exact --ignored --nocapture --test-threads=1
```

Root must arrange package/profile read permissions and appropriate test-process resource limits without changing package bytes. Root owns the outer process deadline; do not start this inside an active timing phase. The test has120s per-fence observation deadlines, but blocking CUDA calls/drain are not forcibly bounded by that timer.

## Oracle and limits

The existing signed selector is applied to4/2/false before deriving execution rows. Normal native loading selects the identical catalog. Existing `load_agreeing` backs four snapshot rows and1,024logical pages, with normal physical-fit validation; host offload is disabled. These reduced diagnostic cache capacities are intentionally not the timing configuration. Signed cache geometry drives every row/page address, checked against owned device allocation bounds. Readback scratch is two16MiB buffers reused serially across ranks; no whole pool download or weight readback.

The original request runs Init→non-sampling Prefill→SnapshotA at the endpoint, using normal scheduler commit, shared input packing and real completion validation. It remains alive to pin its immutable snapshot/pages and retain its live row. A second request hits that exact prefix, receives a different live row and private target/draft tail pages, and runs Restore after those destinations have been filled with0xa5 and read-verified. A test-only allocator reservation then runs normal SnapshotB into a separately poisoned row. Every packed A/B byte is compared on both ranks; the first mismatch reports rank and byte offset. SHA256 guards separately verify unchanged source snapshot, all original live execution rows, original page planes and null row. Complete pages are checked by their logical positions and intentionally share the immutable physical pages. Target/draft private tails are exercised through the captured Restore/re-Snapshot packing, including its shifted draft semantics.

**A live row cannot be compared wholesale with a packed snapshot:** Snapshot materializes external partial-page records into its row. A→Restore→B is the canonical exact comparator; the test does not claim whole-live-row equivalence. Source immutability checks are streaming SHA256 checks, while A/B equality is direct byte comparison. The original live/page guards include inactive bytes; no floating tolerance is applied.

Every submitted frame completes across both ranks before readback. Panic and success paths explicitly close the executor, require confirmed drain before scheduler retirement, and retain/leak GPU owners if drain is unconfirmed. Success reports drain and zero live requests. The test does not publish the second diagnostic checkpoint into the cache.

This establishes only the captured GPU maintenance roundtrip if it passes. It does not establish independent cold-prefill numerical correctness, RNG equivalence, full logits equality, host-store/DMA coverage, allocator performance, or the historical failed128-output gate. No sampler policy is changed and no token is sampled in this test.
