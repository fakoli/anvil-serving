# Protected ABBA-2 closed-bracket summary

**Scope:** descriptive diagnostic evidence only. The analyzer marks
`diagnostic_only=true`, `performance_eligible=false`, and
`recommend_candidate=false`; it does not alter the earlier protected-regression
threshold or any prior failed gate. This summary uses
`analysis/protected-abba-2.json` (SHA-256
`66d290b358bee59fb037013f24aedc8b304bd90d1e2b25d44a9c2bf371ac85b8`). Percent deltas are B minus A; p95 uses nearest rank.

The original `formal/protected-abba-2/closeout.json` false outcome remains
retained. `recovery-closeout.json` and `CLOSED` record the additive manual
recovery that made this completed bracket analyzable; neither erases the
original closeout record.

## Completeness and equality

All 264 planned requests completed: 24 warmups, 96 prime requests, and 144
measured requests. `small12` completed 39 requests in each of four
incarnations (24 measured each); `pageheavy` completed 27 in each (12 measured
each). Every phase has expected = attempted = completed and failed = missing =
0.

| Lane | Pair | Measured cases per arm | Identical case-ID sets | Equal output-token IDs | Complete equal work |
| --- | --- | ---: | --- | ---: | ---: |
| small12 | 1-A ↔ 2-B | 24 | yes | 24/24 | 24/24 |
| small12 | 4-A ↔ 3-B | 24 | yes | 24/24 | 24/24 |
| pageheavy | 1-A ↔ 2-B | 12 | yes | 12/12 | 12/12 |
| pageheavy | 4-A ↔ 3-B | 12 | yes | 12/12 | 12/12 |

Across the analyzer's measured rows, the summed `flare_prefill_tokens_total`,
`flare_host_cache_fetched_total`, and
`flare_host_cache_fetch_failed_total` are each zero for every incarnation.
The measured before/after Prometheus receipts add that
`flare_host_cache_stored_total` has a zero delta, even though its settled
counter value is 31. That confirms the sampled counters for this bracket; it
does not establish a kernel-level cause.

### Measured host-cache snapshots

All 288 measured before/after Prometheus snapshots were inspected (two for each
of 144 measured requests). Within each incarnation, every request advances
`flare_host_cache_lookups_total` by exactly one—24 total in `small12`, 12 in
`pageheavy`—while hits, fetches, fetch failures, and store-counter deltas stay
zero. `flare_host_cache_memory_records` is 31 in every before and after sample
for both A and B.

| Lane | Per-incarnation requests | `bytes_out_total` before/after | `bytes_in_total` before/after | Outbound/inbound/inbound-waiting gauges |
| --- | ---: | ---: | ---: | --- |
| small12 | 24 | 6,022,796,800 / 6,022,796,800 | 0 / 0 | all 0 / 0 |
| pageheavy | 12 | 6,808,663,552 / 6,808,663,552 | 0 / 0 | all 0 / 0 |

This distinguishes an observed settled lookup-only state at the retained
before/after samples from sampled concurrent outbound or inbound transfer work:
there is no counter change or nonzero flight/wait gauge in those receipts. It
does not rule out activity between samples, establish the full host-cache state
outside this bracket, or attribute the latency variation to host transfer.

## Arm summaries

All values are milliseconds. Primary is client E2E for `small12` and
client-generated TTFT for `pageheavy`.

| Lane | Arm | Primary n | Primary median | Primary p95 | Native first-token n | Native median | Native p95 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| small12 | A | 48 | 17.037 | 24.824 | 48 | 15.498 | 22.250 |
| small12 | B | 48 | 20.010 | 28.381 | 48 | 18.070 | 23.486 |
| pageheavy | A | 24 | 32.823 | 57.309 | 24 | 28.661 | 50.085 |
| pageheavy | B | 24 | 35.586 | 55.678 | 24 | 31.036 | 48.746 |

## Matched per-case deltas

Each delta population is complete and output/work matched. The range is
per-case B-minus-A percent, retained to show variation rather than infer a
single causal effect.

| Lane | Pair | n | Median | p95 | Min | Max | Range |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| small12 | 1-A ↔ 2-B | 24 | +17.356% | +91.606% | -41.024% | +94.434% | 135.458 pp |
| small12 | 4-A ↔ 3-B | 24 | +9.704% | +62.227% | -38.890% | +126.709% | 165.600 pp |
| pageheavy | 1-A ↔ 2-B | 12 | -6.128% | +31.950% | -38.254% | +31.950% | 70.205 pp |
| pageheavy | 4-A ↔ 3-B | 12 | +7.245% | +35.734% | -12.395% | +35.734% | 48.129 pp |

## Trace-fit and monitoring context

Each full measured incarnation fits inside the planned 30-second trace bound:
`small12` spans 10.6658–10.7589 seconds and `pageheavy` spans 4.9861–5.1273
seconds, from the earliest measured request start to latest measured request
completion. This only establishes timing fit for a later separately captured,
trace-excluded A/B diagnostic window.

All eight fresh incarnation generations have `up=1` and GPU collection
freshness = 1 at readiness. Query-range artifacts also retain sampled GPU SM
and memory clocks, power, temperature/throttle flags, utilization, and host
available RAM through each window. These are metadata-supported observations;
they are not kernel timing, do not explain the observed timing variation, and
must not be used to attribute a root cause to power or thermal state.
