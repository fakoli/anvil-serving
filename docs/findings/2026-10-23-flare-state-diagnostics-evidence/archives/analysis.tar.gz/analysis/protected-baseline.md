# Protected-lane baseline isolation

**Scope:** read-only analysis of the completed 2026-10-22 formal matrix. This
is diagnostic evidence, not a new experiment or a performance claim. The input
is [normalized-matrix.json](../../2026-10-22-flare-cache-fix/analysis/normalized-matrix.json)
(SHA-256 `5d47ecba13a6b7cc089ebe7fcb07018bcf94cc872e38190c30d1896bb6209143`)
and the derived [machine record](protected-baseline.json).

`small12` has 24 measured requests per arm per repetition; `pageheavy` has 12.
Every one completed successfully and has matched output and work. The 1.571 ms
small12 and 4.420 ms pageheavy values below are arm-median B-minus-A differences
in repetition 3. They are retained observations, not causal estimates.

## Timing separation

| Lane / repetition | Arm order | B−A arm median: primary metric | B−A native first token | B−A paired primary median | Paired spread (stdev) |
| --- | --- | ---: | ---: | ---: | ---: |
| small12 r1 | A→B | E2E −0.371 ms | −1.087 ms | −0.587 ms | 5.870 ms |
| small12 r2 | B→A | E2E −1.134 ms | −1.446 ms | +0.101 ms | 4.201 ms |
| small12 r3 | A→B | E2E +1.571 ms | +0.727 ms | +0.222 ms | 5.932 ms |
| pageheavy r1 | A→B | TTFT −0.269 ms | −1.459 ms | −0.622 ms | 11.811 ms |
| pageheavy r2 | B→A | TTFT +0.186 ms | +0.770 ms | −3.540 ms | 5.818 ms |
| pageheavy r3 | A→B | TTFT +4.420 ms | +3.304 ms | +0.729 ms | 4.274 ms |

The r3 movement appears in both native-first-token and client measurements:
small12's client-minus-native median changes from 1.862 to 1.743 ms (A/B), and
pageheavy's from 5.747 to 4.189 ms. Thus, the retained timing does not isolate
the r3 regression as client transport overhead. It also does not establish an
allocator cause: these timing layers remain affected by other unobserved
scheduler and system work.

The r3 pageheavy p95 rises from 63.550 to 64.631 ms; r3 small12 p95 rises from
23.571 to 25.165 ms. Dispersion remains material: r3 pageheavy arm standard
deviations are 16.264 ms (A) and 16.951 ms (B); r3 small12 is 4.123 and
4.112 ms. The recorded order is A→B in r1 and r3 and B→A in r2, so neither
order nor an across-repetition trend identifies a cause.

## Cache, admission, and work accounting

For every protected A/B repetition, the complete measured phase has identical
counter sums in both arms:

| Lane | Requests / arm | Prefill | Generated | Cache reused | Host reuse / fetch / admission host hit | Store/fetch failures |
| --- | ---: | ---: | ---: | ---: | ---: |
| small12 | 24 | 0 | 24 | 184,926 | 0 / 0 / 0 | 0 / 0 |
| pageheavy | 12 | 0 | 12 | 212,432 | 0 / 0 / 0 | 0 / 0 |

Both arms therefore had full GPU-cache reuse for these measured requests. The
counters provide no differential host-fetch, admission, prefill, generated-work,
or cache-reuse signal that could explain either r3 change. They are not
exclusive origins of work, so equality does not prove identical internal
scheduling; it only rules out these retained aggregate differences.

The formal monitoring receipts verify generation, identity, and traffic-range
conditions. They are not scheduler-event traces, and no scheduler trace artifact
was retained for the protected measured requests. The existing monitoring and
request data therefore separate neither queue/dispatch delay nor a physical
allocator mechanism from ordinary variation. No correlation is treated as a
cause here.

## Smallest bounded next measurement

Subject to explicit lifecycle approval, reuse the frozen replay harness, image,
model/settings, protected inputs, warmup/prime protocol, and verification-off
timing configuration. Run one predeclared counterbalanced A/B bracket for each
protected lane, retaining all attempts:

| Lane | Measured requests / arm | Required retained fields |
| --- | ---: | --- |
| small12 | 24 | exact output/work, native-first-token, client TTFT, E2E, phase counters |
| pageheavy | 12 | exact output/work, native-first-token, client TTFT, E2E, phase counters |

Use the existing A/B runner order reversal across the two lane brackets. If the
existing scheduler trace can be captured without changing timing semantics,
retain its event timestamps beside—not in place of—the normal native receipts.
Do not add a new observability framework. These denominators match the completed
formal lanes; a smaller probe would not resolve the 1.571/4.420 ms arm-median
observations against the retained within-arm and paired spread. The outcome is
diagnostic only and cannot clear numerical, performance, or promotion gates.
