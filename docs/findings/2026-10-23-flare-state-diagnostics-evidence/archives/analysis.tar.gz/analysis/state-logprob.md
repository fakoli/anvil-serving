# Closed state and top-20 diagnostic summary

This is an authoritative compact view of
`analysis/state-logprob.json` (SHA-256
`08d853cefb117bc44aad18cf74750d2419bda84cc58176df5a3c76f9e12ab44b`).
It is diagnostic only: `performance_eligible=false`,
`recommend_candidate=false`, and `promoted=false`.

## Retained windows and repairs

Window 1 closed with the native endpoint-512 failure and restored successfully.
It is retained as failed evidence. The reviewed follow-up made two bounded
source repairs: the first addressed the direct-rank CUDA-context handling
behind the invalid-value copy failure; the second closed the pre-close context
assertion hold. The five retained compile-only passes—three initial and two repair
passes—establish buildability only; none was a GPU execution.

Window 2 closed with no experiment or restoration error, one retained
registration generation, and unchanged bindings before native execution, after
native execution, and after the HTTP observations. It does not erase Window
1's failure or turn the repair into a general production claim.

## Native state roundtrip

Each endpoint process returned zero and emitted two rank checks. Each rank
check exercised a Snapshot A → Restore → Snapshot B test with 81,464,576
snapshot bytes per rank. Canonical snapshot equality, poison verification, and source-guard
checks all passed; every endpoint reported zero active requests and a confirmed
drain.

| Endpoint | Guarded spans/rank | Process / rank checks | Snapshot bytes/rank | Poison / guards / drain |
| ---: | ---: | --- | ---: | --- |
| 512 | 51 | return 0 / 2 passed | 81,464,576 | pass / pass / pass |
| 513 | 75 | return 0 / 2 passed | 81,464,576 | pass / pass / pass |
| 7708 | 411 | return 0 / 2 passed | 81,464,576 | pass / pass / pass |

The native configuration was TP2 ranks 0/1 with `max_concurrency=4`, MTP width
2, adaptive verification disabled, and 512-token pages. It uses the reduced
four-snapshot/1024-page diagnostic geometry, which is not the serving-cache
configuration. Host offload and sampling were not exercised by this native
test.

The result establishes exact packed continuation-state roundtrip only for the
exercised endpoint-specific state of the signed package. It does not establish
uncached numerical correctness, sampler/RNG equivalence, full-logit equality,
host-store/DMA behavior, cache-policy performance, serving-cache capacity, or
clear the historical exact-128 token-ID failure.

## HTTP top-20 observations

Three warmups completed (3 expected, 3 completed, 0 missing), followed by four
successful HTTP observations: first and repeat requests for cases 40 and 51.
The comparison rule is strict: compare top-20 values only while the two output
histories remain identical, stopping at the first output-token-ID divergence.
Neither pair diverged within its eight returned IDs, so each pair contributes
eight in-scope positions. This is not an exact-128 test.

| Case | In-scope positions | First ID divergence | Equal sampled IDs | Exact top-20 positions | Nonexact top-20 positions | Minimum overlap | Largest common absolute logprob delta |
| ---: | ---: | --- | --- | --- | --- | ---: | ---: |
| 40 | 8 | none in 8 | yes | 0–7 | none | 20/20 | 0 |
| 51 | 8 | none in 8 | yes | 0–2 | 3–7 | 18/20 | 0.500295639 |

The case-51 change is a bounded sampled-distribution observation under the
same returned token history; it does not localize a full-vocabulary numerical
error. Its aggregate speculative work is the same in first and repeat (3
rounds, 5 offered drafts, 4 accepted drafts, and 7 emitted tokens), but the
first observation has nonzero batch labels 1, 2, and 4 while the repeat has
only batch label 1. Case 40 uses only batch label 1 in both observations. This
batch-shape difference is an attribution blocker: the result cannot be assigned
solely to restored state, cache, MTP acceptance, or a specific kernel. The
counter deltas do not establish whether scheduler probes or request execution
produced every shape.

There is no full-logit readback contract for the retained signed package, no
teacher-forced independent reference, and no relative-L2 or KL result. The
historical exact-128 gate therefore remains failed and uncleared.

## Evidence and limits

`state-logprob.json` lists SHA-256-bound closed source artifacts, including
both closeouts, all three native summaries, before/after binding receipts,
warmup and observation summaries, per-case comparisons, reviews, and harness
validation. The independently accepted diagnostic/qualification-hold review is
`review/state-results-review.md`; its hash is listed in the JSON. The analysis
retains the first failure and repair count rather than replacing them with
Window 2.
