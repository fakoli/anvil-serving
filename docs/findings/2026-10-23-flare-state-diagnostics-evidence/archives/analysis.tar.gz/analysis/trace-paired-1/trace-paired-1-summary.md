# Paired scheduler-trace normalization

This summary is descriptive scheduler evidence only. It is derived from the
four closed captures with the retained
`2026-10-21-flare-inference-diagnostics/wave-v1/analyze-scheduler.py` and
recorded in `trace-paired-1-summary.json`. It is not a timing qualification,
host-transfer oracle, or causal bottleneck finding.

## Coverage

The four capture groups all completed with zero dropped boundary samples. Their
trace-coverage receipts retain 72/72 measured HTTP intervals: `small12` 24
for A and 24 for B, `pageheavy` 12 for A and 12 for B. The trace normalizer
contains 144 scheduler samples across four approximately 30-second captures.
Coverage establishes that these full measured populations occurred within their
capture windows. It does **not** map an HTTP request to a native scheduler slot
or generation; every receipt explicitly records that mapping as `not_inferred`.

## Observations

Values are p50 / p95. Selection-to-commit is microseconds; all other columns
are milliseconds. GPU is the maximum of the two rank intervals in a scheduler
sample. The normalizer retains the underlying graph/queue/lane group
breakdowns in the four per-capture JSON outputs.

| Lane | Arm | Scheduler samples | Selection → commit | Commit → observation | Max-rank GPU | Wall | Rank interval spread |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| small12 | A | 48 | 14.869 / 52.191 | 0.703 / 1.705 | 0.457 / 0.585 | 0.623 / 0.740 | 0.014 / 0.151 |
| small12 | B | 48 | 14.354 / 46.648 | 0.702 / 1.612 | 0.422 / 0.608 | 0.611 / 0.702 | 0.012 / 0.133 |
| pageheavy | A | 24 | 15.285 / 46.763 | 0.771 / 1.692 | 0.424 / 0.613 | 0.623 / 0.707 | 0.024 / 0.169 |
| pageheavy | B | 24 | 13.302 / 34.854 | 0.706 / 1.472 | 0.427 / 0.579 | 0.618 / 0.654 | 0.020 / 0.177 |

These are observations of scheduler samples, not request-attributed timings.
Rank intervals overlap and are not summed; their spread is not synchronization
wait. Wall minus GPU is not pure CPU overhead. Graph dimensions are capacities,
not executed token counts, and retained shape cost is a prior observation rather
than the submitted-plan estimate. The trace was separately captured and cannot
clear numerical, protected-performance, host-transfer, or promotion gates.

## Sources and review state

The summary JSON binds the four raw captures, their four normalized outputs,
the trace closeout, root closure verification, and the retained analyzer hash.
The trace is closed operationally, but causal interpretation remains pending an
independent final trace review. Do not use this record as a causal conclusion
before that review.
